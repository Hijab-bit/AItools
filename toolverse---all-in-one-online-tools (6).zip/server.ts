import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import ILovePDFApi from '@ilovepdf/ilovepdf-nodejs';
import fs from 'fs';
import os from 'os';
import dotenv from 'dotenv';
import multer from 'multer';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const upload = multer({ 
  dest: os.tmpdir(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit as requested
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // iLovePDF API Route
  app.post("/api/pdf/merge", async (req, res) => {
    const { files } = req.body; // Array of base64 strings or URLs
    
    const publicKey = process.env.ILOVEPDF_PUBLIC_KEY;
    const secretKey = process.env.ILOVEPDF_SECRET_KEY;

    if (!publicKey || !secretKey) {
      return res.status(500).json({ error: "iLovePDF API keys not configured in environment." });
    }

    try {
      const instance = new ILovePDFApi(publicKey, secretKey);
      const task = instance.newTask('merge');
      await task.start();

      const tempFiles: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const fileData = files[i];
        if (fileData.startsWith('http')) {
          await task.addFile(fileData);
        } else {
          // Handle base64
          const base64Data = fileData.replace(/^data:application\/pdf;base64,/, "");
          const tempPath = path.join(os.tmpdir(), `merge_${i}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPath, base64Data, 'base64');
          tempFiles.push(tempPath);
          await task.addFile(tempPath);
        }
      }

      await task.process();
      const data = await task.download();
      
      // Cleanup temp files
      tempFiles.forEach(f => {
        try { fs.unlinkSync(f); } catch (e) {}
      });

      res.setHeader('Content-Type', 'application/pdf');
      res.send(data);
    } catch (error: any) {
      console.error("iLovePDF Error:", error);
      res.status(500).json({ error: error.message || "Failed to merge PDFs" });
    }
  });

  app.post("/api/pdf/compress", async (req, res) => {
    const { file } = req.body; // base64
    
    const publicKey = process.env.ILOVEPDF_PUBLIC_KEY;
    const secretKey = process.env.ILOVEPDF_SECRET_KEY;

    if (!publicKey || !secretKey) {
      return res.status(500).json({ error: "iLovePDF API keys not configured in environment." });
    }

    try {
      const instance = new ILovePDFApi(publicKey, secretKey);
      const task = instance.newTask('compress');
      await task.start();

      const base64Data = file.replace(/^data:application\/pdf;base64,/, "");
      const tempPath = path.join(os.tmpdir(), `compress_${Date.now()}.pdf`);
      fs.writeFileSync(tempPath, base64Data, 'base64');
      
      await task.addFile(tempPath);
      await task.process();
      const data = await task.download();
      
      try { fs.unlinkSync(tempPath); } catch (e) {}

      res.setHeader('Content-Type', 'application/pdf');
      res.send(data);
    } catch (error: any) {
      console.error("iLovePDF Error:", error);
      res.status(500).json({ error: error.message || "Failed to compress PDF" });
    }
  });

  // PDF Unlock Route (using iLovePDF as qpdf is not available)
  app.post("/api/pdf/unlock", upload.single('pdf'), async (req, res) => {
    const file = req.file;
    const { password } = req.body;

    if (!file) {
      return res.status(400).json({ error: "No PDF file uploaded." });
    }

    const publicKey = process.env.ILOVEPDF_PUBLIC_KEY;
    const secretKey = process.env.ILOVEPDF_SECRET_KEY;

    if (!publicKey || !secretKey) {
      // Cleanup temp file
      try { fs.unlinkSync(file.path); } catch (e) {}
      return res.status(500).json({ error: "iLovePDF API keys not configured in environment." });
    }

    try {
      const instance = new ILovePDFApi(publicKey, secretKey);
      const task = instance.newTask('unlock');
      await task.start();

      // Add the file and set the password
      const iloveFile = await task.addFile(file.path);
      (iloveFile as any).password = password;

      await task.process();
      const data = await task.download();
      
      // Cleanup temp file
      try { fs.unlinkSync(file.path); } catch (e) {}

      res.setHeader('Content-Type', 'application/pdf');
      res.send(data);
    } catch (error: any) {
      console.error("iLovePDF Unlock Error:", error);
      // Cleanup temp file
      try { fs.unlinkSync(file.path); } catch (e) {}
      res.status(500).json({ error: error.message || "Failed to unlock PDF. Check your password." });
    }
  });

  // YouTube Downloader API (Apify)
  app.post("/api/video/download", async (req, res) => {
    const { url } = req.body;
    const apiToken = process.env.APIFY_API_TOKEN;

    if (!apiToken) {
      return res.status(500).json({ error: "Apify API token not configured." });
    }

    try {
      // Start the actor run
      const response = await fetch(`https://api.apify.com/v2/acts/streamers~youtube-video-downloader/runs?token=${apiToken}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          downloadVideo: true,
          videoUrl: url
        })
      });

      const runData = await response.json();
      
      if (!response.ok) {
        throw new Error(runData.error?.message || "Failed to start Apify run");
      }

      // Return the run ID so the client can poll or wait
      res.json(runData);
    } catch (error: any) {
      console.error("Apify Error:", error);
      res.status(500).json({ error: error.message || "Failed to start download" });
    }
  });

  // Get Apify Run Status/Result
  app.get("/api/video/download/status/:runId", async (req, res) => {
    const { runId } = req.params;
    const apiToken = process.env.APIFY_API_TOKEN;

    try {
      const response = await fetch(`https://api.apify.com/v2/actor-runs/${runId}?token=${apiToken}`);
      const runData = await response.json();

      if (runData.data.status === 'SUCCEEDED') {
        // Get the output from the default dataset
        const datasetResponse = await fetch(`https://api.apify.com/v2/datasets/${runData.data.defaultDatasetId}/items?token=${apiToken}`);
        const items = await datasetResponse.json();
        res.json({ status: 'SUCCEEDED', results: items });
      } else {
        res.json({ status: runData.data.status });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
