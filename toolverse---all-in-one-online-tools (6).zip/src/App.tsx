import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Search, Moon, Sun, Menu, X, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, 
  Star, Heart, Share2, ArrowLeft, ExternalLink, Instagram, Hash,
  Info, Mail, Shield, LayoutGrid, CheckCircle2,
  Copy, FastForward, Image as ImageIcon, Video as VideoIcon, Music as MusicIcon,
  Terminal, Code, Wand2, Edit3, Film as FilmIcon, Minimize2, Maximize2,
  Mic, MessageSquare, Eye, Braces, Globe, Filter,
  ArrowRight, Zap, Cpu, Github, Twitter, Linkedin,
  Play, Download, Settings, Trash2, FileText, FileMinus, Upload, FileAudio, Volume2, VolumeX, FileArchive, RefreshCw, Scissors, Contrast,
  Plus, Crop, SlidersHorizontal, Layers, Gauge,
  Presentation, Unlock, Lock, Table, PenTool, Scan, FileType, FileImage, Droplet, FilePlus, RotateCw, Link, Youtube, Layout, Type, Repeat, TrendingUp, SortAsc, Languages,
  Sparkles, Box, Camera, Palette, Send, Bot, User as UserIcon, Bug, ShieldAlert, AlertCircle, CheckCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Modality, ThinkingLevel } from "@google/genai";
import { cn } from './lib/utils';
import { TOOLS, CATEGORIES, Tool, Category } from './toolsData';
import { auth, signInWithGoogle, logout, db } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp, collection, addDoc, query, where, onSnapshot, deleteDoc } from 'firebase/firestore';
import { PDFDocument, rgb, degrees, StandardFonts } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import Tesseract from 'tesseract.js';
import mammoth from 'mammoth';
import html2pdf from 'html2pdf.js';
import * as XLSX from 'xlsx';
import { QRCodeSVG } from 'qrcode.react';
import Markdown from 'react-markdown';
import { 
  DndContext, 
  closestCenter, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors,
  DragEndEvent,
  TouchSensor
} from '@dnd-kit/core';
import { 
  arrayMove, 
  SortableContext, 
  sortableKeyboardCoordinates, 
  verticalListSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

// --- Components ---

const Navbar = ({ 
  darkMode, 
  toggleDarkMode, 
  onNavigate,
  user,
  onSignIn,
  onLogout
}: { 
  darkMode: boolean; 
  toggleDarkMode: () => void;
  onNavigate: (view: string) => void;
  user: User | null;
  onSignIn: () => void;
  onLogout: () => void;
}) => (
  <nav className="sticky top-0 z-50 w-full border-b border-red-500/20 bg-black/40 backdrop-blur-xl">
    <div className="container mx-auto px-4 h-16 flex items-center justify-between">
      <div 
        className="flex items-center gap-2 cursor-pointer" 
        onClick={() => onNavigate('home')}
      >
        <div className="w-10 h-10 bg-black border-2 border-red-600 rounded-xl flex items-center justify-center text-yellow-400 shadow-lg shadow-red-500/20">
          <LayoutGrid size={24} />
        </div>
        <span className="text-xl font-bold tracking-tight text-white">
          Tool<span className="text-red-600">Verse</span>
        </span>
      </div>

      <div className="hidden md:flex items-center gap-8">
        {['Tools', 'About', 'Contact'].map((item) => (
          <button
            key={item}
            onClick={() => onNavigate(item.toLowerCase())}
            className="text-sm font-medium text-gray-300 hover:text-yellow-400 transition-colors"
          >
            {item}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <button
          onClick={toggleDarkMode}
          className="p-2 rounded-lg bg-black/40 border border-red-500/20 text-yellow-400 hover:bg-black/60 transition-colors"
        >
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        
        {user ? (
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <p className="text-xs font-bold text-white truncate max-w-[100px]">{user.displayName}</p>
              <button onClick={onLogout} className="text-[10px] text-red-400 hover:text-red-300 uppercase font-bold tracking-widest">Logout</button>
            </div>
            <img src={user.photoURL || ''} alt="Profile" className="w-10 h-10 rounded-full border-2 border-red-600 shadow-md" />
          </div>
        ) : (
          <button 
            onClick={onSignIn}
            className="hidden sm:block px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20"
          >
            Sign In
          </button>
        )}
        
        <button className="md:hidden p-2 text-yellow-400">
          <Menu size={24} />
        </button>
      </div>
    </div>
  </nav>
);

const Footer = ({ onNavigate }: { onNavigate: (view: string) => void }) => (
  <footer className="bg-black/60 border-t border-red-500/20 py-12 backdrop-blur-xl">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-black border border-red-600 rounded-lg flex items-center justify-center text-yellow-400 shadow-sm">
              <LayoutGrid size={18} />
            </div>
            <span className="text-lg font-bold text-white">ToolVerse</span>
          </div>
          <p className="text-sm text-gray-400 leading-relaxed">
            The ultimate collection of 100+ free online tools for everyone. 
            Simple, fast, and secure.
          </p>
        </div>
        <div>
          <h4 className="font-bold mb-4 text-white">Categories</h4>
          <ul className="space-y-2 text-sm text-gray-400">
            {CATEGORIES.slice(0, 5).map(cat => (
              <li key={cat.name} className="hover:text-red-500 cursor-pointer">{cat.name} Tools</li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-4 text-white">Company</h4>
          <ul className="space-y-2 text-sm text-gray-400">
            {['About', 'Contact', 'Privacy Policy', 'Terms of Service'].map(item => (
              <li key={item} className="hover:text-red-500 cursor-pointer" onClick={() => onNavigate(item.toLowerCase().replace(' ', '-'))}>{item}</li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-4 text-white">Newsletter</h4>
          <p className="text-sm text-gray-400 mb-4">Get updates on new tools.</p>
          <div className="flex gap-2">
            <input 
              type="email" 
              placeholder="Email address" 
              className="flex-1 px-3 py-2 rounded-lg border border-red-500/20 bg-black/40 text-white text-sm focus:ring-2 focus:ring-red-500 outline-none"
            />
            <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors">
              Join
            </button>
          </div>
        </div>
      </div>
      <div className="mt-12 pt-8 border-t border-red-500/10 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} ToolVerse. All rights reserved.
      </div>
    </div>
  </footer>
);

interface ToolCardProps {
  tool: Tool;
  onClick: () => void | Promise<void>;
  user: User | null;
  isFavorite: boolean;
  onToggleFavorite: (toolId: string) => void | Promise<void>;
  key?: React.Key;
}

const ToolCard = ({ 
  tool, 
  onClick, 
  user, 
  isFavorite, 
  onToggleFavorite 
}: ToolCardProps) => {
  const Icon = tool.icon;
  const category = CATEGORIES.find(c => c.name === tool.category);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) return;
    onToggleFavorite(tool.id);
  };
  
  // Map category colors to background classes
  const bgColors: Record<string, string> = {
    'PDF': 'bg-red-50 dark:bg-red-900/10 group-hover:bg-red-100 dark:group-hover:bg-red-900/20',
    'Image': 'bg-blue-50 dark:bg-blue-900/10 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/20',
    'Video': 'bg-purple-50 dark:bg-purple-900/10 group-hover:bg-purple-100 dark:group-hover:bg-purple-900/20',
    'Social': 'bg-pink-50 dark:bg-pink-900/10 group-hover:bg-pink-100 dark:group-hover:bg-pink-900/20',
    'Calculator': 'bg-green-50 dark:bg-green-900/10 group-hover:bg-green-100 dark:group-hover:bg-green-900/20',
    'Text': 'bg-orange-50 dark:bg-orange-900/10 group-hover:bg-orange-100 dark:group-hover:bg-orange-900/20',
    'Developer': 'bg-indigo-50 dark:bg-indigo-900/10 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/20',
  };

  const iconColors: Record<string, string> = {
    'PDF': 'text-red-600 dark:text-red-400 group-hover:bg-red-600',
    'Image': 'text-blue-600 dark:text-blue-400 group-hover:bg-blue-600',
    'Video': 'text-purple-600 dark:text-purple-400 group-hover:bg-purple-600',
    'Social': 'text-pink-600 dark:text-pink-400 group-hover:bg-pink-600',
    'Calculator': 'text-green-600 dark:text-green-400 group-hover:bg-green-600',
    'Text': 'text-orange-600 dark:text-orange-400 group-hover:bg-orange-600',
    'Developer': 'text-indigo-600 dark:text-indigo-400 group-hover:bg-indigo-600',
  };

  const shadowColors: Record<string, string> = {
    'PDF': 'group-hover:shadow-red-500/20',
    'Image': 'group-hover:shadow-blue-500/20',
    'Video': 'group-hover:shadow-purple-500/20',
    'Social': 'group-hover:shadow-pink-500/20',
    'Calculator': 'group-hover:shadow-green-500/20',
    'Text': 'group-hover:shadow-orange-500/20',
    'Developer': 'group-hover:shadow-indigo-500/20',
  };

  const isTrending = (tool.popularity || 0) > 1000;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      onClick={onClick}
      className="group shiny-card red-border premium-card rounded-2xl cursor-pointer transition-all duration-300 overflow-hidden relative p-5 text-center"
    >
      {isTrending && (
        <div className="absolute top-3 left-3 z-10">
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-yellow-400 text-black text-[9px] font-black uppercase tracking-wider border border-yellow-500 shadow-sm">
            <TrendingUp size={10} />
            Trending
          </div>
        </div>
      )}
      
      <div className="absolute top-4 right-4 z-10">
        <button 
          onClick={toggleFavorite}
          className={cn(
            "transition-colors p-1.5 rounded-full bg-black/50 border border-red-500/30 backdrop-blur-sm",
            isFavorite ? "text-red-500" : "text-yellow-400 hover:text-red-500"
          )}
        >
          <Heart size={14} className={isFavorite ? "fill-current" : ""} />
        </button>
      </div>

      <div className="mb-4 flex justify-center">
        <div className="icon-animate w-20 h-20 flex items-center justify-center rounded-xl premium-icon-container bg-black/40">
          <Icon size={36} className="text-yellow-400" />
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-center gap-2 mb-1">
          <span className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full bg-red-900/30 text-red-400 border border-red-500/30">
            {tool.category}
          </span>
        </div>
        <h3 className="font-bold text-yellow-400 text-lg group-hover:text-yellow-300 transition-colors">
          {tool.name}
        </h3>
        <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
          {tool.description}
        </p>
      </div>
    </motion.div>
  );
};

// --- Tool Views ---

const WordCounter = () => {
  const [text, setText] = useState('');
  const stats = useMemo(() => ({
    words: text.trim() ? text.trim().split(/\s+/).length : 0,
    chars: text.length,
    lines: text.split('\n').length,
    readingTime: Math.ceil(text.trim().split(/\s+/).length / 200)
  }), [text]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Words', value: stats.words },
          { label: 'Characters', value: stats.chars },
          { label: 'Lines', value: stats.lines },
          { label: 'Reading Time', value: `${stats.readingTime} min` },
        ].map(stat => (
          <div key={stat.label} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border dark:border-slate-800 text-center">
            <div className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{stat.value}</div>
            <div className="text-xs text-slate-500 uppercase tracking-wider font-semibold mt-1">{stat.label}</div>
          </div>
        ))}
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type or paste your text here..."
        className="w-full h-64 p-6 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none shadow-inner"
      />
      <div className="flex justify-end gap-3">
        <button 
          onClick={() => setText('')}
          className="px-6 py-2 rounded-xl border dark:border-slate-800 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          Clear
        </button>
        <button 
          onClick={() => navigator.clipboard.writeText(text)}
          className="px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/20"
        >
          Copy Text
        </button>
      </div>
    </div>
  );
};

const QRCodeGenerator = () => {
  const [value, setValue] = useState('https://toolverse.app');
  const [size, setSize] = useState(256);
  const [fgColor, setFgColor] = useState('#ff0000');
  const [bgColor, setBgColor] = useState('#000000');
  const [level, setLevel] = useState<'L' | 'M' | 'Q' | 'H'>('H');
  const [includeMargin, setIncludeMargin] = useState(true);

  const downloadQR = () => {
    const svg = document.getElementById('qr-code-svg');
    if (!svg) return;
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    img.onload = () => {
      canvas.width = size;
      canvas.height = size;
      ctx!.fillStyle = bgColor;
      ctx!.fillRect(0, 0, size, size);
      ctx?.drawImage(img, 0, 0);
      const pngFile = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.download = `toolverse-qr-${Date.now()}.png`;
      downloadLink.href = pngFile;
      downloadLink.click();
    };
    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Controls Panel */}
        <div className="lg:col-span-7 bg-black/60 backdrop-blur-xl p-8 rounded-[2rem] border border-red-500/10 shadow-2xl space-y-8">
          <div className="flex items-center gap-4 mb-2">
            <div className="w-12 h-12 bg-red-600/10 rounded-2xl flex items-center justify-center text-red-500 border border-red-500/20">
              <Scan size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter">QR Engine</h2>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.3em]">Configure static & dynamic signals</p>
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Encoded Content</label>
            <div className="relative group">
              <textarea
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="Enter URL or payload text..."
                className="w-full h-32 px-6 py-4 rounded-2xl border border-white/5 bg-black/40 text-white placeholder:text-gray-700 focus:ring-2 focus:ring-red-600/50 outline-none resize-none transition-all font-medium"
              />
              <div className="absolute top-4 right-4 text-gray-800 group-focus-within:text-red-900 transition-colors">
                <Code size={18} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Dimensions (px)</label>
              <div className="relative">
                <input
                  type="number"
                  min="64"
                  max="1024"
                  value={size}
                  onChange={(e) => setSize(Number(e.target.value))}
                  className="w-full pl-6 pr-12 py-3 rounded-xl border border-white/5 bg-black/40 text-white outline-none focus:border-red-500/50 transition-all font-bold"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-black text-gray-600 uppercase">Pixels</span>
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Error Correction</label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as any)}
                className="w-full px-6 py-3 rounded-xl border border-white/5 bg-black/40 text-white outline-none focus:border-red-500/50 transition-all font-bold appearance-none cursor-pointer"
              >
                <option value="L">L - Minimal (7%)</option>
                <option value="M">M - Balanced (15%)</option>
                <option value="Q">Q - High Resilience (25%)</option>
                <option value="H">H - Maximum (30%)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Foreground Tint</label>
              <div className="flex gap-2 p-2 bg-black/40 rounded-xl border border-white/5">
                <input
                  type="color"
                  value={fgColor}
                  onChange={(e) => setFgColor(e.target.value)}
                  className="w-12 h-10 rounded-lg cursor-pointer border-none bg-transparent"
                />
                <input
                  type="text"
                  value={fgColor.toUpperCase()}
                  onChange={(e) => setFgColor(e.target.value)}
                  className="flex-1 bg-transparent text-white text-xs font-mono font-bold outline-none uppercase"
                />
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Backdrop Color</label>
              <div className="flex gap-2 p-2 bg-black/40 rounded-xl border border-white/5">
                <input
                  type="color"
                  value={bgColor}
                  onChange={(e) => setBgColor(e.target.value)}
                  className="w-12 h-10 rounded-lg cursor-pointer border-none bg-transparent"
                />
                <input
                  type="text"
                  value={bgColor.toUpperCase()}
                  onChange={(e) => setBgColor(e.target.value)}
                  className="flex-1 bg-transparent text-white text-xs font-mono font-bold outline-none uppercase"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 p-4 bg-red-600/5 rounded-2xl border border-red-500/10">
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-10 h-6 rounded-full relative transition-colors cursor-pointer",
                includeMargin ? "bg-red-600" : "bg-gray-800"
              )} onClick={() => setIncludeMargin(!includeMargin)}>
                <div className={cn(
                  "absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm",
                  includeMargin ? "left-5" : "left-1"
                )} />
              </div>
              <span className="text-[10px] font-black text-white uppercase tracking-widest">Isolated Margin</span>
            </div>
            <p className="text-[9px] text-gray-500 font-bold uppercase tracking-wider leading-tight">
              Adds a 4-module quiet zone buffer for <br /> improved scan reliability.
            </p>
          </div>
        </div>

        {/* Live Preview Display */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-black/80 backdrop-blur-2xl p-10 rounded-[3rem] border border-white/5 shadow-2xl flex flex-col items-center justify-center space-y-8 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent opacity-50" />
            
            <div className="relative z-10 w-full flex justify-center">
              <div 
                className="p-8 rounded-[2rem] bg-white/5 border border-white/10 shadow-[0_0_50px_-12px_rgba(255,0,0,0.3)] transition-transform duration-500 group-hover:scale-105"
                style={{ backgroundColor: bgColor }}
              >
                <QRCodeSVG
                  id="qr-code-svg"
                  value={value || ' '}
                  size={Math.min(size, 300)}
                  fgColor={fgColor}
                  bgColor={bgColor}
                  level={level}
                  includeMargin={includeMargin}
                  className="rounded-lg"
                />
              </div>
            </div>

            <div className="relative z-10 text-center space-y-2">
              <h3 className="text-xl font-black text-white italic uppercase tracking-tighter">Live Signal</h3>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.3em]">Payload verified & valid</p>
            </div>
            
            <button
              onClick={downloadQR}
              className="relative z-10 w-full group py-5 bg-red-600 hover:bg-red-500 text-white rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-red-600/20 active:scale-95 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer" />
              <Download size={20} className="group-hover:bounce-y" />
              <span className="font-black uppercase italic tracking-widest text-sm">Download High-Res PNG</span>
            </button>

            <div className="relative z-10 flex gap-4 w-full">
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(value);
                  alert('Content copied to clipboard!');
                }}
                className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-all flex items-center justify-center gap-2 group"
              >
                <Copy size={16} className="text-gray-400 group-hover:text-red-500" />
                <span className="text-[10px] font-black uppercase tracking-widest">Copy Source</span>
              </button>
              <button 
                onClick={() => setValue('')}
                className="py-3 px-6 bg-white/5 hover:bg-white/10 text-white rounded-xl border border-white/10 transition-all flex items-center justify-center gap-2 group"
              >
                <Trash2 size={16} className="text-gray-400 group-hover:text-red-500" />
              </button>
            </div>
          </div>

          <div className="bg-red-600/5 border border-red-500/10 p-6 rounded-[2rem] flex items-start gap-4">
            <div className="w-10 h-10 bg-red-600/20 rounded-xl flex items-center justify-center text-red-500 shrink-0">
              <Shield size={20} />
            </div>
            <div className="space-y-1">
              <h4 className="text-xs font-black text-white uppercase italic tracking-widest">Enterprise Ready</h4>
              <p className="text-[10px] text-gray-500 font-bold leading-relaxed uppercase tracking-widest">
                Vectors generated client-side for maximum privacy. No data ever leaves your browser signature.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MarkdownEditor = () => {
  const [markdown, setMarkdown] = useState('# Hello World\n\nStart typing your **markdown** here...');
  const previewRef = useRef<HTMLDivElement>(null);

  const copyHtml = () => {
    if (previewRef.current) {
      const html = previewRef.current.innerHTML;
      navigator.clipboard.writeText(html);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-250px)] min-h-[600px]">
      <div className="flex flex-col space-y-4 h-full">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
            <Edit3 size={16} className="text-indigo-500" />
            Markdown Input
          </label>
        </div>
        <textarea
          value={markdown}
          onChange={(e) => setMarkdown(e.target.value)}
          className="flex-1 w-full p-6 font-mono text-sm rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none shadow-inner"
          placeholder="Enter markdown here..."
        />
      </div>
      <div className="flex flex-col space-y-4 h-full">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
            <Eye size={16} className="text-indigo-500" />
            Live Preview
          </label>
          <button 
            onClick={copyHtml}
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-all"
          >
            <Copy size={14} />
            Copy HTML
          </button>
        </div>
        <div className="flex-1 w-full p-6 rounded-2xl border dark:border-slate-800 bg-white overflow-auto shadow-sm prose prose-slate dark:prose-invert max-w-none">
          <div ref={previewRef} className="markdown-body">
            <Markdown>{markdown}</Markdown>
          </div>
        </div>
      </div>
    </div>
  );
};

const JSONFormatter = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');

  const format = () => {
    try {
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed, null, 2));
      setError('');
    } catch (e: any) {
      setError(e.message);
      setOutput('');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Input JSON</label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="w-full h-96 p-4 font-mono text-sm rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
        />
        <button 
          onClick={format}
          className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors"
        >
          Format JSON
        </button>
      </div>
      <div className="space-y-4">
        <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Formatted Output</label>
        <div className="relative">
          <pre className="w-full h-96 p-4 font-mono text-sm rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white overflow-auto">
            {error ? <span className="text-red-500">{error}</span> : output}
          </pre>
          {output && (
            <button 
              onClick={() => navigator.clipboard.writeText(output)}
              className="absolute top-4 right-4 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              <Copy size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

const BMICalculator = () => {
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(170);
  
  const bmi = useMemo(() => {
    const h = height / 100;
    return (weight / (h * h)).toFixed(1);
  }, [weight, height]);

  const category = useMemo(() => {
    const val = parseFloat(bmi);
    if (val < 18.5) return { label: 'Underweight', color: 'text-blue-500' };
    if (val < 25) return { label: 'Normal', color: 'text-green-500' };
    if (val < 30) return { label: 'Overweight', color: 'text-yellow-500' };
    return { label: 'Obese', color: 'text-red-500' };
  }, [bmi]);

  return (
    <div className="max-w-md mx-auto p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border dark:border-slate-800">
      <div className="text-center mb-8">
        <div className={cn("text-6xl font-black mb-2", category.color)}>{bmi}</div>
        <div className="text-lg font-bold text-slate-600 dark:text-slate-400 uppercase tracking-widest">{category.label}</div>
      </div>
      <div className="space-y-8">
        <div className="space-y-4">
          <div className="flex justify-between text-sm font-bold">
            <span className="dark:text-white">Weight</span>
            <span className="text-indigo-600">{weight} kg</span>
          </div>
          <input 
            type="range" min="30" max="200" value={weight} 
            onChange={(e) => setWeight(parseInt(e.target.value))}
            className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
        </div>
        <div className="space-y-4">
          <div className="flex justify-between text-sm font-bold">
            <span className="dark:text-white">Height</span>
            <span className="text-indigo-600">{height} cm</span>
          </div>
          <input 
            type="range" min="100" max="250" value={height} 
            onChange={(e) => setHeight(parseInt(e.target.value))}
            className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
        </div>
      </div>
    </div>
  );
};

const PlaceholderTool = ({ tool }: { tool: Tool }) => (
    <div className="text-center py-20 space-y-6">
    <div className="w-24 h-24 bg-red-900/20 rounded-3xl flex items-center justify-center text-yellow-400 mx-auto border border-red-500/30">
      <tool.icon size={48} />
    </div>
    <div className="space-y-2">
      <h2 className="text-3xl font-bold text-white">{tool.name}</h2>
      <p className="text-gray-400 max-w-md mx-auto">
        This tool is currently in development. We're working hard to bring you the best {tool.category.toLowerCase()} tools!
      </p>
    </div>
    <div className="p-8 border-2 border-dashed border-red-500/20 rounded-3xl max-w-xl mx-auto glass-overlay">
      <div className="flex flex-col items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-black/40 flex items-center justify-center text-red-500">
          <ArrowLeft size={32} />
        </div>
        <p className="text-sm font-medium text-gray-400">Drag & drop files here to get started</p>
        <button className="px-8 py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20">
          Select Files
        </button>
      </div>
    </div>
  </div>
);

const CaseConverter = () => {
  const [text, setText] = useState('');
  const convert = (type: string) => {
    switch (type) {
      case 'upper': setText(text.toUpperCase()); break;
      case 'lower': setText(text.toLowerCase()); break;
      case 'title': setText(text.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase())); break;
      case 'sentence': setText(text.charAt(0).toUpperCase() + text.slice(1).toLowerCase()); break;
    }
  };
  return (
    <div className="space-y-6">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type or paste your text here..."
        className="w-full h-64 p-6 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
      />
      <div className="flex flex-wrap gap-3">
        {['upper', 'lower', 'title', 'sentence'].map(type => (
          <button 
            key={type}
            onClick={() => convert(type)}
            className="px-6 py-2 rounded-xl border dark:border-slate-800 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors capitalize"
          >
            {type} Case
          </button>
        ))}
        <button 
          onClick={() => navigator.clipboard.writeText(text)}
          className="px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors ml-auto"
        >
          Copy Result
        </button>
      </div>
    </div>
  );
};

const Base64Tool = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const encode = () => {
    try { setOutput(btoa(input)); } catch (e) { setOutput('Invalid input for encoding'); }
  };
  const decode = () => {
    try { setOutput(atob(input)); } catch (e) { setOutput('Invalid Base64 string'); }
  };
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter text or Base64..."
          className="w-full h-64 p-4 font-mono text-sm rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
        />
        <div className="flex gap-3">
          <button onClick={encode} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700">Encode</button>
          <button onClick={decode} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700">Decode</button>
        </div>
      </div>
      <div className="space-y-4">
        <div className="w-full h-64 p-4 font-mono text-sm rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white overflow-auto break-all">
          {output || <span className="text-slate-500 italic">Output will appear here...</span>}
        </div>
        <button 
          onClick={() => navigator.clipboard.writeText(output)}
          className="w-full py-3 border dark:border-slate-800 dark:text-white rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800"
        >
          Copy Output
        </button>
      </div>
    </div>
  );
};

const URLEncoder = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');

  const encode = () => {
    try {
      setOutput(encodeURIComponent(input));
    } catch (e) {
      setOutput('Error encoding URL');
    }
  };

  const decode = () => {
    try {
      setOutput(decodeURIComponent(input));
    } catch (e) {
      setOutput('Error decoding URL: Invalid format');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter URL or text to encode/decode..."
          className="w-full h-64 p-4 font-mono text-sm rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
        />
        <div className="flex gap-3">
          <button onClick={encode} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20">
            Encode URL
          </button>
          <button onClick={decode} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20">
            Decode URL
          </button>
        </div>
      </div>
      <div className="space-y-4">
        <div className="w-full h-64 p-4 font-mono text-sm rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white overflow-auto break-all">
          {output || <span className="text-slate-500 italic">Output will appear here...</span>}
        </div>
        <button 
          onClick={() => {
            if (output) {
              navigator.clipboard.writeText(output);
            }
          }}
          disabled={!output}
          className="w-full py-3 border dark:border-slate-800 dark:text-white rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 transition-all"
        >
          Copy Output
        </button>
      </div>
    </div>
  );
};

const ImageCompressor = () => {
  const [file, setFile] = useState<File | null>(null);
  const [quality, setQuality] = useState(0.6);
  const [filter, setFilter] = useState<string>('none');
  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [result, setResult] = useState<{ url: string; size: number; originalSize: number } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected && selected.type.startsWith('image/')) {
      setFile(selected);
      setPreviewUrl(URL.createObjectURL(selected));
      setResult(null);
    }
  };

  const getFilterStyle = (f: string) => {
    switch (f) {
      case 'grayscale': return 'grayscale(100%)';
      case 'sepia': return 'sepia(100%)';
      case 'invert': return 'invert(100%)';
      case 'brightness': return 'brightness(150%)';
      case 'contrast': return 'contrast(150%)';
      case 'saturate': return 'saturate(200%)';
      case 'hue-rotate': return 'hue-rotate(90deg)';
      case 'blur': return 'blur(4px)';
      default: return 'none';
    }
  };

  const compressImage = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      await new Promise((resolve) => (img.onload = resolve));

      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        ctx.filter = getFilterStyle(filter);
        ctx.drawImage(img, 0, 0);
      }

      const blob = await new Promise<Blob | null>((resolve) => 
        canvas.toBlob((b) => resolve(b), file.type, quality)
      );

      if (blob) {
        setResult({
          url: URL.createObjectURL(blob),
          size: blob.size,
          originalSize: file.size
        });
      }
    } catch (error) {
      console.error("Compression error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload Image</label>
          <div className="relative h-64 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500 bg-slate-50 dark:bg-slate-900/50">
            {previewUrl ? (
              <div className="relative w-full h-full flex items-center justify-center p-4">
                <img 
                  src={previewUrl} 
                  alt="Preview" 
                  className="max-w-full max-h-full object-contain rounded-xl shadow-lg transition-all duration-300"
                  style={{ filter: getFilterStyle(filter) }}
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <p className="text-white font-bold text-sm">Click to change image</p>
                </div>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={40} />
                <p className="text-sm font-medium text-slate-500">Click or drag image to upload</p>
                <p className="text-xs text-slate-400 mt-1">Supports JPG, PNG, WebP</p>
              </div>
            )}
            <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
          </div>
          {file && (
            <div className="flex items-center justify-between px-2">
              <span className="text-xs font-medium text-slate-500 truncate max-w-[200px]">{file.name}</span>
              <span className="text-xs font-bold text-indigo-600">{(file.size / 1024).toFixed(1)} KB</span>
            </div>
          )}
        </div>

        {file && (
          <div className="space-y-6">
            <div className="space-y-3">
              <label className="text-sm font-bold dark:text-white">Compression Level</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'Low', val: 0.9 },
                  { label: 'Medium', val: 0.6 },
                  { label: 'High', val: 0.3 }
                ].map((level) => (
                  <button
                    key={level.label}
                    onClick={() => setQuality(level.val)}
                    className={cn(
                      "py-3 rounded-xl font-bold text-sm transition-all border",
                      quality === level.val 
                        ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20" 
                        : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-indigo-500"
                    )}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-bold dark:text-white">Image Filter</label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {[
                  { label: 'None', val: 'none' },
                  { label: 'Grayscale', val: 'grayscale' },
                  { label: 'Sepia', val: 'sepia' },
                  { label: 'Invert', val: 'invert' },
                  { label: 'Bright', val: 'brightness' },
                  { label: 'Contrast', val: 'contrast' },
                  { label: 'Saturate', val: 'saturate' },
                  { label: 'Hue', val: 'hue-rotate' },
                  { label: 'Blur', val: 'blur' }
                ].map((f) => (
                  <button
                    key={f.label}
                    onClick={() => setFilter(f.val)}
                    className={cn(
                      "py-2.5 rounded-xl font-bold text-[10px] uppercase tracking-wider transition-all border",
                      filter === f.val 
                        ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20" 
                        : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-indigo-500"
                    )}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={compressImage}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <FileArchive size={20} />
              )}
              Compress Image
            </button>
          </div>
        )}
      </div>

      {result && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-bold dark:text-white">Compression Complete!</h3>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-slate-500 line-through">{(result.originalSize / 1024).toFixed(1)} KB</span>
                <span className="text-green-600 font-bold">{(result.size / 1024).toFixed(1)} KB</span>
                <span className="px-2 py-0.5 bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded text-xs font-bold">
                  -{Math.round((1 - result.size / result.originalSize) * 100)}%
                </span>
              </div>
            </div>
            <a
              href={result.url}
              download={`compressed_${file?.name}`}
              className="p-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all shadow-lg shadow-green-500/20"
            >
              <Download size={20} />
            </a>
          </div>
          <div className="aspect-video rounded-2xl overflow-hidden border dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
            <img src={result.url} alt="Compressed" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
        </motion.div>
      )}
    </div>
  );
};

const PlagiarismChecker = () => {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<{ score: number; details: string; sources: string[] } | null>(null);

  const checkPlagiarism = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setReport(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const prompt = `Analyze the following text for plagiarism. 
      Use Google Search to find matching content online.
      Provide a similarity score (0-100, where 100 means fully plagiarized), a brief explanation of findings, and a list of potential source URLs.
      
      Format the response as JSON:
      {
        "score": number,
        "details": "string",
        "sources": ["url1", "url2"]
      }
      
      Text to analyze:
      ${text}`;

      const result = await (ai.models as any).generateContent({
        model: "gemini-3.1-flash-lite-preview",
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        tools: [{ googleSearch: {} }]
      });

      const responseText = result.text;
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        setReport(JSON.parse(jsonMatch[0]));
      } else {
        throw new Error("Invalid response format from AI");
      }
    } catch (error) {
      console.error("Plagiarism Check Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-bold dark:text-white text-slate-700">Paste Text to Check</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Paste the content you want to check for originality..."
            className="w-full h-64 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
          />
        </div>
        <button
          onClick={checkPlagiarism}
          disabled={loading || !text.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Scanning for Plagiarism...
            </>
          ) : (
            <>
              <Search size={20} />
              Check Originality
            </>
          )}
        </button>
      </div>

      {report && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-8"
        >
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="relative w-32 h-32 flex-shrink-0">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="64" cy="64" r="58"
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="8"
                  className="text-slate-100 dark:text-slate-800"
                />
                <circle
                  cx="64" cy="64" r="58"
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="8"
                  strokeDasharray={364.4}
                  strokeDashoffset={364.4 * (1 - report.score / 100)}
                  className={cn(
                    "transition-all duration-1000",
                    report.score < 15 ? "text-green-500" : report.score < 40 ? "text-yellow-500" : "text-red-500"
                  )}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-black dark:text-white">{report.score}%</span>
                <span className="text-[10px] font-bold text-slate-500 uppercase">Similarity</span>
              </div>
            </div>
            <div className="flex-1 space-y-2 text-center md:text-left">
              <h3 className="text-xl font-bold dark:text-white">Analysis Report</h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                {report.details}
              </p>
            </div>
          </div>

          {report.sources.length > 0 && (
            <div className="space-y-4 pt-6 border-t dark:border-slate-800">
              <h4 className="text-sm font-bold uppercase tracking-widest text-slate-500">Potential Sources</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {report.sources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800 hover:border-indigo-500 transition-all group"
                  >
                    <Globe size={16} className="text-slate-400 group-hover:text-indigo-500" />
                    <span className="text-xs font-medium dark:text-white truncate flex-1">{source}</span>
                    <ExternalLink size={12} className="text-slate-300" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};

const PercentageCalc = () => {
  const [val1, setVal1] = useState(0);
  const [val2, setVal2] = useState(0);
  const result = useMemo(() => (val1 / 100) * val2, [val1, val2]);
  return (
    <div className="max-w-md mx-auto p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border dark:border-slate-800 space-y-8">
      <div className="text-center">
        <div className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-2">Result</div>
        <div className="text-5xl font-black text-indigo-600 dark:text-indigo-400">{result.toLocaleString()}</div>
      </div>
      <div className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-bold dark:text-white">What is {val1}%</label>
          <input 
            type="number" value={val1} onChange={(e) => setVal1(Number(e.target.value))}
            className="w-full p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold dark:text-white">Of {val2}</label>
          <input 
            type="number" value={val2} onChange={(e) => setVal2(Number(e.target.value))}
            className="w-full p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>
    </div>
  );
};

const TextToSpeech = () => {
  const [activeTab, setActiveTab] = useState<'tts' | 'stt'>('tts');
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [transcript, setTranscript] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const generateSpeech = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const binary = atob(base64Audio);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      }
    } catch (error) {
      console.error("TTS Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!file.type.startsWith('audio/')) return;
    setLoading(true);
    setTranscript('');
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-preview',
          contents: [{
            parts: [
              { inlineData: { data: base64Data, mimeType: file.type } },
              { text: "Transcribe this audio accurately. Provide only the transcript text." }
            ]
          }]
        });
        setTranscript(response.text);
      };
    } catch (error) {
      console.error("Transcription Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileUpload(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit mx-auto">
        <button
          onClick={() => setActiveTab('tts')}
          className={cn(
            "px-6 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2",
            activeTab === 'tts' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          <Volume2 size={16} />
          Text to Speech
        </button>
        <button
          onClick={() => setActiveTab('stt')}
          className={cn(
            "px-6 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2",
            activeTab === 'stt' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          <Mic size={16} />
          Transcription
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'tts' ? (
          <motion.div
            key="tts"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
          >
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter text to convert to speech..."
              className="w-full h-48 p-6 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none text-lg"
            />
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              {audioUrl ? (
                <audio controls src={audioUrl} className="w-full sm:w-auto h-10" />
              ) : (
                <div className="hidden sm:block text-slate-400 text-sm italic">
                  Audio will appear here after generation
                </div>
              )}
              <button
                onClick={generateSpeech}
                disabled={loading || !text.trim()}
                className="w-full sm:w-auto px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center gap-2"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Wand2 size={18} />
                )}
                {loading ? 'Generating...' : 'Generate Speech'}
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="stt"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <div
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
              className={cn(
                "relative h-64 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center transition-all group",
                isDragging ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/10" : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
              )}
            >
              <input
                type="file"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                className="absolute inset-0 opacity-0 cursor-pointer"
                accept="audio/*"
              />
              <div className="text-center space-y-4">
                <div className={cn(
                  "w-16 h-16 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110",
                  isDragging ? "bg-indigo-600 text-white" : "bg-indigo-100 dark:bg-indigo-900/20 text-indigo-600"
                )}>
                  <Upload size={32} />
                </div>
                <div>
                  <p className="font-bold dark:text-white text-lg">Drag & drop audio file</p>
                  <p className="text-sm text-slate-500">or click to browse (MP3, WAV, M4A)</p>
                </div>
              </div>
            </div>

            {loading && (
              <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 shadow-xl">
                <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-slate-500 font-medium animate-pulse">Gemini is transcribing your audio...</p>
              </div>
            )}

            {transcript && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-bold dark:text-white uppercase text-xs tracking-widest flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    Transcript Result
                  </h3>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(transcript);
                      }}
                      className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-500 transition-colors flex items-center gap-2 text-xs font-bold"
                    >
                      <Copy size={16} />
                      Copy
                    </button>
                  </div>
                </div>
                <div className="prose dark:prose-invert max-w-none">
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-wrap text-lg">
                    {transcript}
                  </p>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const PPTtoPDF = () => {
  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6 text-center">
        <Presentation size={48} className="mx-auto text-indigo-600" />
        <h2 className="text-2xl font-bold dark:text-white">PPT to PDF</h2>
        <p className="text-slate-500">PowerPoint conversion is a complex process. We are working on a high-fidelity client-side converter. Check back soon!</p>
      </div>
    </div>
  );
};

const UnlockPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
      setResultUrl(null);
    } else {
      setError('Please upload a valid PDF file.');
    }
  };

  const unlockPdf = async (useBackend = false) => {
    if (!file) return;
    setLoading(true);
    setError(null);
    setResultUrl(null);

    if (useBackend) {
      const formData = new FormData();
      formData.append("pdf", file);
      formData.append("password", password);

      try {
        const response = await fetch("/api/pdf/unlock", {
          method: "POST",
          body: formData
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || "Failed to unlock PDF via server.");
        }

        const blob = await response.blob();
        setResultUrl(URL.createObjectURL(blob));
      } catch (err: any) {
        console.error("Backend Unlock Error:", err);
        setError(err.message || "Failed to unlock PDF via server. Check your password or API configuration.");
      } finally {
        setLoading(false);
      }
      return;
    }

    try {
      const arrayBuffer = await file.arrayBuffer();
      
      // Attempt to load the PDF with the provided password
      const pdfDoc = await PDFDocument.load(arrayBuffer, { 
        password: password,
        ignoreEncryption: false 
      } as any);

      // Save the PDF (this removes the encryption if it was successfully opened)
      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err: any) {
      console.error("Client Unlock Error:", err);
      if (err.message.includes('password')) {
        setError('Incorrect password. Please try again.');
      } else {
        setError('Client-side unlock failed. This PDF might use an unsupported encryption type. Try the Advanced Engine below.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <Unlock size={48} className="mx-auto text-indigo-600" />
          <h2 className="text-2xl font-bold dark:text-white">Unlock PDF</h2>
          <p className="text-slate-500 text-sm">Remove passwords and restrictions from your PDF files.</p>
        </div>

        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload Protected PDF</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-indigo-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
                <button onClick={() => setFile(null)} className="text-xs text-red-500 mt-2 hover:underline">Remove</button>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-xs text-slate-500">Click or drag protected PDF here</p>
              </div>
            )}
            <input 
              type="file" 
              onChange={handleFileChange} 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              accept=".pdf" 
            />
          </div>
        </div>

        {file && (
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">PDF Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter PDF password..."
                className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white transition-all"
              />
            </div>
          </div>
        )}

        {error && (
          <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl flex items-center gap-3 text-red-600 dark:text-red-400 text-sm">
            <AlertCircle size={18} />
            <div className="flex-1">
              <p>{error}</p>
              {error.includes('Advanced Engine') && (
                <button 
                  onClick={() => unlockPdf(true)}
                  className="mt-2 text-xs font-bold underline hover:no-underline"
                >
                  Try Advanced Engine (Server-side)
                </button>
              )}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => unlockPdf(false)}
            disabled={!file || !password || loading}
            className="py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw className="animate-spin" size={20} /> : <Zap size={20} />}
            Standard Unlock
          </button>
          <button
            onClick={() => unlockPdf(true)}
            disabled={!file || !password || loading}
            className="py-4 bg-slate-800 text-white rounded-2xl font-bold hover:bg-slate-900 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw className="animate-spin" size={20} /> : <Cpu size={20} />}
            Advanced Engine
          </button>
        </div>

        {resultUrl && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-2xl text-center space-y-4"
          >
            <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400 font-bold">
              <CheckCircle size={20} />
              PDF Successfully Unlocked!
            </div>
            <a 
              href={resultUrl} 
              download={`unlocked_${file?.name}`}
              className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20"
            >
              <Download size={18} />
              Download Unlocked PDF
            </a>
          </motion.div>
        )}
      </div>
    </div>
  );
};

const PDFSizeReducer = () => {
  return <CompressPDF />;
};

const ExcelToPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const convertToPdf = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer);
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const html = XLSX.utils.sheet_to_html(worksheet);

      const element = document.createElement('div');
      element.innerHTML = html;
      element.style.padding = '20px';
      
      const opt = {
        margin: 0.5,
        filename: file.name.replace('.xlsx', '.pdf').replace('.xls', '.pdf'),
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'landscape' as const }
      };

      const pdfBlob = await html2pdf().from(element).set(opt).output('blob');
      setResultUrl(URL.createObjectURL(pdfBlob));
    } catch (err: any) {
      setError('Conversion Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload Excel File (.xlsx, .xls)</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <Table className="mx-auto mb-2 text-green-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag Excel file to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".xlsx,.xls" />
          </div>
        </div>

        {file && (
          <button
            onClick={convertToPdf}
            disabled={loading}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <FileText size={20} />}
            Convert to PDF
          </button>
        )}
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download={file?.name.replace('.xlsx', '.pdf')} className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const HTMLToPDF = () => {
  const [html, setHtml] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const convertToPdf = async () => {
    if (!html.trim()) return;
    setLoading(true);
    try {
      const element = document.createElement('div');
      element.innerHTML = html;
      const pdfBlob = await html2pdf().from(element).output('blob');
      setResultUrl(URL.createObjectURL(pdfBlob));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-bold dark:text-white">Enter HTML Content</label>
          <textarea
            value={html}
            onChange={(e) => setHtml(e.target.value)}
            placeholder="<h1>Hello World</h1><p>This is a PDF generated from HTML.</p>"
            className="w-full h-64 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 dark:text-white font-mono text-sm outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button
          onClick={convertToPdf}
          disabled={loading || !html.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Globe size={20} />}
          Generate PDF from HTML
        </button>
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download="webpage.pdf" className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const PDFEditor = () => {
  const [file, setFile] = useState<File | null>(null);
  const [textToAdd, setTextToAdd] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const editPdf = async () => {
    if (!file || !textToAdd) return;
    setLoading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      const pages = pdfDoc.getPages();
      const firstPage = pages[0];
      const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
      
      firstPage.drawText(textToAdd, {
        x: 50,
        y: 50,
        size: 12,
        font,
        color: rgb(0, 0, 0),
      });

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF to Edit</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white">Text to Add (Bottom Left)</label>
              <input
                type="text"
                value={textToAdd}
                onChange={(e) => setTextToAdd(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <button
              onClick={editPdf}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Edit3 size={20} />}
              Apply Changes
            </button>
          </div>
        )}
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download="edited_document.pdf" className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download Edited PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const SignPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  useEffect(() => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
      }
    }
  }, [file]);

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      ctx?.beginPath();
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e) ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = ('touches' in e) ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearCanvas = () => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      ctx?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }
  };

  const signPdf = async () => {
    if (!file || !canvasRef.current) return;
    setLoading(true);
    setError(null);

    try {
      const signatureDataUrl = canvasRef.current.toDataURL('image/png');
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      const signatureImg = await pdfDoc.embedPng(signatureDataUrl);
      
      const pages = pdfDoc.getPages();
      const lastPage = pages[pages.length - 1];
      const { width, height } = lastPage.getSize();

      lastPage.drawImage(signatureImg, {
        x: width - 200,
        y: 50,
        width: 150,
        height: 75,
      });

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err: any) {
      setError('Error signing PDF: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF to Sign</label>
          <div className="relative h-32 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-bold dark:text-white">Draw Your Signature</label>
                <button onClick={clearCanvas} className="text-xs text-red-500 hover:underline">Clear</button>
              </div>
              <canvas
                ref={canvasRef}
                width={400}
                height={150}
                onMouseDown={startDrawing}
                onMouseUp={stopDrawing}
                onMouseMove={draw}
                onTouchStart={startDrawing}
                onTouchEnd={stopDrawing}
                onTouchMove={draw}
                className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-xl cursor-crosshair"
              />
            </div>
            <button
              onClick={signPdf}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <PenTool size={20} />}
              Sign & Download
            </button>
          </div>
        )}
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download="signed_document.pdf" className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download Signed PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const OCR_PDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);

  const runOcr = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    setText('');
    setProgress(0);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2.0 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (!context) continue;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        await (page as any).render({ canvasContext: context, viewport }).promise;
        const imgData = canvas.toDataURL('image/png');

        const { data: { text } } = await Tesseract.recognize(imgData, 'eng', {
          logger: m => {
            if (m.status === 'recognizing text') {
              setProgress(Math.round((i - 1) / pdf.numPages * 100 + (m.progress * (100 / pdf.numPages))));
            }
          }
        });
        fullText += `--- Page ${i} ---\n${text}\n\n`;
      }
      setText(fullText);
    } catch (err: any) {
      setError('OCR Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload Scanned PDF</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="space-y-4">
            {loading && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold dark:text-white">
                  <span>Processing OCR...</span>
                  <span>{progress}%</span>
                </div>
                <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-indigo-600"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}
            <button
              onClick={runOcr}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Scan size={20} />}
              Extract Text (OCR)
            </button>
          </div>
        )}
      </div>

      {text && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold dark:text-white">Extracted Text</h3>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(text);
                alert('Text copied to clipboard!');
              }}
              className="text-xs text-indigo-600 hover:underline"
            >
              Copy All
            </button>
          </div>
          <textarea 
            readOnly 
            value={text} 
            className="w-full h-64 p-4 bg-slate-50 dark:bg-slate-800 border dark:border-slate-700 rounded-xl text-sm font-mono dark:text-white outline-none"
          />
        </motion.div>
      )}
    </div>
  );
};

const WordToPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const convertToPdf = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.convertToHtml({ arrayBuffer });
      const html = result.value;

      const element = document.createElement('div');
      element.innerHTML = html;
      element.style.padding = '40px';
      element.style.fontFamily = 'Arial, sans-serif';

      const opt = {
        margin: 1,
        filename: file.name.replace('.docx', '.pdf').replace('.doc', '.pdf'),
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' as const }
      };

      const pdfBlob = await html2pdf().from(element).set(opt).output('blob');
      setResultUrl(URL.createObjectURL(pdfBlob));
    } catch (err: any) {
      setError('Conversion Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload Word Document (.docx)</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-blue-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag Word file to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".docx" />
          </div>
        </div>

        {file && (
          <button
            onClick={convertToPdf}
            disabled={loading}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <FileText size={20} />}
            Convert to PDF
          </button>
        )}
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download={file?.name.replace('.docx', '.pdf')} className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const PDFtoWord = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState('');

  const extractText = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        const strings = content.items.map((item: any) => item.str);
        fullText += strings.join(' ') + '\n\n';
      }
      setText(fullText);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF to Extract Text</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <button
            onClick={extractText}
            disabled={loading}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <FileType size={20} />}
            Extract Text (to Word)
          </button>
        )}
      </div>

      {text && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-4">
          <h3 className="font-bold dark:text-white">Extracted Text</h3>
          <div className="p-4 bg-slate-50 dark:bg-slate-800 border dark:border-slate-700 rounded-xl max-h-96 overflow-y-auto text-sm dark:text-white whitespace-pre-wrap">
            {text}
          </div>
          <button 
            onClick={() => {
              const blob = new Blob([text], { type: 'application/msword' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = file?.name.replace('.pdf', '.doc') || 'document.doc';
              a.click();
            }}
            className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all"
          >
            Download as .doc
          </button>
        </motion.div>
      )}
    </div>
  );
};

const PDFtoJPG = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<{ name: string; url: string }[]>([]);

  const convertToJpg = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    setResults([]);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const newResults: { name: string; url: string }[] = [];

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2.0 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (!context) continue;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        await (page as any).render({ canvasContext: context, viewport }).promise;
        const url = canvas.toDataURL('image/jpeg', 0.8);
        newResults.push({
          name: `${file.name.replace('.pdf', '')}_page_${i}.jpg`,
          url
        });
      }
      setResults(newResults);
    } catch (err: any) {
      setError('Error converting PDF: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF File</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <button
            onClick={convertToJpg}
            disabled={loading}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <FileImage size={20} />}
            Convert to JPG
          </button>
        )}
      </div>

      {results.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-4">
          <h3 className="font-bold dark:text-white">Extracted Images ({results.length})</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {results.map((res, idx) => (
              <div key={idx} className="relative group aspect-[3/4] rounded-xl overflow-hidden border dark:border-slate-800">
                <img src={res.url} alt="" className="w-full h-full object-cover" />
                <a href={res.url} download={res.name} className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                  <Download size={24} />
                </a>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

const CompressPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [originalSize, setOriginalSize] = useState(0);
  const [compressedSize, setCompressedSize] = useState(0);
  const [compressionLevel, setCompressionLevel] = useState(50);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setOriginalSize(selectedFile.size);
      setError(null);
      setResultUrl(null);
    }
  };

  const compressPdf = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    try {
      // Try backend iLovePDF first
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      const base64 = await base64Promise;

      const response = await fetch('/api/pdf/compress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file: base64 })
      });

      if (response.ok) {
        const blob = await response.blob();
        setCompressedSize(blob.size);
        setResultUrl(URL.createObjectURL(blob));
      } else {
        // Fallback to client-side if backend fails or keys not set
        const arrayBuffer = await file.arrayBuffer();
        const pdfDoc = await PDFDocument.load(arrayBuffer);
        const pdfBytes = await pdfDoc.save({
          useObjectStreams: true,
          addDefaultPage: false,
        });
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        setCompressedSize(blob.size);
        setResultUrl(URL.createObjectURL(blob));
      }
    } catch (err: any) {
      setError('Error compressing PDF: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF to Compress</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileArchive className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
                <p className="text-xs text-slate-500">{formatSize(originalSize)}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="space-y-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border dark:border-slate-800">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Minimize2 size={16} className="text-indigo-600" />
                <label className="text-xs font-bold dark:text-white uppercase tracking-wider">Compression Level</label>
              </div>
              <span className="text-sm font-mono text-indigo-600 font-bold">{compressionLevel}%</span>
            </div>
            <input 
              type="range" min="1" max="100" value={compressionLevel}
              onChange={(e) => setCompressionLevel(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <div className="flex justify-between text-[10px] text-slate-500 uppercase font-bold">
              <span>Basic</span>
              <span>Recommended</span>
              <span>Extreme</span>
            </div>
          </div>
        )}

        {loading && (
          <div className="space-y-2">
            <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-indigo-600"
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 1.5, ease: "easeInOut" }}
              />
            </div>
            <p className="text-[10px] text-center text-slate-500 animate-pulse">Optimizing PDF structure and assets...</p>
          </div>
        )}

        <button
          onClick={compressPdf}
          disabled={loading || !file}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <Zap size={20} />}
          {loading ? 'Optimizing...' : 'Compress PDF'}
        </button>
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h4 className="font-bold dark:text-white">Compressed PDF</h4>
              <div className="space-y-2 mt-1">
                <div className="flex justify-between text-xs text-slate-500">
                  <span>{formatSize(compressedSize)}</span>
                  <span className="text-green-500 font-bold">
                    -{Math.round((1 - compressedSize / originalSize) * 100)}%
                  </span>
                </div>
                <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-green-500" 
                    style={{ width: `${(compressedSize / originalSize) * 100}%` }}
                  />
                </div>
              </div>
            </div>
            <a href={resultUrl} download={`compressed_${file?.name}`} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
              <Download size={16} /> Download
            </a>
          </div>
          <iframe src={resultUrl} className="w-full h-[500px] rounded-2xl border dark:border-slate-800" />
        </motion.div>
      )}
    </div>
  );
};

const ExtractPages = () => {
  return <SplitPDF />; // Reusing SplitPDF logic as it handles extraction
};

const AddWatermark = () => {
  const [file, setFile] = useState<File | null>(null);
  const [text, setText] = useState('WATERMARK');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const addWatermark = async () => {
    if (!file || !text) return;
    setLoading(true);
    setError(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      const font = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      const pages = pdfDoc.getPages();

      pages.forEach((page) => {
        const { width, height } = page.getSize();
        page.drawText(text, {
          x: width / 4,
          y: height / 2,
          size: 50,
          font,
          color: rgb(0.7, 0.7, 0.7),
          rotate: degrees(45),
          opacity: 0.3,
        });
      });

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err: any) {
      setError('Error adding watermark: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF File</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white">Watermark Text</label>
              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
            <button
              onClick={addWatermark}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Droplet size={20} />}
              Add Watermark
            </button>
          </div>
        )}
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download="watermarked_document.pdf" className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const PDFViewer = () => {
  const [file, setFile] = useState<File | null>(null);
  const [url, setUrl] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setUrl(URL.createObjectURL(selectedFile));
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {!url ? (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">Upload PDF to View</label>
            <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to view</p>
              </div>
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold dark:text-white truncate max-w-xs">{file?.name}</h3>
            <button onClick={() => setUrl(null)} className="text-sm text-indigo-600 hover:underline">Upload Another</button>
          </div>
          <div className="bg-slate-100 dark:bg-slate-900 rounded-3xl overflow-hidden border dark:border-slate-800 h-[800px]">
            <iframe src={url} className="w-full h-full" title="PDF Viewer" />
          </div>
        </div>
      )}
    </div>
  );
};

const MergePDF = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFiles = Array.from(e.dataTransfer.files) as File[];
      const pdfFiles = droppedFiles.filter(f => f.type === 'application/pdf');
      if (pdfFiles.length > 0) {
        setFiles(prev => [...prev, ...pdfFiles]);
        setError(null);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []) as File[];
    const pdfFiles = selectedFiles.filter(f => f.type === 'application/pdf');
    if (pdfFiles.length > 0) {
      setFiles(prev => [...prev, ...pdfFiles]);
      setError(null);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const moveFile = (index: number, direction: 'up' | 'down') => {
    setFiles(prev => {
      const newFiles = [...prev];
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= newFiles.length) return prev;
      [newFiles[index], newFiles[targetIndex]] = [newFiles[targetIndex], newFiles[index]];
      return newFiles;
    });
  };

  const clearAll = () => {
    setFiles([]);
    setError(null);
    setResultUrl(null);
  };

  const mergePdfs = async () => {
    if (files.length < 2) {
      setError('Please select at least 2 PDF files to merge.');
      return;
    }
    setLoading(true);
    setError(null);
    setResultUrl(null);

    try {
      // Try backend iLovePDF first
      const base64Files = await Promise.all(files.map(file => {
        return new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
      }));

      const response = await fetch('/api/pdf/merge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files: base64Files })
      });

      if (response.ok) {
        const blob = await response.blob();
        setResultUrl(URL.createObjectURL(blob));
      } else {
        // Fallback to client-side
        const mergedPdf = await PDFDocument.create();
        for (const file of files) {
          const arrayBuffer = await file.arrayBuffer();
          const pdfDoc = await PDFDocument.load(arrayBuffer);
          const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
          copiedPages.forEach((page) => mergedPdf.addPage(page));
        }
        const pdfBytes = await mergedPdf.save();
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        setResultUrl(URL.createObjectURL(blob));
      }
    } catch (err: any) {
      setError('Error merging PDFs: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <label className="text-sm font-bold dark:text-white">Upload PDF Files (Min 2)</label>
            {files.length > 0 && (
              <button 
                onClick={clearAll}
                className="text-xs font-bold text-red-500 hover:text-red-600 transition-colors flex items-center gap-1"
              >
                <Trash2 size={12} />
                Clear All
              </button>
            )}
          </div>
          <div 
            className={cn(
              "relative h-32 border-2 border-dashed rounded-2xl flex items-center justify-center overflow-hidden group transition-all",
              dragActive 
                ? "border-indigo-500 bg-indigo-50/50 dark:bg-indigo-900/10" 
                : "border-slate-200 dark:border-slate-800 hover:border-indigo-500"
            )}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="text-center p-4 pointer-events-none">
              <Upload className={cn(
                "mx-auto mb-2 transition-colors",
                dragActive ? "text-indigo-600" : "text-slate-400 group-hover:text-indigo-500"
              )} size={32} />
              <p className="text-sm text-slate-500">
                {dragActive ? "Drop files here" : "Click or drag PDFs to add"}
              </p>
            </div>
            <input 
              type="file" 
              multiple 
              onChange={handleFileChange} 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              accept=".pdf" 
            />
          </div>
        </div>

        {files.length > 0 && (
          <div className="space-y-4">
            <div className="max-h-60 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
              {files.map((file, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border dark:border-slate-800">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="flex flex-col gap-1 mr-1">
                      <button 
                        onClick={() => moveFile(idx, 'up')} 
                        disabled={idx === 0}
                        className="text-slate-400 hover:text-indigo-500 disabled:opacity-30 transition-colors"
                      >
                        <ChevronRight size={14} className="-rotate-90" />
                      </button>
                      <button 
                        onClick={() => moveFile(idx, 'down')} 
                        disabled={idx === files.length - 1}
                        className="text-slate-400 hover:text-indigo-500 disabled:opacity-30 transition-colors"
                      >
                        <ChevronRight size={14} className="rotate-90" />
                      </button>
                    </div>
                    <FileText size={16} className="text-red-500 flex-shrink-0" />
                    <span className="text-xs font-medium dark:text-white truncate">{file.name}</span>
                  </div>
                  <button onClick={() => removeFile(idx)} className="text-slate-400 hover:text-red-500 transition-colors">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>

            {error && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-xl text-red-600 dark:text-red-400 text-sm">
                {error}
              </div>
            )}

            <button
              onClick={mergePdfs}
              disabled={loading || files.length < 2}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Merging PDFs...
                </>
              ) : (
                <>
                  <FilePlus size={20} />
                  Merge PDFs
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {resultUrl && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4"
        >
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mx-auto">
            <CheckCircle2 size={32} />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-bold dark:text-white">PDFs Merged Successfully!</h3>
            <p className="text-slate-500 dark:text-slate-400">Your combined PDF is ready for download.</p>
          </div>
          <a 
            href={resultUrl} 
            download="merged_document.pdf"
            className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20"
          >
            <Download size={20} />
            Download Merged PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const RotatePDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rotation, setRotation] = useState(90);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
      setResultUrl(null);
    }
  };

  const rotatePdf = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      const pages = pdfDoc.getPages();
      
      pages.forEach((page) => {
        const currentRotation = page.getRotation().angle;
        page.setRotation(degrees((currentRotation + rotation) % 360));
      });

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err: any) {
      setError('Error rotating PDF: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF File</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-3">
              {[90, 180, 270].map((deg) => (
                <button
                  key={deg}
                  onClick={() => setRotation(deg)}
                  className={cn(
                    "py-3 rounded-xl text-sm font-bold transition-all border",
                    rotation === deg 
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20" 
                      : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-500"
                  )}
                >
                  {deg}°
                </button>
              ))}
            </div>

            <button
              onClick={rotatePdf}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <RotateCw size={20} />}
              Rotate PDF
            </button>
          </div>
        )}
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-4">
          <a href={resultUrl} download="rotated_document.pdf" className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
            <Download size={20} />
            Download Rotated PDF
          </a>
        </motion.div>
      )}
    </div>
  );
};

const ProtectPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [subject, setSubject] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
      setResultUrl(null);
    }
  };

  const updateMetadata = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      
      if (title) pdfDoc.setTitle(title);
      if (author) pdfDoc.setAuthor(author);
      if (subject) pdfDoc.setSubject(subject);
      
      pdfDoc.setProducer('ToolVerse PDF Engine');
      pdfDoc.setCreator('ToolVerse');
      pdfDoc.setModificationDate(new Date());

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err: any) {
      setError('Error updating metadata: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF to Update Metadata</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Lock className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept=".pdf" />
          </div>
        </div>

        {file && (
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white">Document Title</label>
              <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Enter title..." className="w-full p-3 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white">Author</label>
              <input type="text" value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Enter author name..." className="w-full p-3 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white">Subject</label>
              <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Enter subject..." className="w-full p-3 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none" />
            </div>
          </div>
        )}

        <button
          onClick={updateMetadata}
          disabled={loading || !file}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
          {loading ? 'Updating...' : 'Update Metadata'}
        </button>
      </div>

      {resultUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-bold dark:text-white">Updated PDF</h4>
            <a href={resultUrl} download={`updated_${file?.name}`} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20">
              <Download size={16} /> Download
            </a>
          </div>
          <iframe src={resultUrl} className="w-full h-[500px] rounded-2xl border dark:border-slate-800" />
        </motion.div>
      )}
    </div>
  );
};

const JPGtoPDF = () => {
  const [images, setImages] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFiles = Array.from(e.dataTransfer.files) as File[];
      const imgFiles = droppedFiles.filter(f => f.type.startsWith('image/'));
      if (imgFiles.length > 0) {
        setImages(prev => [...prev, ...imgFiles]);
        setError(null);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []) as File[];
    const imgFiles = selectedFiles.filter(f => f.type.startsWith('image/'));
    if (imgFiles.length > 0) {
      setImages(prev => [...prev, ...imgFiles]);
      setError(null);
    }
  };

  const convertToPdf = async () => {
    if (images.length === 0) return;
    setLoading(true);
    setError(null);

    try {
      const pdfDoc = await PDFDocument.create();
      for (const imgFile of images) {
        const imgBytes = await imgFile.arrayBuffer();
        let img;
        if (imgFile.type === 'image/jpeg' || imgFile.type === 'image/jpg') {
          img = await pdfDoc.embedJpg(imgBytes);
        } else if (imgFile.type === 'image/png') {
          img = await pdfDoc.embedPng(imgBytes);
        } else {
          continue;
        }

        const page = pdfDoc.addPage([img.width, img.height]);
        page.drawImage(img, {
          x: 0,
          y: 0,
          width: img.width,
          height: img.height,
        });
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      setResultUrl(URL.createObjectURL(blob));
    } catch (err: any) {
      setError('Error converting images: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload Images (JPG, PNG)</label>
          <div 
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={cn(
              "relative h-48 border-2 border-dashed rounded-2xl flex items-center justify-center overflow-hidden group transition-all",
              dragActive 
                ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/10" 
                : "border-slate-200 dark:border-slate-800 hover:border-indigo-500"
            )}
          >
            <div className="text-center p-4 pointer-events-none">
              <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className={cn("transition-colors", dragActive ? "text-indigo-600" : "text-slate-400")} size={32} />
              </div>
              <p className="text-sm font-bold dark:text-white">Click or drag images to add</p>
              <p className="text-xs text-slate-500 mt-1">Supports JPG, PNG up to 10MB each</p>
            </div>
            <input type="file" multiple onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
          </div>
        </div>

        {images.length > 0 && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[400px] overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-slate-200 dark:scrollbar-thumb-slate-800">
              <AnimatePresence>
                {images.map((img, idx) => (
                  <motion.div 
                    key={`${img.name}-${idx}`}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="relative aspect-square rounded-xl overflow-hidden border dark:border-slate-800 group shadow-sm bg-slate-50 dark:bg-slate-950"
                  >
                    <ImageThumbnail file={img} />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button 
                        onClick={() => setImages(prev => prev.filter((_, i) => i !== idx))}
                        className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors shadow-lg"
                        title="Remove image"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-1.5 bg-black/60 backdrop-blur-sm">
                      <p className="text-[10px] text-white truncate font-medium">{img.name}</p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border dark:border-slate-800">
              <div className="text-sm font-bold dark:text-white">
                {images.length} {images.length === 1 ? 'image' : 'images'} selected
              </div>
              <button
                onClick={() => setImages([])}
                className="text-xs font-bold text-red-500 hover:text-red-600 flex items-center gap-1"
              >
                <Trash2 size={14} />
                Clear All
              </button>
            </div>

            <button
              onClick={convertToPdf}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <FilePlus size={20} />
              )}
              Convert {images.length} {images.length === 1 ? 'Image' : 'Images'} to PDF
            </button>
          </div>
        )}
      </div>

      {resultUrl && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl text-center space-y-6"
        >
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/20 text-green-600 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 size={32} />
          </div>
          <div>
            <h3 className="text-xl font-bold dark:text-white">Conversion Successful!</h3>
            <p className="text-slate-500 text-sm mt-1">Your PDF is ready for download.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a 
              href={resultUrl} 
              download="converted_images.pdf" 
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20"
            >
              <Download size={20} />
              Download PDF
            </a>
            <button 
              onClick={() => {
                setResultUrl(null);
                setImages([]);
              }}
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border dark:border-slate-800 dark:text-white rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
            >
              <RotateCw size={20} />
              Convert More
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

const ImageThumbnail = ({ file }: { file: File }) => {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    const objectUrl = URL.createObjectURL(file);
    setUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [file]);

  if (!url) return <div className="w-full h-full bg-slate-100 dark:bg-slate-800 animate-pulse" />;

  return (
    <img 
      src={url} 
      alt={file.name} 
      className="w-full h-full object-cover" 
      referrerPolicy="no-referrer"
    />
  );
};

const SplitPDF = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [splitMode, setSplitMode] = useState<'ranges' | 'fixed'>('ranges');
  const [ranges, setRanges] = useState('');
  const [fixedPages, setFixedPages] = useState('1');
  const [results, setResults] = useState<{ name: string; url: string }[]>([]);
  const [pageCount, setPageCount] = useState<number | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
      setResults([]);
      
      try {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const pdfDoc = await PDFDocument.load(arrayBuffer);
        setPageCount(pdfDoc.getPageCount());
      } catch (err) {
        setError('Failed to read PDF file.');
        setPageCount(null);
      }
    } else {
      setError('Please select a valid PDF file.');
    }
  };

  const splitPdf = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    setResults([]);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfDoc = await PDFDocument.load(arrayBuffer);
      const totalPages = pdfDoc.getPageCount();
      const newResults: { name: string; url: string }[] = [];

      if (splitMode === 'fixed') {
        const pagesPerSplit = parseInt(fixedPages);
        if (isNaN(pagesPerSplit) || pagesPerSplit <= 0) {
          throw new Error('Invalid number of pages per split.');
        }

        for (let i = 0; i < totalPages; i += pagesPerSplit) {
          const newPdf = await PDFDocument.create();
          const end = Math.min(i + pagesPerSplit, totalPages);
          const pagesToCopy = Array.from({ length: end - i }, (_, k) => i + k);
          const copiedPages = await newPdf.copyPages(pdfDoc, pagesToCopy);
          copiedPages.forEach((page) => newPdf.addPage(page));
          
          const pdfBytes = await newPdf.save();
          const blob = new Blob([pdfBytes], { type: 'application/pdf' });
          const url = URL.createObjectURL(blob);
          newResults.push({
            name: `${file.name.replace('.pdf', '')}_part_${Math.floor(i / pagesPerSplit) + 1}.pdf`,
            url
          });
        }
      } else {
        // Ranges mode: e.g. "1-2, 3-5, 6"
        const rangeParts = ranges.split(',').map(r => r.trim()).filter(r => r !== '');
        if (rangeParts.length === 0) {
          throw new Error('Please enter at least one page range.');
        }

        for (let i = 0; i < rangeParts.length; i++) {
          const part = rangeParts[i];
          let start, end;
          if (part.includes('-')) {
            [start, end] = part.split('-').map(p => parseInt(p.trim()));
          } else {
            start = end = parseInt(part);
          }

          if (isNaN(start) || isNaN(end) || start <= 0 || end <= 0 || start > totalPages || end > totalPages || start > end) {
            throw new Error(`Invalid range: ${part}`);
          }

          const newPdf = await PDFDocument.create();
          const pagesToCopy = Array.from({ length: end - start + 1 }, (_, k) => start - 1 + k);
          const copiedPages = await newPdf.copyPages(pdfDoc, pagesToCopy);
          copiedPages.forEach((page) => newPdf.addPage(page));
          
          const pdfBytes = await newPdf.save();
          const blob = new Blob([pdfBytes], { type: 'application/pdf' });
          const url = URL.createObjectURL(blob);
          newResults.push({
            name: `${file.name.replace('.pdf', '')}_range_${part}.pdf`,
            url
          });
        }
      }

      setResults(newResults);
    } catch (err: any) {
      setError(err.message || 'An error occurred while splitting the PDF.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white">Upload PDF File</label>
          <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-indigo-500">
            {file ? (
              <div className="text-center p-4">
                <FileText className="mx-auto mb-2 text-red-600" size={32} />
                <p className="text-sm font-bold dark:text-white truncate max-w-[200px]">{file.name}</p>
                <p className="text-xs text-slate-500">{(file.size / (1024 * 1024)).toFixed(2)} MB • {pageCount} pages</p>
              </div>
            ) : (
              <div className="text-center p-4">
                <Upload className="mx-auto mb-2 text-slate-400 group-hover:text-indigo-500 transition-colors" size={32} />
                <p className="text-sm text-slate-500">Click or drag PDF to upload</p>
              </div>
            )}
            <input 
              type="file" 
              onChange={handleFileChange} 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              accept=".pdf" 
            />
          </div>
        </div>

        {file && (
          <div className="space-y-6">
            <div className="flex gap-4">
              <button
                onClick={() => setSplitMode('ranges')}
                className={cn(
                  "flex-1 py-3 rounded-xl text-sm font-bold transition-all border",
                  splitMode === 'ranges' 
                    ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20" 
                    : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-500"
                )}
              >
                Custom Ranges
              </button>
              <button
                onClick={() => setSplitMode('fixed')}
                className={cn(
                  "flex-1 py-3 rounded-xl text-sm font-bold transition-all border",
                  splitMode === 'fixed' 
                    ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20" 
                    : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-500"
                )}
              >
                Fixed Intervals
              </button>
            </div>

            {splitMode === 'ranges' ? (
              <div className="space-y-2">
                <label className="text-sm font-bold dark:text-white">Page Ranges (e.g. 1-2, 3-5, 6)</label>
                <input
                  type="text"
                  value={ranges}
                  onChange={(e) => setRanges(e.target.value)}
                  placeholder="1-2, 3-5, 6"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <label className="text-sm font-bold dark:text-white">Pages per PDF</label>
                <input
                  type="number"
                  value={fixedPages}
                  onChange={(e) => setFixedPages(e.target.value)}
                  min="1"
                  max={pageCount || 1}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-xl text-red-600 dark:text-red-400 text-sm">
                {error}
              </div>
            )}

            <button
              onClick={splitPdf}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Splitting PDF...
                </>
              ) : (
                <>
                  <FileMinus size={20} />
                  Split PDF
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {results.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl space-y-4"
        >
          <h3 className="font-bold dark:text-white flex items-center gap-2">
            <CheckCircle2 className="text-green-500" size={20} />
            Split Results ({results.length} files)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {results.map((res, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border dark:border-slate-800">
                <div className="flex items-center gap-2 min-w-0">
                  <FileText size={16} className="text-red-500 flex-shrink-0" />
                  <span className="text-xs font-medium dark:text-white truncate">{res.name}</span>
                </div>
                <a 
                  href={res.url} 
                  download={res.name}
                  className="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                >
                  <Download size={16} />
                </a>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

const MUSIC_GENRES = ['Lo-fi', 'Cinematic', 'Electronic', 'Jazz', 'Rock', 'Ambient', 'Synthwave', 'Classical', 'Hip Hop', 'Techno', 'Folk'];
const MUSIC_MOODS = ['Chill', 'Uplifting', 'Dark', 'Energetic', 'Sad', 'Whimsical', 'Tense', 'Peaceful', 'Nostalgic', 'Futuristic'];
const MUSIC_INSTRUMENTS = ['Piano', 'Electric Guitar', 'Synthesizer', 'Violin', 'Drums', 'Acoustic Guitar', 'Cello', 'Saxophone', 'Flute', 'Orchestra'];

const MusicGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [genre, setGenre] = useState('');
  const [mood, setMood] = useState('');
  const [selectedInstruments, setSelectedInstruments] = useState<string[]>([]);
  const [duration, setDuration] = useState<'clip' | 'pro'>('clip');
  const [loading, setLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState(false);
  const [compositionInfo, setCompositionInfo] = useState<{ mood: string, genre: string, instruments: string[] } | null>(null);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const toggleInstrument = (inst: string) => {
    setSelectedInstruments(prev => 
      prev.includes(inst) ? prev.filter(i => i !== inst) : [...prev, inst]
    );
  };

  const generateMusic = async () => {
    let combinedPrompt = prompt.trim();
    if (genre) combinedPrompt = `${genre} music. ${combinedPrompt}`;
    if (mood) combinedPrompt = `${mood} mood. ${combinedPrompt}`;
    if (selectedInstruments.length > 0) combinedPrompt = `${combinedPrompt} Featuring ${selectedInstruments.join(', ')}.`;
    
    if (!combinedPrompt.trim()) return;
    
    if (!hasKey) {
      await handleSelectKey();
    }
    
    setLoading(true);
    setAudioUrl(null);
    setCompositionInfo({ mood, genre, instruments: selectedInstruments });

    try {
      // Create a fresh instance for the call to ensure the latest API key is used
      const apiKey = (process.env as any).API_KEY || (process.env as any).GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      const response = await ai.models.generateContentStream({
        model: duration === 'clip' ? "lyria-3-clip-preview" : "lyria-3-pro-preview",
        contents: combinedPrompt,
        config: {
          responseModalities: [Modality.AUDIO]
        }
      });

      let audioBase64 = "";
      let mimeType = "audio/wav";

      for await (const chunk of response) {
        const parts = chunk.candidates?.[0]?.content?.parts;
        if (!parts) continue;
        for (const part of parts) {
          if (part.inlineData?.data) {
            if (!audioBase64 && part.inlineData.mimeType) {
              mimeType = part.inlineData.mimeType;
            }
            audioBase64 += part.inlineData.data;
          }
        }
      }

      if (audioBase64) {
        const binary = atob(audioBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: mimeType });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      }
    } catch (error) {
      console.error("Music Gen Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Immersive Background Decor */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-20 -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full blur-[120px] animate-pulse delay-1000" />
      </div>

      {!hasKey && (
        <div className="bg-amber-500/10 backdrop-blur-xl border border-amber-500/20 p-6 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-top-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-500 border border-amber-500/20">
              <ShieldAlert size={24} />
            </div>
            <div>
              <h4 className="font-black text-amber-500 uppercase italic tracking-wider">Premium Access Required</h4>
              <p className="text-xs text-amber-500/60 font-bold uppercase tracking-widest leading-relaxed">Lyria models require a high-tier paid API key for generation.</p>
            </div>
          </div>
          <button 
            onClick={handleSelectKey}
            className="px-8 py-3 bg-amber-500 text-black rounded-xl font-black uppercase italic tracking-widest hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/20 active:scale-95"
          >
            Authenticate Now
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Configuration Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-black/40 backdrop-blur-2xl p-6 rounded-[2rem] border border-white/5 space-y-6 shadow-2xl">
            <div className="space-y-4">
              <label className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Sonic Profile</label>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Genre</span>
                  <select 
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm font-medium text-white appearance-none focus:border-indigo-500 outline-none transition-all"
                  >
                    <option value="" className="bg-slate-900">Select Genre</option>
                    {MUSIC_GENRES.map(g => <option key={g} value={g} className="bg-slate-900">{g}</option>)}
                  </select>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Mood</span>
                  <select 
                    value={mood}
                    onChange={(e) => setMood(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm font-medium text-white appearance-none focus:border-indigo-500 outline-none transition-all"
                  >
                    <option value="" className="bg-slate-900">Select Mood</option>
                    {MUSIC_MOODS.map(m => <option key={m} value={m} className="bg-slate-900">{m}</option>)}
                  </select>
                </div>

                <div className="space-y-3">
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Model Engine</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => setDuration('clip')}
                      className={cn(
                        "px-3 py-2 rounded-xl text-[10px] font-black uppercase italic tracking-tighter border transition-all",
                        duration === 'clip' ? "bg-indigo-500 border-indigo-400 text-white shadow-lg shadow-indigo-500/20" : "bg-white/5 border-white/10 text-gray-500 hover:text-gray-300"
                      )}
                    >
                      Clip (30s)
                    </button>
                    <button 
                      onClick={() => setDuration('pro')}
                      className={cn(
                        "px-3 py-2 rounded-xl text-[10px] font-black uppercase italic tracking-tighter border transition-all",
                        duration === 'pro' ? "bg-indigo-500 border-indigo-400 text-white shadow-lg shadow-indigo-500/20" : "bg-white/5 border-white/10 text-gray-500 hover:text-gray-300"
                      )}
                    >
                      Pro Track
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-white/5">
              <label className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Instrumentation</label>
              <div className="flex flex-wrap gap-2">
                {MUSIC_INSTRUMENTS.map(inst => (
                  <button
                    key={inst}
                    onClick={() => toggleInstrument(inst)}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border",
                      selectedInstruments.includes(inst) 
                        ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.2)]" 
                        : "bg-white/5 border-white/5 text-gray-600 hover:border-white/20 hover:text-gray-400"
                    )}
                  >
                    {inst}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Workspace Area */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-black/40 backdrop-blur-2xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[100px] -mr-32 -mt-32 rounded-full" />
            
            <div className="relative z-10 space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-500 border border-indigo-500/20 shadow-inner">
                  <MusicIcon size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter leading-none">Sonic Studio</h2>
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.3em]">AI Music Orchestration • Lyria Engine</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="relative group">
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe the cinematic atmosphere, specific rhythmic patterns, or emotional arc of your piece..."
                    className="w-full h-48 bg-white/5 border border-white/10 rounded-[2rem] p-8 text-lg font-medium text-white placeholder:text-gray-600 focus:border-indigo-500/50 outline-none transition-all resize-none shadow-inner"
                  />
                  <div className="absolute top-6 right-8 opacity-0 group-focus-within:opacity-100 transition-opacity">
                    <Sparkles size={20} className="text-indigo-400 animate-pulse" />
                  </div>
                </div>

                <button
                  onClick={generateMusic}
                  disabled={loading || (!prompt.trim() && !genre && !mood)}
                  className="w-full py-6 bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/5 disabled:text-gray-600 text-white rounded-[2rem] font-black uppercase italic tracking-[0.2em] transition-all shadow-2xl shadow-indigo-600/20 active:scale-[0.98] flex items-center justify-center gap-3 relative group"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  {loading ? (
                    <>
                      <div className="flex gap-1 animate-pulse">
                        <div className="w-1 h-4 bg-white/40 rounded-full animate-bounce [animation-delay:-0.3s]" />
                        <div className="w-1 h-6 bg-white rounded-full animate-bounce [animation-delay:-0.15s]" />
                        <div className="w-1 h-4 bg-white/40 rounded-full animate-bounce" />
                      </div>
                      Compose Audio
                    </>
                  ) : (
                    <>
                      Begin Composition
                      <Zap size={20} fill="currentColor" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {audioUrl ? (
              <motion.div 
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-indigo-600 p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden group"
              >
                {/* Visualizer Background */}
                <div className="absolute inset-0 flex items-end gap-1 opacity-20 pointer-events-none">
                  {[...Array(60)].map((_, i) => (
                    <div 
                      key={i} 
                      className="flex-1 bg-white rounded-t-full"
                      style={{ 
                        height: `${Math.random() * 80 + 20}%`,
                        animation: `wave ${Math.random() * 2 + 1}s ease-in-out infinite alternate`
                      }}
                    />
                  ))}
                </div>

                <div className="relative z-10 space-y-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-white backdrop-blur-md">
                          <CheckCircle size={20} />
                        </div>
                        <div>
                          <h4 className="text-xl font-black text-white italic uppercase tracking-tighter">Composition Ready</h4>
                          <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest">Mastered • {duration === 'clip' ? '30s Clip' : 'Full Track'}</p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {compositionInfo?.genre && <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-black text-white uppercase tracking-widest border border-white/20">{compositionInfo.genre}</span>}
                        {compositionInfo?.mood && <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-black text-white uppercase tracking-widest border border-white/20">{compositionInfo.mood}</span>}
                        {compositionInfo?.instruments.map(inst => (
                          <span key={inst} className="px-3 py-1 bg-black/10 rounded-lg text-[10px] font-black text-indigo-200 uppercase tracking-widest border border-indigo-400/20">{inst}</span>
                        ))}
                      </div>
                    </div>
                    
                    <a 
                      href={audioUrl} 
                      download="lyria_masterpiece.wav"
                      className="w-14 h-14 bg-white text-indigo-600 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all"
                    >
                      <Download size={24} />
                    </a>
                  </div>

                  <div className="pt-4">
                    <div className="bg-black/30 backdrop-blur-md p-4 rounded-3xl border border-white/10">
                      <audio src={audioUrl} controls className="w-full accent-white" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : loading ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-black/40 backdrop-blur-2xl p-12 rounded-[2.5rem] border border-white/5 border-dashed flex flex-col items-center justify-center text-center space-y-4"
              >
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
                  <MusicIcon className="absolute inset-0 m-auto text-indigo-500 animate-pulse" size={24} />
                </div>
                <div className="space-y-2">
                  <p className="text-lg font-black text-white uppercase italic tracking-tighter">Harmonizing Structures</p>
                  <p className="text-xs text-gray-500 font-bold uppercase tracking-widest animate-pulse transition-all">This may take up to 60 seconds for advanced orchestration...</p>
                </div>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const IMAGE_STYLES = [
  { 
    id: 'none', 
    name: 'None', 
    icon: X, 
    description: 'Direct interpretation of your prompt.', 
    image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: 'cinematic', 
    name: 'Cinematic', 
    icon: FilmIcon, 
    description: 'Dramatic lighting and movie-like atmosphere.', 
    image: 'https://images.unsplash.com/photo-1485092329990-6ec63c76503b?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: 'digital-art', 
    name: 'Digital Art', 
    icon: Palette, 
    description: 'Clean, vibrant modern digital illustrations.', 
    image: 'https://images.unsplash.com/photo-1547891261-38fde3223efc?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: '3d-render', 
    name: '3D Render', 
    icon: Box, 
    description: 'High-detail 3D models with realistic physics.', 
    image: 'https://images.unsplash.com/photo-1614728263952-84ea206f99b6?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: 'anime', 
    name: 'Anime', 
    icon: Sparkles, 
    description: 'Classic Japanese animation aesthetic.', 
    image: 'https://images.unsplash.com/photo-1580477667995-2b94f01c9516?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: 'oil-painting', 
    name: 'Oil Painting', 
    icon: Edit3, 
    description: 'Traditional brushstrokes and rich textures.', 
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: 'cyberpunk', 
    name: 'Cyberpunk', 
    icon: Zap, 
    description: 'Neon-lit futuristic urban scenes.', 
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=200&q=80' 
  },
  { 
    id: 'minimalist', 
    name: 'Minimalist', 
    icon: Minimize2, 
    description: 'Simple compositions and clean backgrounds.', 
    image: 'https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=200&q=80' 
  },
];

const AIImageStudio = ({ initialPrompt }: { initialPrompt?: string }) => {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '3:4' | '4:3' | '9:16' | '16:9'>('1:1');
  const [style, setStyle] = useState('none');
  const [imageFilter, setImageFilter] = useState('none');
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [history, setHistory] = useState<{url: string, prompt: string}[]>([]);
  const [hasKey, setHasKey] = useState(false);
  const [status, setStatus] = useState('');

  useEffect(() => {
    if (initialPrompt) setPrompt(initialPrompt);
  }, [initialPrompt]);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const enhancePrompt = async () => {
    if (!prompt.trim()) return;
    setEnhancing(true);
    try {
      const apiKey = (process.env as any).API_KEY || (process.env as any).GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ role: 'user', parts: [{ text: `Enhance this image prompt into a professional artistic description for a high-end image model. Keep it concise but descriptive. Prompt: "${prompt}"` }] }],
        config: {
          systemInstruction: "You are a professional digital artist and prompt engineer. Create highly detailed, visual descriptions that specify lighting, colors, textures, and composition. Return ONLY the enhanced prompt."
        }
      });
      if (response.text) {
        setPrompt(response.text.trim());
      }
    } catch (error) {
      console.error("Enhance Error:", error);
    } finally {
      setEnhancing(false);
    }
  };

  const generateImage = async () => {
    if (!prompt.trim()) return;
    if (!hasKey) {
      await handleSelectKey();
    }
    setLoading(true);
    setStatus('Initializing Google Imagen...');
    try {
      const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      let finalPrompt = prompt;
      if (style !== 'none') {
        finalPrompt += `. Created in ${style} art style.`;
      }
      if (imageFilter !== 'none') {
        finalPrompt += ` Apply a ${imageFilter} visual aesthetic.`;
      }

      setStatus('Vision in progress...');
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: finalPrompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: aspectRatio
        }
      });

      const base64Data = response.generatedImages[0].image.imageBytes;
      const url = `data:image/jpeg;base64,${base64Data}`;
      setImageUrl(url);
      setHistory(prev => [{url, prompt: finalPrompt}, ...prev].slice(0, 16));
    } catch (error) {
      console.error("Image Studio Error:", error);
      setStatus('Error generating image. Verify API key privileges.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-12 pb-24 animate-in fade-in duration-700">
      {/* Dynamic Header */}
      <div className="relative group p-12 bg-black/40 backdrop-blur-3xl rounded-[3rem] border border-white/5 overflow-hidden text-center space-y-6 shadow-2xl">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/10 blur-[120px] -mr-64 -mt-64 rounded-full animate-pulse" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-600/10 blur-[120px] -ml-64 -mb-64 rounded-full animate-pulse [animation-delay:2s]" />
        
        <div className="relative z-10 space-y-4">
          <div className="inline-flex items-center gap-3 px-6 py-2 bg-white/5 text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10 shadow-inner">
            <Sparkles size={14} className="animate-pulse" />
            Next-Gen Neural Rendering Core
          </div>
          <h1 className="text-6xl md:text-8xl font-black text-white tracking-tighter italic uppercase leading-none">
            Art <span className="text-indigo-500">Forge</span> AI
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-medium leading-relaxed">
            Manifest your imagination into ultra-high-fidelity visual assets. Powered by Google's elite latent diffusion models.
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-12 items-start">
        {/* Parametric Controls */}
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-black/60 backdrop-blur-3xl rounded-[2.5rem] border border-white/5 p-8 shadow-2xl space-y-10">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Canvas Geometry</label>
                <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center text-gray-500">
                  <Layout size={14} />
                </div>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {(['1:1', '4:3', '16:9', '3:4', '9:16'] as const).map((ar) => (
                  <button
                    key={ar}
                    onClick={() => setAspectRatio(ar)}
                    className={cn(
                      "py-3 rounded-xl border text-[10px] font-black uppercase transition-all",
                      aspectRatio === ar 
                        ? "bg-white text-black border-white shadow-xl scale-110" 
                        : "bg-white/5 border-white/5 text-gray-500 hover:border-white/20 hover:text-white"
                    )}
                  >
                    {ar}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Artistic Styles</label>
                <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center text-gray-500">
                  <Palette size={14} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {IMAGE_STYLES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setStyle(s.id)}
                    className={cn(
                      "group relative aspect-[4/3] rounded-2xl border transition-all overflow-hidden",
                      style === s.id 
                        ? "border-red-500 ring-2 ring-red-500/50 shadow-2xl scale-105" 
                        : "border-white/5 opacity-40 hover:opacity-100 hover:border-white/20"
                    )}
                  >
                    <img src={s.image} alt={s.name} className="absolute inset-0 w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute bottom-2 left-3 right-3 flex items-center gap-2 text-white">
                      <s.icon size={12} className="text-red-500" />
                      <span className="text-[9px] font-black uppercase tracking-widest truncate italic">{s.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Visual Filters</label>
                <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center text-gray-500">
                  <Filter size={14} />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {(['none', 'vibrant', 'moody', 'warm', 'cool', 'surreal', 'hyper-real'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setImageFilter(f)}
                    className={cn(
                      "px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all border",
                      imageFilter === f 
                        ? "bg-red-500 border-red-500 text-white shadow-lg shadow-red-500/20" 
                        : "bg-white/5 border-white/5 text-gray-500 hover:border-white/20 hover:text-white"
                    )}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            {!hasKey && (
              <button 
                onClick={handleSelectKey}
                className="w-full p-6 bg-red-600/10 border border-red-500/20 rounded-3xl flex items-center gap-4 text-left transition-all hover:bg-red-600/20"
              >
                <div className="w-12 h-12 bg-red-600/20 rounded-2xl flex items-center justify-center text-red-500">
                  <ShieldAlert size={24} />
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-red-500">Forge Locked</p>
                  <p className="text-xs text-gray-400 font-bold leading-tight">Connect Pro API Key to unbind limits.</p>
                </div>
              </button>
            )}
          </div>
        </div>

        {/* Neural Canvas Area */}
        <div className="lg:col-span-8 space-y-8">
          <div className="bg-black/60 backdrop-blur-3xl border border-white/5 rounded-[3rem] p-4 shadow-2xl overflow-hidden min-h-[600px] flex flex-col relative group">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(79,70,229,0.05),transparent_70%)]" />
            
            <div className="flex-1 flex flex-col items-center justify-center relative">
              {imageUrl ? (
                <div className="w-full h-full flex flex-col p-4 animate-in fade-in zoom-in duration-700">
                  <div className="relative flex-1 rounded-[2.5rem] overflow-hidden shadow-2xl group/canvas">
                    <img 
                      src={imageUrl} 
                      alt="AI Creation" 
                      className="w-full h-full object-contain bg-slate-950" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/canvas:opacity-100 transition-opacity flex items-center justify-center gap-4">
                      <a 
                        href={imageUrl} 
                        download="ai_forge_art.jpg"
                        className="p-5 bg-white text-black rounded-3xl hover:scale-110 hover:bg-red-500 hover:text-white transition-all shadow-2xl flex items-center gap-3 font-black uppercase italic text-xs tracking-widest"
                      >
                        <Download size={20} />
                        Export Masterpiece
                      </a>
                      <button 
                        onClick={() => {
                          navigator.clipboard.writeText(prompt);
                        }}
                        className="p-5 bg-white/10 backdrop-blur-xl border border-white/20 text-white rounded-3xl hover:scale-110 hover:bg-white hover:text-black transition-all shadow-2xl"
                      >
                        <Copy size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-8 p-12">
                  <div className="relative">
                    <div className="w-32 h-32 bg-white/5 rounded-[2.5rem] flex items-center justify-center mx-auto text-gray-800 border border-white/5 animate-pulse">
                      <Wand2 size={64} />
                    </div>
                    <div className="absolute -top-4 -right-4 w-12 h-12 bg-red-600/20 rounded-2xl flex items-center justify-center text-red-500 animate-bounce">
                      <Zap size={24} />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h3 className="text-3xl font-black text-white italic uppercase tracking-tighter leading-none">Void of Vision</h3>
                    <p className="text-gray-500 max-w-sm mx-auto text-sm font-bold uppercase tracking-widest leading-relaxed">
                      Supply a neural sequence to initiate the forging process.
                    </p>
                  </div>
                </div>
              )}

              {loading && (
                <div className="absolute inset-0 bg-black-950/90 backdrop-blur-xl z-50 flex flex-col items-center justify-center p-12 space-y-8 animate-in fade-in duration-500">
                  <div className="relative">
                    <div className="w-40 h-40 rounded-full border-2 border-white/5 border-t-red-500 animate-spin transition-all duration-1000" />
                    <div className="absolute top-0 w-40 h-40 rounded-full border-2 border-red-500/20 border-b-indigo-500 animate-[spin_3s_linear_infinite]" />
                    <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white animate-pulse" size={48} />
                  </div>
                  <div className="text-center space-y-4">
                    <p className="text-3xl font-black text-white uppercase italic tracking-tighter animate-pulse">{status}</p>
                    <div className="flex gap-2 justify-center">
                      {[1, 2, 3, 4, 5].map(i => (
                        <div key={i} className="w-1.5 h-1.5 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.1}s` }} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Neural Sequence Input Area */}
            <div className="p-4 bg-white/5 m-4 rounded-[2.5rem] border border-white/5 shadow-inner">
              <div className="flex items-center gap-4">
                <div className="flex-1 group/input relative">
                  <input 
                    type="text" 
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && generateImage()}
                    placeholder="Sequence Description: Ex: An ethereal cosmic landscape with bioluminescent nebulas..."
                    className="w-full bg-transparent text-white outline-none py-4 px-6 font-bold text-lg placeholder:text-gray-700 italic tracking-tight"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    <button
                      onClick={enhancePrompt}
                      disabled={enhancing || !prompt.trim()}
                      className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-400 rounded-xl text-[10px] font-black uppercase tracking-widest border border-indigo-500/20 hover:bg-indigo-500/20 transition-all disabled:opacity-50"
                    >
                      {enhancing ? <RefreshCw className="animate-spin" size={14} /> : <Wand2 size={14} />}
                      AI Enhance
                    </button>
                  </div>
                </div>
                <button 
                  onClick={generateImage}
                  disabled={loading || !prompt.trim()}
                  className="px-10 py-5 bg-white text-black rounded-[2rem] font-black uppercase italic tracking-[0.2em] hover:bg-red-500 hover:text-white transition-all shadow-2xl disabled:bg-gray-800 disabled:text-gray-600 active:scale-95 flex items-center gap-4 group/btn"
                >
                  {loading ? 'Forging...' : (
                    <>
                      Materialize
                      <ArrowRight size={24} className="group-hover/btn:translate-x-2 transition-transform" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Chronological Archives */}
          {history.length > 0 && (
            <div className="space-y-6 pt-8">
              <div className="flex items-center justify-between border-b border-white/5 pb-4">
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.4em]">Chronological Archives</p>
                <span className="text-[10px] font-black text-red-500 italic uppercase">Sync Enabled</span>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-4">
                {history.map((item, i) => (
                  <button 
                    key={i} 
                    onClick={() => setImageUrl(item.url)}
                    className="group relative aspect-square rounded-[2rem] border border-white/5 overflow-hidden transition-all hover:scale-110 hover:z-10 shadow-xl"
                  >
                    <img src={item.url} alt="History" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-red-600/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const VIDEO_STYLES = [
  { 
    id: 'cinematic', 
    name: 'Cinematic', 
    description: 'High-quality movie-like visuals with dramatic lighting and professional color grading.',
    icon: FilmIcon, 
    color: 'from-slate-900 to-slate-700',
    image: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=200&q=80'
  },
  { 
    id: 'anime', 
    name: 'Anime', 
    description: 'Vibrant hand-drawn animation style inspired by Japanese animation and manga.',
    icon: Sparkles, 
    color: 'from-pink-500 to-rose-500',
    image: 'https://images.unsplash.com/photo-1578632738981-4330ce9b50ff?auto=format&fit=crop&w=200&q=80'
  },
  { 
    id: '3d', 
    name: '3D Render', 
    description: 'Modern computer-generated imagery with depth, textures, and realistic physics.',
    icon: Box, 
    color: 'from-indigo-500 to-blue-600',
    image: 'https://images.unsplash.com/photo-1633167606207-d840b5070fc2?auto=format&fit=crop&w=200&q=80'
  },
  { 
    id: 'realistic', 
    name: 'Realistic', 
    description: 'Lifelike visuals that mimic real-world photography and natural environments.',
    icon: Camera, 
    color: 'from-emerald-500 to-teal-600',
    image: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=200&q=80'
  },
  { 
    id: 'cyberpunk', 
    name: 'Cyberpunk', 
    description: 'Futuristic neon-lit aesthetic with high-tech elements and dark urban settings.',
    icon: Zap, 
    color: 'from-purple-600 to-pink-600',
    image: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=200&q=80'
  },
  { 
    id: 'watercolor', 
    name: 'Watercolor', 
    description: 'Soft, artistic painting style with fluid colors and delicate textures.',
    icon: Droplet, 
    color: 'from-cyan-400 to-blue-500',
    image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=200&q=80'
  },
  { 
    id: 'sketch', 
    name: 'Sketch', 
    description: 'Hand-drawn pencil or charcoal look with rough lines and artistic shading.',
    icon: PenTool, 
    color: 'from-slate-400 to-slate-600',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=200&q=80'
  },
];

const AIVideoStudio = ({ initialPrompt }: { initialPrompt?: string }) => {
  const [activeTab, setActiveTab] = useState<'text' | 'image' | 'video'>('text');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [style, setStyle] = useState<string>('cinematic');
  const [videoFilter, setVideoFilter] = useState<string>('none');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredStyles = useMemo(() => {
    return VIDEO_STYLES.filter(s => 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      s.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-md mx-auto">
        <button
          onClick={() => setActiveTab('text')}
          className={cn(
            "flex-1 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2",
            activeTab === 'text' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          <Type size={18} />
          Text to Video
        </button>
        <button
          onClick={() => setActiveTab('image')}
          className={cn(
            "flex-1 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2",
            activeTab === 'image' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          <ImageIcon size={18} />
          Image to Video
        </button>
        <button
          onClick={() => setActiveTab('video')}
          className={cn(
            "flex-1 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2",
            activeTab === 'video' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          <FilmIcon size={18} />
          Clip to Video
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white flex items-center gap-2">
              <Maximize2 size={16} className="text-indigo-500" />
              Global Aspect Ratio
            </label>
            <div className="grid grid-cols-3 gap-2">
              {['16:9', '9:16', '1:1'].map((ar) => (
                <button
                  key={ar}
                  onClick={() => setAspectRatio(ar as any)}
                  className={cn(
                    "py-2.5 rounded-xl border text-xs font-bold transition-all",
                    aspectRatio === ar ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" : "border-slate-200 dark:border-slate-800 dark:text-white hover:border-indigo-500"
                  )}
                >
                  {ar}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold dark:text-white flex items-center gap-2">
                <Wand2 size={16} className="text-indigo-500" />
                Global Animation Style
              </label>
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text"
                  placeholder="Search styles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all w-40 sm:w-56"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              {filteredStyles.length > 0 ? (
                filteredStyles.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setStyle(s.id as any)}
                    className={cn(
                      "group relative flex flex-col items-center gap-2 p-1.5 rounded-2xl border transition-all overflow-hidden",
                      style === s.id 
                        ? "border-indigo-600 ring-2 ring-indigo-600/50 scale-105 z-10 shadow-xl" 
                        : "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 dark:text-white hover:border-indigo-500 hover:opacity-100 opacity-60"
                    )}
                  >
                    <div className={cn(
                      "w-full aspect-video rounded-xl flex items-center justify-center transition-all bg-cover bg-center relative overflow-hidden shadow-sm",
                      style === s.id ? "" : "group-hover:scale-105"
                    )} style={{ backgroundImage: `url(${s.image})` }}>
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors" />
                      <s.icon size={16} className="text-white relative z-10" />
                    </div>
                    <span className="text-[8px] font-black uppercase tracking-[0.2em]">{s.name}</span>
                  </button>
                ))
              ) : (
                <div className="col-span-full py-8 text-center">
                  <p className="text-sm text-slate-500">No styles found matching "{searchQuery}"</p>
                </div>
              )}
            </div>
          </div>
          <div className="md:col-span-2 space-y-4 pt-4 border-t dark:border-slate-800">
            <label className="text-sm font-bold dark:text-white flex items-center gap-2">
              <Filter size={16} className="text-indigo-500" />
              Global Visual Filter
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {(['none', 'vintage', 'glitch', 'vibrant', 'grayscale', 'sepia', 'blur'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setVideoFilter(f)}
                  className={cn(
                    "py-2 rounded-xl border text-[10px] font-bold uppercase tracking-wider transition-all",
                    videoFilter === f 
                      ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                      : "border-slate-100 dark:border-slate-800 dark:text-slate-400 hover:border-indigo-500"
                  )}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'text' ? 
            <VideoCreatorAI initialPrompt={initialPrompt} externalAspectRatio={aspectRatio} externalStyle={style} externalFilter={videoFilter} /> : 
           activeTab === 'image' ?
            <ImageToVideo externalAspectRatio={aspectRatio} externalStyle={style} externalFilter={videoFilter} /> :
            <AdvancedVideoAI externalAspectRatio={aspectRatio} externalStyle={style} externalFilter={videoFilter} />
          }
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

const AIVideoAgent = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', content: string, videoUrl?: string }[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [hasKey, setHasKey] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const hour = new Date().getHours();
    const day = new Date().getDay();
    let timeContext = "today";
    if (hour < 12) timeContext = "this morning";
    else if (hour < 18) timeContext = "this afternoon";
    else timeContext = "this evening";

    if (day === 5) timeContext += " (Happy Friday!)";

    setMessages([{ 
      role: 'assistant', 
      content: `Hello! I'm your AI Video Agent. Based on the context of ${timeContext}, I can help you storyboard and generate a professional video. 

Would you like to try something cinematic, like a "Golden Hour Cityscape" or perhaps a "Serene Nature Loop"? Tell me what's on your mind!` 
    }]);
  }, []);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });

      // First, use Gemini to decide if we should generate a video or just chat
      const chatResponse = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: 'user', parts: [{ text: `The user wants: "${userMessage}". Based on the conversation history, should we generate a video now? If yes, provide a detailed video generation prompt. If no, ask clarifying questions to refine the video idea. 
          Respond in JSON format: { "shouldGenerate": boolean, "prompt": string, "response": string }` }] }
        ],
        config: {
          responseMimeType: "application/json",
          systemInstruction: "You are an AI Video Agent. Your goal is to help users create amazing videos. You can brainstorm ideas, suggest styles, and eventually generate the video. When the user is ready, you generate a prompt for a video generation model."
        }
      });

      const decision = JSON.parse(chatResponse.text || '{}');

      if (decision.shouldGenerate) {
        setMessages(prev => [...prev, { role: 'assistant', content: decision.response || "Great! I'm generating that video for you now..." }]);
        setStatus('Dreaming up your video...');
        
        let operation = await ai.models.generateVideos({
          model: 'veo-3.1-lite-generate-preview',
          prompt: decision.prompt,
          config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
          }
        });

        while (!operation.done) {
          await new Promise(resolve => setTimeout(resolve, 10000));
          operation = await (ai.operations as any).getVideosOperation({ operation });
        }

        const downloadLink = (operation.response as any)?.generatedVideos?.[0]?.video?.uri;
        if (downloadLink) {
          const res = await fetch(downloadLink, {
            method: 'GET',
            headers: { 'x-goog-api-key': apiKey! },
          });
          const blob = await res.blob();
          const videoUrl = URL.createObjectURL(blob);
          setMessages(prev => [...prev, { role: 'assistant', content: "Here is your generated video!", videoUrl }]);
        }
      } else {
        setMessages(prev => [...prev, { role: 'assistant', content: decision.response }]);
      }
    } catch (error) {
      console.error("Agent Error:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: "I'm sorry, I encountered an error. Please make sure your API key is configured correctly." }]);
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[700px] flex flex-col bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 shadow-2xl overflow-hidden">
      <div className="p-6 border-b dark:border-slate-800 flex items-center justify-between bg-indigo-600 text-white">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <Bot size={24} />
          </div>
          <div>
            <h3 className="font-bold">AI Video Agent</h3>
            <p className="text-xs text-indigo-100">Powered by Gemini & Veo</p>
          </div>
        </div>
        {!hasKey && (
          <button onClick={handleSelectKey} className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1.5 rounded-lg transition-all font-bold">
            Set API Key
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50 dark:bg-slate-950">
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn(
              "flex gap-4 max-w-[85%]",
              msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
            )}
          >
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
              msg.role === 'user' ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-800 text-indigo-600 border dark:border-slate-700"
            )}>
              {msg.role === 'user' ? <UserIcon size={16} /> : <Bot size={16} />}
            </div>
            <div className="space-y-4">
              <div className={cn(
                "p-4 rounded-2xl shadow-sm",
                msg.role === 'user' 
                  ? "bg-indigo-600 text-white rounded-tr-none" 
                  : "bg-white dark:bg-slate-800 dark:text-white rounded-tl-none border dark:border-slate-700"
              )}>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
              </div>
              {msg.videoUrl && (
                <div className="rounded-2xl overflow-hidden border dark:border-slate-800 shadow-lg bg-black">
                  <video src={msg.videoUrl} controls className="w-full aspect-video" />
                  <div className="p-3 bg-slate-900 flex justify-between items-center">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Generated Video</span>
                    <a href={msg.videoUrl} download="ai-video.mp4" className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 text-xs font-bold">
                      <Download size={14} />
                      Download
                    </a>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        ))}
        {loading && (
          <div className="flex gap-4 mr-auto">
            <div className="w-8 h-8 rounded-full bg-white dark:bg-slate-800 text-indigo-600 border dark:border-slate-700 flex items-center justify-center">
              <Bot size={16} className="animate-pulse" />
            </div>
            <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl rounded-tl-none border dark:border-slate-700 shadow-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.4s]" />
                <span className="text-xs text-slate-500 ml-2">{status || 'Thinking...'}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white dark:bg-slate-900 border-t dark:border-slate-800">
        <div className="relative flex items-center">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Describe the video you want to create..."
            className="w-full p-4 pr-16 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none h-14"
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="absolute right-2 p-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20"
          >
            <Send size={20} />
          </button>
        </div>
        <p className="mt-3 text-[10px] text-slate-500 text-center">
          Tip: You can ask me to refine the style, change the lighting, or add specific details before generating.
        </p>
      </div>
    </div>
  );
};

const VideoCreatorAI = ({ 
  externalAspectRatio, 
  externalStyle, 
  externalFilter,
  initialPrompt
}: { 
  externalAspectRatio?: '16:9' | '9:16' | '1:1', 
  externalStyle?: string, 
  externalFilter?: string,
  initialPrompt?: string
}) => {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>(externalAspectRatio || '16:9');
  const [style, setStyle] = useState<string>(externalStyle || 'cinematic');
  const [videoFilter, setVideoFilter] = useState<string>(externalFilter || 'none');
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [hasKey, setHasKey] = useState(false);

  const loadingMessages = [
    "Analyzing visual concepts...",
    "Dreaming up cinematic textures...",
    "Orchestrating light and motion...",
    "Rendering high-fidelity frames...",
    "Finalizing cinematic sequence...",
    "Polishing visual details..."
  ];

  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);

  useEffect(() => {
    let interval: any;
    if (loading) {
      interval = setInterval(() => {
        setCurrentMessageIndex((prev) => (prev + 1) % loadingMessages.length);
      }, 8000);
    }
    return () => clearInterval(interval);
  }, [loading]);

  useEffect(() => {
    if (externalAspectRatio) setAspectRatio(externalAspectRatio);
  }, [externalAspectRatio]);

  useEffect(() => {
    if (externalStyle) setStyle(externalStyle);
  }, [externalStyle]);

  useEffect(() => {
    if (externalFilter) setVideoFilter(externalFilter);
  }, [externalFilter]);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const enhancePrompt = async () => {
    if (!prompt.trim()) return;
    setEnhancing(true);
    try {
      const apiKey = (process.env as any).API_KEY || (process.env as any).GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ role: 'user', parts: [{ text: `Enhance this video prompt into a professional cinematic description for a high-end video model. Keep it concise but descriptive. Prompt: "${prompt}"` }] }],
        config: {
          systemInstruction: "You are a professional cinematographer and prompt engineer. Create highly detailed, visual descriptions that specify lighting, camera movement, and textures. Return ONLY the enhanced prompt."
        }
      });
      if (response.text) {
        setPrompt(response.text.trim());
      }
    } catch (error) {
      console.error("Enhance Error:", error);
    } finally {
      setEnhancing(false);
    }
  };

  const generateVideo = async () => {
    if (!prompt.trim()) return;
    
    if (!hasKey) {
      await handleSelectKey();
    }

    setLoading(true);
    setStatus('Initializing generation...');
    try {
      const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      let finalPrompt = prompt;
      if (videoFilter !== 'none') {
        finalPrompt += ` with a ${videoFilter} visual style`;
      }

      let operation = await (ai.models as any).generateVideos({
        model: 'veo-3.1-lite-generate-preview',
        prompt: `${finalPrompt} Crafted in ${style} style. High quality, detailed.`,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio
        }
      });

      let attempts = 0;
      while (!operation.done) {
        attempts++;
        setStatus(loadingMessages[currentMessageIndex % loadingMessages.length]);
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await (ai.operations as any).getVideosOperation({ operation });
        
        if (attempts > 60) throw new Error("Generation timed out. Please try again.");
      }

      const downloadLink = (operation.response as any)?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        setStatus('Finalizing video asset...');
        const res = await fetch(downloadLink, {
          method: 'GET',
          headers: {
            'x-goog-api-key': apiKey!,
          },
        });
        const blob = await res.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error("Video Gen Error:", error);
      setStatus('Error generating video. Please check your API key and billing.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-700">
      {!hasKey && (
        <div className="bg-red-500/10 backdrop-blur-xl border border-red-500/20 p-6 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-red-500/20 rounded-2xl flex items-center justify-center text-red-500 border border-red-500/20">
              <ShieldAlert size={24} />
            </div>
            <div>
              <h4 className="font-black text-red-500 uppercase italic tracking-wider">Premium Access Required</h4>
              <p className="text-xs text-red-500/60 font-bold uppercase tracking-widest leading-relaxed">Veo video generation requires a high-tier paid API key.</p>
            </div>
          </div>
          <button 
            onClick={handleSelectKey}
            className="px-8 py-3 bg-red-600 text-white rounded-xl font-black uppercase italic tracking-widest hover:bg-red-500 transition-all shadow-lg shadow-red-500/20 active:scale-95"
          >
            Authenticate Now
          </button>
        </div>
      )}

      <div className="grid lg:grid-cols-12 gap-8 items-start">
        {/* Main Orchestrator */}
        <div className="lg:col-span-12">
          <div className="bg-black/60 backdrop-blur-3xl p-8 rounded-[3rem] border border-white/5 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/5 blur-[120px] -mr-48 -mt-48 rounded-full" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-600/5 blur-[120px] -ml-48 -mb-48 rounded-full" />
            
            <div className="relative z-10 space-y-8">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-red-600/20 rounded-2xl flex items-center justify-center text-red-500 border border-red-500/20 shadow-inner">
                    <Sparkles size={28} />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter leading-none">Film Maker AI</h2>
                    <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.4em] mt-1">Cinematic Core • Veo 3.1 Pro Engine</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-white/5 p-1.5 rounded-2xl border border-white/5">
                  {(['16:9', '9:16', '1:1'] as const).map((ar) => (
                    <button
                      key={ar}
                      onClick={() => setAspectRatio(ar)}
                      className={cn(
                        "px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                        aspectRatio === ar ? "bg-white text-black shadow-xl" : "text-gray-500 hover:text-white"
                      )}
                    >
                      {ar}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="relative group">
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe your cinematic vision... Mention specific actors, camera angles, lighting, and environmental effects."
                    className="w-full h-48 bg-white/5 border border-white/10 rounded-[2.5rem] p-10 text-xl font-medium text-white placeholder:text-gray-700 focus:border-red-500/30 outline-none transition-all resize-none shadow-inner"
                  />
                  <div className="absolute bottom-6 right-8 flex items-center gap-3">
                    <button
                      onClick={enhancePrompt}
                      disabled={enhancing || !prompt.trim()}
                      className="flex items-center gap-2 px-4 py-2 bg-indigo-500/20 text-indigo-400 rounded-xl text-[10px] font-black uppercase tracking-widest border border-indigo-500/20 hover:bg-indigo-500/30 transition-all disabled:opacity-50"
                    >
                      {enhancing ? <RefreshCw className="animate-spin" size={14} /> : <Wand2 size={14} />}
                      AI Enhance
                    </button>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/5 space-y-6">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Cinematic Style Forge</label>
                      <div className="w-8 h-8 bg-white/10 rounded-xl flex items-center justify-center text-red-500">
                        <Palette size={14} />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {VIDEO_STYLES.map(s => (
                        <button
                          key={s.id}
                          onClick={() => setStyle(s.id)}
                          className={cn(
                            "group relative aspect-[4/3] rounded-2xl border transition-all overflow-hidden",
                            style === s.id 
                              ? "border-red-500 ring-2 ring-red-500/50 shadow-2xl scale-105" 
                              : "border-white/5 opacity-40 hover:opacity-100 hover:border-white/20"
                          )}
                        >
                          <img src={s.image} alt={s.name} className="absolute inset-0 w-full h-full object-cover" referrerPolicy="no-referrer" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                          <div className="absolute bottom-2 left-3 right-3 flex items-center gap-2 text-white">
                            <s.icon size={12} className="text-red-500" />
                            <span className="text-[9px] font-black uppercase tracking-widest truncate italic">{s.name}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5 space-y-4">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Visual Filters</label>
                    <div className="flex flex-wrap gap-2">
                      {(['none', 'vintage', 'glitch', 'vibrant', 'grayscale', 'sepia', 'blur'] as const).map(f => (
                        <button
                          key={f}
                          onClick={() => setVideoFilter(f)}
                          className={cn(
                            "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border",
                            videoFilter === f ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-400 shadow-lg" : "bg-white/5 border-white/5 text-gray-600 hover:border-white/20"
                          )}
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  onClick={generateVideo}
                  disabled={loading || !prompt.trim()}
                  className="w-full py-8 bg-red-600 hover:bg-red-500 disabled:bg-white/5 disabled:text-gray-700 text-white rounded-[2.5rem] font-black uppercase italic tracking-[0.3em] transition-all shadow-2xl shadow-red-600/20 active:scale-[0.98] flex items-center justify-center gap-4 group/btn"
                >
                  {loading ? (
                    <div className="flex items-center gap-3">
                      <RefreshCw className="animate-spin" size={24} />
                      {status}
                    </div>
                  ) : (
                    <>
                      Materialize Film
                      <ArrowRight size={24} className="group-hover/btn:translate-x-2 transition-transform" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Output Preview */}
        <AnimatePresence mode="wait">
          {videoUrl && (
            <motion.div 
              key="output"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="lg:col-span-12 bg-black rounded-[3rem] p-8 border border-white/5 shadow-2xl space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xl font-black text-white italic uppercase tracking-tighter">Your Masterpiece</h4>
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking widest mt-1">Rendered with Veo v3.1 Elite Edition</p>
                </div>
                <a 
                  href={videoUrl} 
                  download="dream_film.mp4"
                  className="flex items-center gap-3 px-6 py-3 bg-white text-black text-[10px] font-black uppercase italic tracking-widest rounded-2xl hover:bg-red-500 hover:text-white transition-all shadow-2xl"
                >
                  <Download size={16} />
                  Download
                </a>
              </div>
              
              <div className="relative aspect-video rounded-[2rem] overflow-hidden group shadow-inner bg-slate-900 border border-white/5">
                <video src={videoUrl} controls autoPlay loop className="w-full h-full object-cover" />
                <div className="absolute inset-0 pointer-events-none border border-white/10 rounded-[2rem]" />
              </div>
            </motion.div>
          )}

          {loading && !videoUrl && (
            <motion.div 
              key="loader"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="lg:col-span-12 bg-black-950 border border-white/5 bg-gradient-to-b from-white/5 to-transparent rounded-[3rem] p-12 md:p-24 flex flex-col items-center justify-center text-center space-y-12 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(220,38,38,0.1),transparent_70%)] animate-pulse" />
              
              <div className="relative group">
                <div className="w-48 h-48 border-4 border-red-500/10 border-t-red-500 rounded-full animate-spin transition-all duration-1000 shadow-[0_0_50px_rgba(220,38,38,0.2)]" />
                <div className="absolute inset-0 m-auto w-40 h-40 border-4 border-indigo-500/10 border-b-indigo-500 rounded-full animate-[spin_3s_linear_infinite]" />
                <div className="absolute inset-0 m-auto flex items-center justify-center">
                  <FilmIcon className="text-red-500 animate-pulse" size={56} />
                </div>
              </div>

              <div className="space-y-6 w-full max-w-lg relative z-10">
                <div className="space-y-2">
                  <p className="text-3xl font-black text-white italic uppercase tracking-tighter animate-pulse">{status}</p>
                  <p className="text-xs font-bold text-gray-500 uppercase tracking-[0.4em] italic h-4">
                    {loadingMessages[(currentMessageIndex + 1) % loadingMessages.length]}
                  </p>
                </div>
                
                <div className="space-y-3">
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-red-600 via-purple-600 to-indigo-600 shadow-[0_0_20px_rgba(220,38,38,0.5)]"
                      initial={{ width: "0%" }}
                      animate={{ 
                        width: ["5%", "15%", "45%", "65%", "85%", "92%"],
                        transition: { duration: 60, ease: "easeInOut" }
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] font-black text-gray-600 uppercase tracking-widest overflow-hidden h-4">
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity }}>Initializing Latent Buffers</motion.span>
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}>Rendering Neural Stream</motion.span>
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity, delay: 1 }}>Syncing Frame Sequence</motion.span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const AIVideoGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [style, setStyle] = useState<string>('cinematic');
  const [videoFilter, setVideoFilter] = useState<string>('none');
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const enhancePrompt = async () => {
    if (!prompt.trim()) return;
    setEnhancing(true);
    try {
      const apiKey = (process.env as any).API_KEY || (process.env as any).GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ role: 'user', parts: [{ text: `Enhance this video prompt into a professional cinematic description for a high-end video model. Keep it concise but descriptive. Prompt: "${prompt}"` }] }],
        config: {
          systemInstruction: "You are a professional cinematographer and prompt engineer. Create highly detailed, visual descriptions that specify lighting, camera movement, and textures. Return ONLY the enhanced prompt."
        }
      });
      if (response.text) {
        setPrompt(response.text.trim());
      }
    } catch (error) {
      console.error("Enhance Error:", error);
    } finally {
      setEnhancing(false);
    }
  };

  const generateVideo = async () => {
    if (!prompt.trim()) return;
    
    if (!hasKey) {
      await handleSelectKey();
    }

    setLoading(true);
    setStatus('Initializing AI Video Engine...');
    try {
      const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      let finalPrompt = prompt;
      if (videoFilter !== 'none') {
        finalPrompt += ` with a ${videoFilter} visual style`;
      }

      let operation = await (ai.models as any).generateVideos({
        model: 'veo-3.1-lite-generate-preview',
        prompt: `${finalPrompt} in ${style} style`,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio
        }
      });

      while (!operation.done) {
        setStatus('AI is dreaming up your video... (this may take a few minutes)');
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await (ai.operations as any).getVideosOperation({ operation });
      }

      const downloadLink = (operation.response as any)?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        setStatus('Finalizing video file...');
        const res = await fetch(downloadLink, {
          method: 'GET',
          headers: {
            'x-goog-api-key': apiKey!,
          },
        });
        const blob = await res.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error("Video Generator Error:", error);
      setStatus('Error generating video. Please ensure your API key has billing enabled.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {!hasKey && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-indigo-100 dark:bg-indigo-900/40 rounded-2xl flex items-center justify-center text-indigo-600">
              <Shield size={28} />
            </div>
            <div>
              <h4 className="font-bold dark:text-white text-lg">API Key Required</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">Professional video generation requires a Google Cloud API key with billing.</p>
            </div>
          </div>
          <button 
            onClick={handleSelectKey}
            className="px-8 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 whitespace-nowrap"
          >
            Connect API Key
          </button>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border dark:border-slate-800 shadow-xl space-y-6">
            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Edit3 size={16} className="text-indigo-500" />
                Video Prompt
              </label>
              <div className="relative group">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe the scene you want to create in detail..."
                  className="w-full h-48 p-6 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none text-lg leading-relaxed shadow-inner"
                />
                <div className="absolute bottom-6 right-6 flex items-center gap-2">
                  <button
                    onClick={enhancePrompt}
                    disabled={enhancing || !prompt.trim()}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-400 rounded-xl text-[10px] font-black uppercase tracking-widest border border-indigo-500/20 hover:bg-indigo-500/20 transition-all disabled:opacity-50"
                  >
                    {enhancing ? <RefreshCw className="animate-spin" size={14} /> : <Wand2 size={14} />}
                    AI Enhance
                  </button>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <label className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Layout size={16} className="text-indigo-500" />
                  Aspect Ratio
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['16:9', '9:16', '1:1'] as const).map((ar) => (
                    <button
                      key={ar}
                      onClick={() => setAspectRatio(ar)}
                      className={cn(
                        "py-3 rounded-2xl border-2 font-bold transition-all flex flex-col items-center gap-1",
                        aspectRatio === ar 
                          ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                          : "border-slate-100 dark:border-slate-800 dark:text-slate-400 hover:border-indigo-500"
                      )}
                    >
                      <div className={cn(
                        "border-2 rounded-sm mb-1",
                        ar === '16:9' ? "w-6 h-3.5" : ar === '9:16' ? "w-3.5 h-6" : "w-5 h-5",
                        aspectRatio === ar ? "border-white" : "border-slate-300 dark:border-slate-600"
                      )} />
                      <span className="text-[10px]">{ar}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Palette size={16} className="text-indigo-500" />
                  Animation Style
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {VIDEO_STYLES.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setStyle(s.id as any)}
                      className={cn(
                        "group relative flex flex-col items-center gap-2 p-1.5 rounded-2xl border transition-all overflow-hidden",
                        style === s.id 
                          ? "border-indigo-600 ring-4 ring-indigo-500/10 scale-105 z-10 shadow-xl" 
                          : "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 dark:text-white hover:border-indigo-500 hover:opacity-100 opacity-60"
                      )}
                    >
                      <div className={cn(
                        "w-full aspect-video rounded-xl flex items-center justify-center transition-all bg-cover bg-center relative overflow-hidden shadow-sm",
                        style === s.id ? "" : "group-hover:scale-105"
                      )} style={{ backgroundImage: `url(${s.image})` }}>
                        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors" />
                        <s.icon size={16} className="text-white relative z-10" />
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-[0.2em]">{s.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Filter size={16} className="text-indigo-500" />
                  Visual Filter
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['none', 'vintage', 'glitch', 'vibrant', 'grayscale', 'sepia', 'blur'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setVideoFilter(f)}
                      className={cn(
                        "py-2 rounded-xl border text-[10px] font-bold uppercase tracking-wider transition-all",
                        videoFilter === f 
                          ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                          : "border-slate-100 dark:border-slate-800 dark:text-slate-400 hover:border-indigo-500"
                      )}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={generateVideo}
              disabled={loading || !prompt.trim()}
              className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-xl shadow-indigo-500/30 flex items-center justify-center gap-3"
            >
              {loading ? (
                <>
                  <RefreshCw className="animate-spin" size={24} />
                  {status}
                </>
              ) : (
                <>
                  <Sparkles size={24} />
                  Generate Cinematic Video
                </>
              )}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border dark:border-slate-800 shadow-xl">
            <h3 className="font-bold dark:text-white mb-4 flex items-center gap-2">
              <Info size={18} className="text-indigo-500" />
              Style Gallery
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {VIDEO_STYLES.slice(0, 6).map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={cn(
                    "group relative aspect-square rounded-2xl overflow-hidden border-2 transition-all",
                    style === s.id ? "border-indigo-500 scale-95" : "border-transparent hover:border-indigo-500"
                  )}
                >
                  <img src={s.image} alt={s.name} className="w-full h-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                    <span className="text-[10px] font-black text-white uppercase tracking-wider">{s.name}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-indigo-600 p-6 rounded-[2rem] text-white shadow-xl shadow-indigo-500/20">
            <h4 className="font-black uppercase tracking-widest text-xs mb-2 opacity-80">Pro Tip</h4>
            <p className="text-sm leading-relaxed font-medium">
              Be descriptive! Mention lighting, camera angles, and specific movements for the best results.
            </p>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {videoUrl && (
          <motion.div 
            key="result-pane"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black p-8 md:p-12 rounded-[3.5rem] border border-white/10 shadow-2xl space-y-10 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 blur-[120px] rounded-full" />
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
              <div className="text-center md:text-left">
                <h4 className="text-3xl font-black text-white italic uppercase tracking-tighter">Production Output</h4>
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.4em] mt-2 italic">Refined with Neural Upscaling • Veo Engine</p>
              </div>
              <a 
                href={videoUrl} 
                download="ai_masterpiece.mp4"
                className="flex items-center gap-3 px-10 py-5 bg-white text-black text-xs font-black uppercase italic tracking-widest rounded-3xl hover:bg-indigo-600 hover:text-white transition-all shadow-2xl active:scale-95 group"
              >
                <Download size={20} className="group-hover:-translate-y-1 transition-transform" />
                Export High-Res Asset
              </a>
            </div>
            
            <div className="relative aspect-video rounded-[2.5rem] overflow-hidden group shadow-[0_0_80px_rgba(0,0,0,0.8)] border border-white/5 bg-slate-950">
              <video src={videoUrl} controls autoPlay loop className="w-full h-full object-cover" />
              <div className="absolute inset-0 pointer-events-none border border-white/10 rounded-[2.5rem] ring-1 ring-white/10" />
            </div>
          </motion.div>
        )}

        {loading && !videoUrl && (
          <motion.div 
            key="progress-pane"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white dark:bg-slate-900 border dark:border-slate-800 rounded-[3.5rem] p-16 md:p-32 flex flex-col items-center justify-center text-center space-y-12 relative overflow-hidden shadow-2xl"
          >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(79,70,229,0.05),transparent_70%)] animate-pulse" />
            
            <div className="relative">
              <div className="w-56 h-56 border-4 border-indigo-500/10 border-t-indigo-600 rounded-full animate-spin transition-all duration-1000 shadow-[0_0_60px_rgba(79,70,229,0.2)]" />
              <div className="absolute inset-0 m-auto w-48 h-48 border-4 border-slate-200 dark:border-slate-800 border-b-indigo-400 rounded-full animate-[spin_3s_linear_infinite]" />
              <div className="absolute inset-0 m-auto flex items-center justify-center">
                <div className="relative">
                  <RefreshCw className="text-indigo-600 animate-spin" size={64} />
                  <Sparkles className="absolute -top-4 -right-4 text-indigo-400 animate-pulse" size={24} />
                </div>
              </div>
            </div>

            <div className="space-y-8 w-full max-w-xl relative z-10">
              <div className="space-y-3">
                <p className="text-4xl font-black text-slate-900 dark:text-white italic uppercase tracking-tighter drop-shadow-sm">{status}</p>
                <div className="flex items-center justify-center gap-4">
                  <span className="w-12 h-[1px] bg-indigo-500/30" />
                  <p className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.5em] italic animate-pulse">
                    Neural Synthesis Engine Active
                  </p>
                  <span className="w-12 h-[1px] bg-indigo-500/30" />
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="h-2 w-full bg-slate-100 dark:bg-slate-800/50 rounded-full overflow-hidden p-[2px] border dark:border-slate-800 shadow-inner">
                  <motion.div 
                    className="h-full rounded-full bg-gradient-to-r from-indigo-600 via-blue-500 to-indigo-600 shadow-[0_0_25px_rgba(79,70,229,0.4)]"
                    initial={{ width: "0%" }}
                    animate={{ 
                      width: ["8%", "32%", "58%", "82%", "96%"],
                      transition: { duration: 55, ease: "easeInOut" }
                    }}
                  />
                </div>
                <div className="flex justify-between text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] overflow-hidden h-4 italic px-2">
                  <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity }}>Initializing Kernels</motion.span>
                  <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}>Neural Field Synthesis</motion.span>
                  <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ duration: 2, repeat: Infinity, delay: 1 }}>Finalizing Buffers</motion.span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const BGRemover = () => {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeBackground = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = image.split(',')[1];
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-image-preview',
        contents: [{
          parts: [
            { inlineData: { data: base64Data, mimeType: 'image/png' } },
            { text: "Remove the background of this image and return only the subject on a transparent background as a PNG image." }
          ]
        }]
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setResult(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (error) {
      console.error("BG Removal Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border dark:border-slate-800 shadow-2xl space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase italic tracking-tighter">AI Background Remover</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Extract subjects instantly with neural segmentation</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Source Image</label>
            <div className="relative aspect-square border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[2rem] flex items-center justify-center overflow-hidden bg-slate-50 dark:bg-black/50 group transition-all hover:border-indigo-500">
              {image ? (
                <img src={image} alt="Original" className="w-full h-full object-contain p-4" />
              ) : (
                <div className="text-center p-8">
                  <ImageIcon className="mx-auto mb-4 text-slate-300 dark:text-slate-700" size={64} />
                  <p className="text-sm font-bold text-slate-400 uppercase tracking-widest leading-relaxed">Deposit Image Sequence</p>
                </div>
              )}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Segmented Output</label>
            <div className="relative aspect-square border border-slate-100 dark:border-slate-800 rounded-[2rem] flex items-center justify-center overflow-hidden bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] dark:bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:20px_20px] shadow-inner">
              {result ? (
                <img src={result} alt="Removed Background" className="w-full h-full object-contain p-4 animate-in zoom-in duration-700" />
              ) : (
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center mx-auto text-slate-400">
                    <Zap size={32} />
                  </div>
                  <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Awaiting Neural Processing</p>
                </div>
              )}
              {loading && (
                <div className="absolute inset-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm flex flex-col items-center justify-center space-y-4 z-10">
                  <div className="w-12 h-12 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
                  <p className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.3em] animate-pulse">Isolating Subject...</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="pt-4">
          <button
            onClick={removeBackground}
            disabled={loading || !image}
            className="w-full py-6 bg-slate-950 dark:bg-white text-white dark:text-black rounded-3xl font-black uppercase italic tracking-[0.2em] hover:bg-indigo-600 dark:hover:bg-indigo-500 hover:text-white transition-all shadow-2xl disabled:opacity-50 active:scale-95 flex items-center justify-center gap-4 group"
          >
            {loading ? 'Processing Neural Mask...' : (
              <>
                Execute BG Removal
                <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
              </>
            )}
          </button>
        </div>

        {result && (
          <div className="pt-4 text-center">
            <a
              href={result}
              download="removed_bg.png"
              className="inline-flex items-center gap-3 px-8 py-4 bg-indigo-500 text-white rounded-2xl font-black uppercase italic tracking-widest hover:bg-indigo-600 transition-all shadow-xl shadow-indigo-500/20 active:scale-95"
            >
              Export Transparent Asset
              <Download size={20} />
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

const ImageResizer = () => {
  const [image, setImage] = useState<string | null>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [newDimensions, setNewDimensions] = useState({ width: 0, height: 0 });
  const [aspectRatio, setAspectRatio] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      img.onload = () => {
        setImage(img.src);
        setDimensions({ width: img.width, height: img.height });
        setNewDimensions({ width: img.width, height: img.height });
        setAspectRatio(img.width / img.height);
        setResult(null);
      };
    }
  };

  const handleWidthChange = (w: number) => {
    setNewDimensions(prev => ({
      width: w,
      height: aspectRatio ? Math.round(w / aspectRatio) : prev.height
    }));
  };

  const handleHeightChange = (h: number) => {
    setNewDimensions(prev => ({
      height: h,
      width: aspectRatio ? Math.round(h * aspectRatio) : prev.width
    }));
  };

  const setPresetRatio = (ratio: number | null) => {
    setAspectRatio(ratio);
    if (ratio) {
      setNewDimensions(prev => ({
        ...prev,
        height: Math.round(prev.width / ratio)
      }));
    }
  };

  const resizeImage = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const img = new Image();
      img.src = image;
      await new Promise(r => img.onload = r);

      const canvas = document.createElement('canvas');
      canvas.width = newDimensions.width;
      canvas.height = newDimensions.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, newDimensions.width, newDimensions.height);
        setResult(canvas.toDataURL('image/png'));
      }
    } catch (error) {
      console.error("Resize Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border dark:border-slate-800 shadow-2xl space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase italic tracking-tighter">Image Geometry Resizer</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Precision scaling with aspect ratio locking</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Input Source</label>
              <div className="relative aspect-video border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[2rem] flex items-center justify-center overflow-hidden bg-slate-50 dark:bg-black/50 group transition-all hover:border-indigo-500">
                {image ? (
                  <img src={image} alt="Original" className="w-full h-full object-contain p-4" />
                ) : (
                  <div className="text-center">
                    <ImageIcon className="mx-auto mb-2 text-slate-300 dark:text-slate-700" size={48} />
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Select Visual Asset</p>
                  </div>
                )}
                <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
              </div>
              {image && (
                <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">
                  <span>Current: {dimensions.width}x{dimensions.height}</span>
                </div>
              )}
            </div>

            {image && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">New Width</label>
                    <input 
                      type="number" 
                      value={newDimensions.width}
                      onChange={(e) => handleWidthChange(parseInt(e.target.value))}
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 font-black text-xl italic outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">New Height</label>
                    <input 
                      type="number" 
                      value={newDimensions.height}
                      onChange={(e) => handleHeightChange(parseInt(e.target.value))}
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 font-black text-xl italic outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Aspect Ratio Presets</label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { label: 'Free', val: null },
                      { label: '1:1', val: 1 },
                      { label: '4:3', val: 4/3 },
                      { label: '16:9', val: 16/9 },
                      { label: '9:16', val: 9/16 }
                    ].map(preset => (
                      <button
                        key={preset.label}
                        onClick={() => setPresetRatio(preset.val)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border",
                          aspectRatio === preset.val 
                            ? "bg-indigo-500 border-indigo-500 text-white shadow-lg" 
                            : "bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-500 hover:border-indigo-500"
                        )}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Result Canvas</label>
            <div className="relative aspect-square border border-slate-100 dark:border-slate-800 rounded-[2rem] flex items-center justify-center overflow-hidden bg-slate-50 dark:bg-slate-950 shadow-inner">
              {result ? (
                <div className="w-full h-full flex flex-col p-4">
                  <img src={result} alt="Resized" className="w-full h-full object-contain rounded-xl" />
                  <div className="absolute top-6 right-6">
                    <span className="bg-indigo-500 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
                      {newDimensions.width} x {newDimensions.height}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 space-y-4">
                  <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center mx-auto text-slate-400">
                    <Minimize2 size={32} />
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-relaxed">Adjust geometry to generate asset</p>
                </div>
              )}
            </div>
            {result && (
              <div className="pt-4 text-center">
                <a
                  href={result}
                  download="resized_asset.png"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-indigo-500 text-white rounded-2xl font-black uppercase italic tracking-widest hover:bg-indigo-600 transition-all shadow-xl active:scale-95"
                >
                  Download Asset
                  <Download size={20} />
                </a>
              </div>
            )}
          </div>
        </div>

        {image && !result && (
          <div className="pt-4 border-t dark:border-slate-800">
            <button
              onClick={resizeImage}
              disabled={loading}
              className="w-full py-6 bg-slate-950 dark:bg-white text-white dark:text-black rounded-3xl font-black uppercase italic tracking-[0.2em] hover:bg-indigo-600 dark:hover:bg-indigo-500 hover:text-white transition-all shadow-2xl active:scale-95"
            >
              Materialize Resized Asset
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

const WatermarkImage = () => {
  const [image, setImage] = useState<string | null>(null);
  const [watermark, setWatermark] = useState<string | null>(null);
  const [watermarkText, setWatermarkText] = useState('TOOLVERSE');
  const [opacity, setOpacity] = useState(0.5);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [position, setPosition] = useState<'bottom-right' | 'bottom-left' | 'top-right' | 'top-left' | 'center'>('bottom-right');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWatermarkFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setWatermark(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const applyWatermark = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const mainImg = new Image();
      mainImg.src = image;
      await new Promise(r => mainImg.onload = r);

      const canvas = document.createElement('canvas');
      canvas.width = mainImg.width;
      canvas.height = mainImg.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(mainImg, 0, 0);
        ctx.globalAlpha = opacity;

        if (watermark) {
          const wmImg = new Image();
          wmImg.src = watermark;
          await new Promise(r => wmImg.onload = r);
          
          const wmWidth = mainImg.width * 0.2;
          const wmHeight = (wmImg.height / wmImg.width) * wmWidth;
          
          let x = 0, y = 0;
          const padding = 40;
          
          switch (position) {
            case 'bottom-right': x = mainImg.width - wmWidth - padding; y = mainImg.height - wmHeight - padding; break;
            case 'bottom-left': x = padding; y = mainImg.height - wmHeight - padding; break;
            case 'top-right': x = mainImg.width - wmWidth - padding; y = padding; break;
            case 'top-left': x = padding; y = padding; break;
            case 'center': x = (mainImg.width - wmWidth) / 2; y = (mainImg.height - wmHeight) / 2; break;
          }
          
          ctx.drawImage(wmImg, x, y, wmWidth, wmHeight);
        } else {
          ctx.font = `bold ${Math.round(mainImg.width * 0.05)}px Inter`;
          ctx.fillStyle = 'white';
          ctx.textAlign = 'right';
          ctx.textBaseline = 'bottom';
          
          let x = 0, y = 0;
          const padding = 40;
          
          switch (position) {
            case 'bottom-right': x = mainImg.width - padding; y = mainImg.height - padding; break;
            case 'bottom-left': x = padding; y = mainImg.height - padding; ctx.textAlign = 'left'; break;
            case 'top-right': x = mainImg.width - padding; y = padding + (mainImg.width * 0.05); break;
            case 'top-left': x = padding; y = padding + (mainImg.width * 0.05); ctx.textAlign = 'left'; break;
            case 'center': x = mainImg.width / 2; y = mainImg.height / 2 + (mainImg.width * 0.025); ctx.textAlign = 'center'; break;
          }
          
          ctx.shadowColor = 'rgba(0,0,0,0.5)';
          ctx.shadowBlur = 10;
          ctx.fillText(watermarkText, x, y);
        }

        setResult(canvas.toDataURL('image/png'));
      }
    } catch (error) {
      console.error("Watermark Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border dark:border-slate-800 shadow-2xl space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase italic tracking-tighter">Artistic Watermark Tool</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Protect your intellectual property with stylish overlays</p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Primary Asset</label>
              <div className="relative aspect-video border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[2rem] flex items-center justify-center overflow-hidden bg-slate-50 dark:bg-slate-950 group transition-all hover:border-indigo-500">
                {image ? (
                  <img src={image} alt="Original" className="w-full h-full object-contain p-4" />
                ) : (
                  <div className="text-center">
                    <ImageIcon className="mx-auto mb-2 text-slate-300" size={48} />
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Select Image</p>
                  </div>
                )}
                <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
              </div>
            </div>

            {image && (
              <div className="bg-slate-50 dark:bg-slate-950 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 space-y-6">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Watermark Type</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => setWatermark(null)}
                      className={cn(
                        "p-4 rounded-2xl border font-black text-xs uppercase tracking-widest transition-all",
                        !watermark ? "bg-indigo-500 text-white border-indigo-500 shadow-lg" : "bg-white dark:bg-slate-900 text-slate-500 border-slate-200 dark:border-slate-800"
                      )}
                    >
                      Text Overlay
                    </button>
                    <div className="relative">
                      <button 
                        className={cn(
                          "w-full h-full p-4 rounded-2xl border font-black text-xs uppercase tracking-widest transition-all",
                          watermark ? "bg-indigo-500 text-white border-indigo-500 shadow-lg" : "bg-white dark:bg-slate-900 text-slate-500 border-slate-200 dark:border-slate-800"
                        )}
                      >
                        Image Logo
                      </button>
                      <input type="file" onChange={handleWatermarkFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
                    </div>
                  </div>
                </div>

                {!watermark && (
                  <div className="space-y-4">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Custom Label</label>
                    <input 
                      type="text" 
                      value={watermarkText}
                      onChange={(e) => setWatermarkText(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 font-black italic outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
                    />
                  </div>
                )}

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-left">Opacity Intensity</label>
                    <span className="text-[10px] font-black text-indigo-500">{Math.round(opacity * 100)}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    value={opacity}
                    onChange={(e) => setOpacity(parseFloat(e.target.value))}
                    className="w-full"
                  />
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-left block">Anchor Position</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'top-left', label: 'TL' },
                      { id: 'top-right', label: 'TR' },
                      { id: 'center', label: 'MID' },
                      { id: 'bottom-left', label: 'BL' },
                      { id: 'bottom-right', label: 'BR' }
                    ].map(pos => (
                      <button
                        key={pos.id}
                        onClick={() => setPosition(pos.id as any)}
                        className={cn(
                          "py-2 rounded-xl text-[10px] font-black transition-all border",
                          position === pos.id ? "bg-indigo-500 border-indigo-500 text-white shadow-md" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500"
                        )}
                      >
                        {pos.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={applyWatermark}
                  disabled={loading || !image}
                  className="w-full py-4 bg-slate-950 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase italic tracking-[0.2em] hover:bg-red-500 dark:hover:bg-red-500 hover:text-white transition-all shadow-xl active:scale-95"
                >
                  Generate Protected Asset
                </button>
              </div>
            )}
          </div>

          <div className="lg:col-span-7 space-y-4">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-2">Composite Result</label>
            <div className="relative aspect-square border border-slate-100 dark:border-slate-800 rounded-[3rem] flex items-center justify-center overflow-hidden bg-slate-50 dark:bg-slate-950 shadow-inner group">
              {result ? (
                <div className="w-full h-full flex flex-col p-4">
                  <img src={result} alt="Watermarked" className="w-full h-full object-contain rounded-2xl animate-in fade-in zoom-in duration-500" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <a
                      href={result}
                      download="watermarked_vision.png"
                      className="px-8 py-4 bg-white text-black rounded-2xl font-black uppercase italic tracking-widest hover:bg-red-500 hover:text-white transition-all shadow-2xl flex items-center gap-3"
                    >
                      Export Secured Asset
                      <Download size={20} />
                    </a>
                  </div>
                </div>
              ) : (
                <div className="text-center p-12 space-y-6">
                  <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-[1.5rem] flex items-center justify-center mx-auto text-slate-400">
                    <Shield size={40} />
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] leading-relaxed max-w-[200px] mx-auto">Composite rendering occurs upon neural synchronization</p>
                </div>
              )}
              {loading && (
                <div className="absolute inset-0 bg-indigo-500/10 backdrop-blur-sm flex items-center justify-center">
                  <RefreshCw className="text-indigo-500 animate-spin" size={48} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ImageEditorAI = () => {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const editImage = async () => {
    if (!prompt.trim() || !image) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = image.split(',')[1];
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-image-preview',
        contents: [{
          parts: [
            { inlineData: { data: base64Data, mimeType: 'image/png' } },
            { text: prompt }
          ]
        }]
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setResultUrl(`data:image/png;base64,${part.inlineData.data}`);
          break;
        }
      }
    } catch (error) {
      console.error("Image Edit Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">Upload Image</label>
            <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden">
              {image ? (
                <img src={image} alt="Original" className="w-full h-full object-cover" />
              ) : (
                <div className="text-center p-4">
                  <ImageIcon className="mx-auto mb-2 text-slate-400" size={32} />
                  <p className="text-xs text-slate-500">Click to upload or drag and drop</p>
                </div>
              )}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            </div>
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">Edit Instructions</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., Change the background to a beach, add a hat to the person..."
              className="w-full h-48 p-4 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
            />
          </div>
        </div>
        <button
          onClick={editImage}
          disabled={loading || !prompt.trim() || !image}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20"
        >
          {loading ? 'Editing Image...' : 'Apply AI Edits'}
        </button>
      </div>
      {resultUrl && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border dark:border-slate-800 shadow-xl">
          <img src={resultUrl} alt="Edited" className="w-full rounded-2xl" />
        </div>
      )}
    </div>
  );
};

const AIAnalyzer = ({ type }: { type: 'image' | 'video' }) => {
  const [file, setFile] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('Analyze this content and provide a detailed summary.');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      const reader = new FileReader();
      reader.onloadend = () => setFile(reader.result as string);
      reader.readAsDataURL(f);
    }
  };

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = file.split(',')[1];
      const mimeType = file.split(';')[0].split(':')[1];
      
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-preview',
        contents: [{
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            { text: prompt }
          ]
        }]
      });

      setResult(response.text);
    } catch (error) {
      console.error("Analysis Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">Upload {type === 'image' ? 'Image' : 'Video'}</label>
            <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden">
              {file ? (
                type === 'image' ? <img src={file} className="w-full h-full object-cover" /> : <video src={file} className="w-full h-full object-cover" />
              ) : (
                <div className="text-center p-4">
                  {type === 'image' ? <ImageIcon className="mx-auto mb-2 text-slate-400" size={32} /> : <FilmIcon className="mx-auto mb-2 text-slate-400" size={32} />}
                  <p className="text-xs text-slate-500">Click to upload {type}</p>
                </div>
              )}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept={type === 'image' ? 'image/*' : 'video/*'} />
            </div>
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">What should I look for?</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full h-48 p-4 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
            />
          </div>
        </div>
        <button
          onClick={analyze}
          disabled={loading || !file}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20"
        >
          {loading ? 'Analyzing...' : `Analyze ${type === 'image' ? 'Image' : 'Video'}`}
        </button>
      </div>
      {result && (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl prose dark:prose-invert max-w-none">
          <h3 className="text-xl font-bold mb-4">Analysis Result</h3>
          <div className="whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};

const VideoContentAnalyzer = () => {
  const [file, setFile] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('Provide a detailed summary of this video, including key events, people, and any important information.');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [status, setStatus] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      const reader = new FileReader();
      reader.onloadend = () => setFile(reader.result as string);
      reader.readAsDataURL(f);
    }
  };

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    setStatus('Processing video...');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = file.split(',')[1];
      const mimeType = file.split(';')[0].split(':')[1];
      
      setStatus('Analyzing content with Gemini 3.1 Flash Lite...');
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-preview',
        contents: [{
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            { text: prompt }
          ]
        }]
      });

      setResult(response.text);
    } catch (error) {
      console.error("Video Analysis Error:", error);
      setResult("Error: Failed to analyze video. Please ensure the file is not too large and is in a supported format.");
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  const presets = [
    { name: 'Summary', prompt: 'Provide a detailed summary of this video, including key events, people, and any important information.' },
    { name: 'Key Insights', prompt: 'Extract the top 5 key insights or takeaways from this video.' },
    { name: 'Timeline', prompt: 'Create a chronological timeline of the main events in this video.' },
    { name: 'Action Items', prompt: 'Identify any action items, tasks, or follow-ups mentioned in this video.' }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white flex items-center gap-2">
              <VideoIcon size={16} className="text-indigo-600" />
              Upload Video
            </label>
            <div className="relative h-64 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden bg-slate-50 dark:bg-slate-950">
              {file ? (
                <video src={file} controls className="w-full h-full object-contain" />
              ) : (
                <div className="text-center p-6 space-y-2">
                  <FilmIcon className="mx-auto text-slate-400" size={48} />
                  <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Click to upload video</p>
                  <p className="text-xs text-slate-500">MP4, WebM, or MOV</p>
                </div>
              )}
              {!file && <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="video/*" />}
            </div>
            {file && (
              <button 
                onClick={() => setFile(null)}
                className="text-xs font-bold text-red-500 hover:underline flex items-center gap-1"
              >
                <Trash2 size={12} /> Remove Video
              </button>
            )}
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white flex items-center gap-2">
              <MessageSquare size={16} className="text-indigo-600" />
              Analysis Instructions
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Tell Gemini what to look for in the video..."
              className="w-full h-48 p-4 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-600 outline-none resize-none text-sm"
            />
            <div className="flex flex-wrap gap-2">
              {presets.map(p => (
                <button
                  key={p.name}
                  onClick={() => setPrompt(p.prompt)}
                  className="px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-600 dark:text-slate-400 hover:bg-indigo-600 hover:text-white transition-colors"
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>
        </div>
        <button
          onClick={analyze}
          disabled={loading || !file}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>{status}</span>
            </>
          ) : (
            <>
              <Search size={20} />
              <span>Analyze Video Content</span>
            </>
          )}
        </button>
      </div>

      {result && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold dark:text-white flex items-center gap-2">
              <CheckCircle2 className="text-green-500" />
              Analysis Result
            </h3>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(result);
              }}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
              title="Copy to clipboard"
            >
              <Copy size={20} />
            </button>
          </div>
          <div className="prose dark:prose-invert max-w-none">
            <div className="whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed text-sm">
              {result}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

const ThinkingAI = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const think = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
        }
      });
      setResult(response.text);
    } catch (error) {
      console.error("Thinking Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-bold dark:text-white">Complex Query</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask a complex question that requires deep reasoning..."
            className="w-full h-48 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
          />
        </div>
        <button
          onClick={think}
          disabled={loading || !prompt.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20"
        >
          {loading ? 'Thinking Deeply...' : 'Analyze with High Reasoning'}
        </button>
      </div>
      {result && (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl prose dark:prose-invert max-w-none">
          <h3 className="text-xl font-bold mb-4">Reasoning Result</h3>
          <div className="whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};

const GeminiExplorer = () => {
  const [selectedModel, setSelectedModel] = useState('gemini-3-flash-preview');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const models = [
    { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash', description: 'Fast and efficient for general tasks.', capabilities: ['Text', 'Vision', 'Grounding'] },
    { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro', description: 'Advanced reasoning and complex problem solving.', capabilities: ['Text', 'Vision', 'Complex Reasoning', 'Coding'] },
    { id: 'gemini-3.1-flash-lite-preview', name: 'Gemini 3.1 Flash-Lite', description: 'Optimized for low latency and high efficiency.', capabilities: ['Text', 'Vision'] },
    { id: 'gemini-2.5-flash-image', name: 'Gemini 2.5 Flash Image', description: 'Native image generation and editing.', capabilities: ['Image Generation', 'Image Editing'] },
    { id: 'gemini-3.1-flash-image-preview', name: 'Gemini 3.1 Flash Image Pro', description: 'High-quality image generation with 4K support.', capabilities: ['High-Res Image Generation', 'Grounding'] },
    { id: 'veo-3.1-generate-preview', name: 'Veo 3.1', description: 'High-quality video generation.', capabilities: ['Video Generation'] },
    { id: 'lyria-3-pro-preview', name: 'Lyria 3 Pro', description: 'Full-length high-quality music generation.', capabilities: ['Music Generation'] },
  ];

  const testModel = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: [{ parts: [{ text: prompt }] }],
      });
      setResult(response.text);
    } catch (err: any) {
      console.error("Explorer Error:", err);
      setError(err.message || "An error occurred while testing the model.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-lg font-bold dark:text-white">Select Model</h3>
          <div className="space-y-2">
            {models.map((m) => (
              <button
                key={m.id}
                onClick={() => setSelectedModel(m.id)}
                className={cn(
                  "w-full p-4 rounded-2xl text-left transition-all border",
                  selectedModel === m.id 
                    ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20" 
                    : "bg-white dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800 hover:border-indigo-500"
                )}
              >
                <p className="font-bold">{m.name}</p>
                <p className="text-xs opacity-80 mt-1">{m.description}</p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {m.capabilities.map(cap => (
                    <span key={cap} className="text-[10px] px-2 py-0.5 bg-black/10 dark:bg-white/10 rounded-full">
                      {cap}
                    </span>
                  ))}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b dark:border-slate-800">
              <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg">
                <Globe className="text-indigo-600 dark:text-indigo-400" size={24} />
              </div>
              <div>
                <h4 className="font-bold dark:text-white">Testing: {models.find(m => m.id === selectedModel)?.name}</h4>
                <p className="text-sm text-slate-500">Enter a prompt to see how this model responds.</p>
              </div>
            </div>

            <div className="space-y-4">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={`Try something with ${models.find(m => m.id === selectedModel)?.name}...`}
                className="w-full h-32 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
              />
              <button
                onClick={testModel}
                disabled={loading || !prompt.trim()}
                className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
              >
                {loading ? <RefreshCw className="animate-spin" size={20} /> : <Zap size={20} />}
                {loading ? 'Generating...' : 'Run Model Test'}
              </button>
            </div>

            {error && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-red-600 dark:text-red-400 text-sm">
                {error}
              </div>
            )}

            {result && (
              <div className="space-y-4 pt-6 border-t dark:border-slate-800">
                <h5 className="font-bold dark:text-white">Model Output</h5>
                <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border dark:border-slate-800 whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed">
                  {result}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const SmartSearch = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [groundingLinks, setGroundingLinks] = useState<{title: string, uri: string}[]>([]);

  const search = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: query }] }],
        config: {
          tools: [{ googleSearch: {} }]
        }
      });
      setResult(response.text);
      // Extract grounding metadata if available
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        setGroundingLinks(chunks.map((c: any) => ({
          title: c.web?.title || 'Source',
          uri: c.web?.uri
        })).filter((l: any) => l.uri));
      }
    } catch (error) {
      console.error("Search Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="flex gap-4">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the web with AI grounding..."
            className="flex-1 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
          />
          <button
            onClick={search}
            disabled={loading || !query.trim()}
            className="px-8 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all"
          >
            {loading ? 'Searching...' : 'Search'}
          </button>
        </div>
      </div>
      {result && (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl prose dark:prose-invert max-w-none space-y-6">
          <div className="whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed">
            {result}
          </div>
          {groundingLinks.length > 0 && (
            <div className="pt-6 border-t dark:border-slate-800">
              <h4 className="text-sm font-bold mb-3 flex items-center gap-2">
                <ExternalLink size={16} />
                Sources & Locations
              </h4>
              <div className="flex flex-wrap gap-2">
                {groundingLinks.map((link, i) => (
                  <a
                    key={i}
                    href={link.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors"
                  >
                    {link.title}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const MapExplorerAI = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [groundingLinks, setGroundingLinks] = useState<{title: string, uri: string}[]>([]);

  const explore = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: query }] }],
        config: {
          tools: [{ googleMaps: {} }]
        }
      });
      setResult(response.text);
      // Extract grounding metadata
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        setGroundingLinks(chunks.map((c: any) => ({
          title: c.maps?.title || 'Location',
          uri: c.maps?.uri
        })).filter((l: any) => l.uri));
      }
    } catch (error) {
      console.error("Maps Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="flex gap-4">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find places, get directions, or explore locations..."
            className="flex-1 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
          />
          <button
            onClick={explore}
            disabled={loading || !query.trim()}
            className="px-8 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all"
          >
            {loading ? 'Exploring...' : 'Explore'}
          </button>
        </div>
      </div>
      {result && (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl prose dark:prose-invert max-w-none space-y-6">
          <div className="whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed">
            {result}
          </div>
          {groundingLinks.length > 0 && (
            <div className="pt-6 border-t dark:border-slate-800">
              <h4 className="text-sm font-bold mb-3 flex items-center gap-2">
                <ExternalLink size={16} />
                Maps & Places
              </h4>
              <div className="flex flex-wrap gap-2">
                {groundingLinks.map((link, i) => (
                  <a
                    key={i}
                    href={link.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors"
                  >
                    {link.title}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const AIChatbot = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string; links?: {title: string, uri: string}[] }[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event: any) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            setInput(prev => prev + event.results[i][0].transcript);
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const speak = (text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    // Find a good voice if possible
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Female')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;
    
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const sendMessage = async (overrideInput?: string) => {
    const textToSend = overrideInput || input;
    if (!textToSend.trim()) return;
    
    const userMsg = textToSend;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const chat = ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: "You are a helpful, creative, and intelligent AI assistant named ToolVerse AI. You have access to real-time information via Google Search and Google Maps. Use them to provide accurate and up-to-date answers. Keep your responses concise and conversational if the user is speaking to you.",
          tools: [{ googleSearch: {} }, { googleMaps: {} }]
        },
        history: messages.map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        }))
      });

      const response = await chat.sendMessage({ message: userMsg });
      
      const links = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((c: any) => ({
        title: c.web?.title || c.maps?.title || 'Source',
        uri: c.web?.uri || c.maps?.uri
      })).filter((l: any) => l.uri);

      const modelText = response.text;
      setMessages(prev => [...prev, { role: 'model', text: modelText, links }]);
      
      if (autoSpeak) {
        speak(modelText);
      }
    } catch (error) {
      console.error("Chat Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[600px] flex flex-col bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 shadow-xl overflow-hidden">
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={cn(
            "max-w-[80%] p-4 rounded-2xl space-y-3",
            m.role === 'user' ? "ml-auto bg-indigo-600 text-white" : "bg-slate-100 dark:bg-slate-800 dark:text-white"
          )}>
            <div className="text-sm leading-relaxed markdown-body">
              <Markdown>{m.text}</Markdown>
            </div>
            <div className="flex items-center justify-between pt-2">
              {m.role === 'model' && (
                <button 
                  onClick={() => speak(m.text)}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors text-slate-500"
                  title="Speak message"
                >
                  <Volume2 size={14} />
                </button>
              )}
              {m.links && m.links.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {m.links.map((link, li) => (
                    <a
                      key={li}
                      href={link.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                    >
                      <ExternalLink size={10} />
                      {link.title}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-100 dark:bg-slate-800 dark:text-white max-w-[80%] p-4 rounded-2xl flex items-center gap-2"
          >
            <div className="flex gap-1">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 1, delay: 0 }}
                className="w-1.5 h-1.5 bg-indigo-600 rounded-full"
              />
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                className="w-1.5 h-1.5 bg-indigo-600 rounded-full"
              />
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                className="w-1.5 h-1.5 bg-indigo-600 rounded-full"
              />
            </div>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">ToolVerse AI is thinking...</span>
          </motion.div>
        )}
      </div>
      <div className="p-4 border-t dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder={isListening ? "Listening..." : "Type your message..."}
              className={cn(
                "w-full p-4 pr-12 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all",
                isListening && "border-indigo-500 ring-2 ring-indigo-500/20"
              )}
            />
            <button
              onClick={toggleListening}
              className={cn(
                "absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-all",
                isListening ? "bg-red-500 text-white animate-pulse" : "text-slate-400 hover:text-indigo-600"
              )}
              title={isListening ? "Stop listening" : "Start voice input"}
            >
              <Mic size={20} />
            </button>
          </div>
          <button
            onClick={() => setAutoSpeak(!autoSpeak)}
            className={cn(
              "p-4 rounded-xl border transition-all",
              autoSpeak ? "bg-indigo-600 text-white border-indigo-600 shadow-lg" : "bg-white dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700"
            )}
            title={autoSpeak ? "Auto-speak ON" : "Auto-speak OFF"}
          >
            <Volume2 size={20} />
          </button>
          <button
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            className="px-8 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20"
          >
            Send
          </button>
        </div>
        {isListening && (
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 animate-pulse px-2">
            <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full" />
            Voice recognition active...
          </div>
        )}
      </div>
    </div>
  );
};

const CreativeWriter = () => {
  const [prompt, setPrompt] = useState('');
  const [genre, setGenre] = useState('Fantasy');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const genres = ['Fantasy', 'Sci-Fi', 'Mystery', 'Romance', 'Horror', 'Historical', 'Poetry', 'Script'];

  const generateStory = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: [{ parts: [{ text: `Write a ${genre} story based on this prompt: ${prompt}` }] }],
        config: {
          systemInstruction: `You are an award-winning creative writer specializing in ${genre}. Your goal is to write immersive, emotionally resonant, and highly descriptive content. Use sophisticated vocabulary and varied sentence structures. Focus on "show, don't tell".`,
          temperature: 0.9,
        }
      });
      setResult(response.text);
    } catch (error) {
      console.error("Creative Writing Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {genres.map(g => (
            <button
              key={g}
              onClick={() => setGenre(g)}
              className={cn(
                "py-2 px-4 rounded-xl text-xs font-bold transition-all border",
                genre === g ? "bg-indigo-600 text-white border-indigo-600" : "bg-slate-50 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700 hover:border-indigo-500"
              )}
            >
              {g}
            </button>
          ))}
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold dark:text-white">Story Prompt</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={`Describe your ${genre} story idea...`}
            className="w-full h-40 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
          />
        </div>
        <button
          onClick={generateStory}
          disabled={loading || !prompt.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <PenTool size={20} />}
          {loading ? 'Crafting Story...' : 'Generate Creative Content'}
        </button>
      </div>
      {result && (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl prose dark:prose-invert max-w-none">
          <div className="whitespace-pre-wrap text-slate-600 dark:text-slate-400 leading-relaxed font-serif text-lg">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};

// --- Productivity Tools ---

const SortableTaskItem = ({ task, onToggleComplete, onDelete, onUpdatePriority }: { 
  task: any, 
  onToggleComplete: (id: string) => void, 
  onDelete: (id: string) => void,
  onUpdatePriority: (id: string, priority: 'low' | 'medium' | 'high') => void
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : 1,
  };

  const priorityColors = {
    low: 'text-emerald-500 bg-emerald-500/10',
    medium: 'text-yellow-500 bg-yellow-500/10',
    high: 'text-red-500 bg-red-500/10'
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center gap-3 p-4 bg-black/40 border border-white/5 rounded-2xl group transition-all",
        isDragging ? "shadow-2xl border-red-500/30 scale-[1.02] cursor-grabbing" : "hover:border-white/10"
      )}
    >
      <div {...attributes} {...listeners} className="cursor-grab text-gray-600 hover:text-white transition-colors">
        <Menu size={18} />
      </div>

      <button
        onClick={() => onToggleComplete(task.id)}
        className={cn(
          "w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all",
          task.completed ? "bg-red-600 border-red-600 text-white" : "border-white/20 hover:border-red-500/50"
        )}
      >
        {task.completed && <CheckCircle size={14} />}
      </button>

      <div className="flex-1 min-w-0">
        <p className={cn(
          "text-sm font-medium transition-all truncate",
          task.completed ? "text-gray-500 line-through" : "text-white"
        )}>
          {task.text}
        </p>
      </div>

      <div className="flex items-center gap-2">
        <select
          value={task.priority}
          onChange={(e) => onUpdatePriority(task.id, e.target.value as any)}
          className={cn(
            "text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-lg outline-none cursor-pointer transition-all border border-transparent hover:border-white/10",
            priorityColors[task.priority as keyof typeof priorityColors]
          )}
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>

        <button
          onClick={() => onDelete(task.id)}
          className="p-2 text-gray-600 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
};

const TaskManager = () => {
  const [tasks, setTasks] = useState<any[]>([]);
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 300, tolerance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) {
        const q = query(collection(db, 'tasks'), where('userId', '==', u.uid));
        const unsubTasks = onSnapshot(q, (snapshot) => {
          const loadedTasks = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          })).sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
          setTasks(loadedTasks);
          setLoading(false);
        });
        return () => unsubTasks();
      } else {
        const saved = localStorage.getItem('toolverse_tasks');
        if (saved) setTasks(JSON.parse(saved).sort((a: any, b: any) => (a.order || 0) - (b.order || 0)));
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const saveTasks = async (newTasks: any[]) => {
    if (user) {
      // In a real app, we'd update sequence in Firestore. For now, local state + immediate firestore update
      setTasks(newTasks);
    } else {
      setTasks(newTasks);
      localStorage.setItem('toolverse_tasks', JSON.stringify(newTasks));
    }
  };

  const addTask = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!newTaskText.trim()) return;

    const newTask = {
      text: newTaskText,
      priority: newTaskPriority,
      completed: false,
      createdAt: new Date().toISOString(),
      order: tasks.length
    };

    if (user) {
      await addDoc(collection(db, 'tasks'), {
        ...newTask,
        userId: user.uid,
        createdAt: serverTimestamp()
      });
    } else {
      const updated = [...tasks, { ...newTask, id: Math.random().toString(36).substr(2, 9) }];
      saveTasks(updated);
    }

    setNewTaskText('');
  };

  const toggleComplete = async (id: string) => {
    const updated = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    setTasks(updated);
    
    if (user) {
      await setDoc(doc(db, 'tasks', id), { completed: !tasks.find(t => t.id === id)?.completed }, { merge: true });
    } else {
      localStorage.setItem('toolverse_tasks', JSON.stringify(updated));
    }
  };

  const deleteTask = async (id: string) => {
    const updated = tasks.filter(t => t.id !== id);
    setTasks(updated);

    if (user) {
      await deleteDoc(doc(db, 'tasks', id));
    } else {
      localStorage.setItem('toolverse_tasks', JSON.stringify(updated));
    }
  };

  const updatePriority = async (id: string, priority: 'low' | 'medium' | 'high') => {
    const updated = tasks.map(t => t.id === id ? { ...t, priority } : t);
    setTasks(updated);

    if (user) {
      await setDoc(doc(db, 'tasks', id), { priority }, { merge: true });
    } else {
      localStorage.setItem('toolverse_tasks', JSON.stringify(updated));
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setTasks((items) => {
        const oldIndex = items.findIndex((t) => t.id === active.id);
        const newIndex = items.findIndex((t) => t.id === over.id);
        const updated = arrayMove(items, oldIndex, newIndex).map((t, idx) => ({ ...t, order: idx }));
        
        if (user) {
          // Fire and forget updates for order
          updated.forEach(async (t) => {
            await setDoc(doc(db, 'tasks', t.id), { order: t.order }, { merge: true });
          });
        } else {
          localStorage.setItem('toolverse_tasks', JSON.stringify(updated));
        }
        
        return updated;
      });
    }
  };

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.completed).length,
    high: tasks.filter(t => t.priority === 'high' && !t.completed).length,
    medium: tasks.filter(t => t.priority === 'medium' && !t.completed).length,
    low: tasks.filter(t => t.priority === 'low' && !t.completed).length,
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div className="bg-black/60 backdrop-blur-3xl p-8 rounded-[3rem] border border-white/5 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 blur-[120px] -mr-48 -mt-48 rounded-full" />
        <div className="relative z-10 space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400 border border-emerald-500/20 shadow-inner">
                <CheckCircle2 size={28} />
              </div>
              <div>
                <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter leading-none">Task Planner</h2>
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.4em] mt-1">Productivity Engine • Drag & Drop</p>
              </div>
            </div>

            <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 divide-x divide-white/5">
              <div className="pr-4 text-center">
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Total</p>
                <p className="text-xl font-black text-white">{stats.total}</p>
              </div>
              <div className="px-4 text-center">
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Completed</p>
                <p className="text-xl font-black text-emerald-400">{stats.completed}</p>
              </div>
              <div className="px-4 text-center border-l border-white/5">
                 <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">High Focus</p>
                 <p className="text-xl font-black text-red-500">{stats.high}</p>
              </div>
            </div>
          </div>

          <form onSubmit={addTask} className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <input
                type="text"
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
                placeholder="What needs to be done?"
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-gray-600 outline-none focus:border-red-500/50 transition-all font-medium"
              />
              <div className="flex gap-2 p-1 bg-black/40 rounded-2xl border border-white/5">
                {(['low', 'medium', 'high'] as const).map(p => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setNewTaskPriority(p)}
                    className={cn(
                      "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                      newTaskPriority === p 
                        ? {
                            low: "bg-emerald-500 text-black",
                            medium: "bg-yellow-500 text-black",
                            high: "bg-red-600 text-white shadow-lg shadow-red-500/20"
                          }[p]
                        : "text-gray-500 hover:text-white"
                    )}
                  >
                    {p}
                  </button>
                ))}
              </div>
              <button
                type="submit"
                disabled={!newTaskText.trim()}
                className="px-8 py-4 bg-red-600 hover:bg-red-500 disabled:bg-white/5 disabled:text-gray-700 text-white rounded-2xl font-black uppercase italic tracking-widest transition-all shadow-xl shadow-red-600/20 active:scale-95 flex items-center justify-center gap-2"
              >
                <Plus size={20} />
                Add Task
              </button>
            </div>
          </form>

          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Active Tasks Portfolio</span>
              {!user && (
                <div className="flex items-center gap-2 text-yellow-500">
                  <AlertCircle size={12} />
                  <span className="text-[9px] font-bold uppercase tracking-wider">Sync limited (Guest)</span>
                </div>
              )}
            </div>

            {loading ? (
              <div className="py-20 flex flex-col items-center justify-center space-y-4">
                <RefreshCw className="animate-spin text-red-500" size={32} />
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.4em]">Optimizing Planner...</p>
              </div>
            ) : tasks.length === 0 ? (
              <div className="py-20 text-center space-y-4 border-2 border-dashed border-white/5 rounded-[2rem]">
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto text-gray-700">
                  <CheckCircle2 size={32} />
                </div>
                <div className="space-y-1">
                  <p className="text-white font-bold uppercase tracking-tight italic">No tasks active</p>
                  <p className="text-xs text-gray-500 uppercase tracking-widest font-black">All systems are clear for takeoff.</p>
                </div>
              </div>
            ) : (
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext
                  items={tasks}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-3">
                    {tasks.map((task) => (
                      <SortableTaskItem 
                        key={task.id} 
                        task={task} 
                        onToggleComplete={toggleComplete}
                        onDelete={deleteTask}
                        onUpdatePriority={updatePriority}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            )}
          </div>
        </div>
      </div>

      {user && (
        <div className="bg-red-600/5 border border-red-500/10 p-6 rounded-[2rem] flex items-start gap-4">
          <div className="w-10 h-10 bg-red-600/20 rounded-xl flex items-center justify-center text-red-500 shrink-0">
            <Shield size={20} />
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-black text-white uppercase italic tracking-widest">Real-time Cloud Sync Active</h4>
            <p className="text-[10px] text-gray-500 font-bold leading-relaxed uppercase tracking-widest">
              Your tasks are encrypted and synced across all your devices via ToolVerse Identity Cloud.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

const CaptionGenerator = () => {
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Creative');
  const [platform, setPlatform] = useState('Instagram');
  const [includeEmojis, setIncludeEmojis] = useState(true);
  const [includeHashtags, setIncludeHashtags] = useState(true);
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [captions, setCaptions] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const tones = ['Creative', 'Funny', 'Professional', 'Inspirational', 'Witty', 'Minimalist', 'Bold'];
  const platforms = ['Instagram', 'TikTok', 'Twitter', 'LinkedIn', 'Facebook'];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateCaptions = async () => {
    if (!topic.trim() && !image) return;
    setLoading(true);
    setError(null);
    setCaptions([]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      let promptText = `Generate 5 creative social media captions for ${platform}.
      Topic/Context: ${topic}
      Tone: ${tone}
      Include Emojis: ${includeEmojis ? 'Yes' : 'No'}
      Include Hashtags: ${includeHashtags ? 'Yes' : 'No'}
      
      Please provide the captions as a numbered list. Make them engaging and optimized for ${platform}.`;

      let contents: any;
      if (image) {
        const base64Data = imagePreview?.split(',')[1];
        contents = {
          parts: [
            { text: promptText },
            { inlineData: { mimeType: image.type, data: base64Data } }
          ]
        };
      } else {
        contents = [{ parts: [{ text: promptText }] }];
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: contents,
      });
      
      const text = response.text;
      if (!text) throw new Error("No response from AI");
      
      // Simple parsing of numbered list
      const parsedCaptions = text.split(/\d\.\s+/).filter(c => c.trim().length > 0);
      setCaptions(parsedCaptions.length > 0 ? parsedCaptions : [text]);
    } catch (err: any) {
      console.error("Caption Gen Error:", err);
      setError("Failed to generate captions. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b dark:border-slate-800">
            <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
              <Instagram className="text-red-600 dark:text-red-400" size={24} />
            </div>
            <div>
              <h4 className="font-bold dark:text-white">AI Caption Studio</h4>
              <p className="text-sm text-slate-500">Craft the perfect message for your audience.</p>
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white flex items-center gap-2">
              <Edit3 size={18} className="text-red-500" />
              What is your post about?
            </label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="E.g., A beautiful sunset at the beach, my new coffee shop opening, a weekend hiking trip..."
              className="w-full h-32 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 outline-none resize-none"
            />
          </div>

          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white flex items-center gap-2">
              <ImageIcon size={18} className="text-red-500" />
              Optional: Upload an image for context
            </label>
            <div className="relative h-40 border-2 border-dashed border-red-500/20 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-red-500">
              {imagePreview ? (
                <div className="relative w-full h-full">
                  <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                  <button 
                    onClick={() => { setImage(null); setImagePreview(null); }}
                    className="absolute top-2 right-2 p-1 bg-black/50 text-white rounded-full hover:bg-black/70"
                  >
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <div className="text-center p-4">
                  <Upload className="mx-auto mb-2 text-red-500 group-hover:scale-110 transition-transform" size={32} />
                  <p className="text-xs text-gray-500">Click to upload image</p>
                </div>
              )}
              <input type="file" onChange={handleImageChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase">Tone</label>
              <select 
                value={tone} 
                onChange={(e) => setTone(e.target.value)}
                className="w-full p-3 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
              >
                {tones.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase">Platform</label>
              <select 
                value={platform} 
                onChange={(e) => setPlatform(e.target.value)}
                className="w-full p-3 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
              >
                {platforms.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-6 pt-2">
            <label className="flex items-center gap-2 cursor-pointer group">
              <div className={cn(
                "w-5 h-5 rounded border flex items-center justify-center transition-all",
                includeEmojis ? "bg-red-500 border-red-500" : "border-gray-300 dark:border-slate-700"
              )} onClick={() => setIncludeEmojis(!includeEmojis)}>
                {includeEmojis && <CheckCircle2 size={14} className="text-white" />}
              </div>
              <span className="text-sm dark:text-gray-300">Include Emojis</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer group">
              <div className={cn(
                "w-5 h-5 rounded border flex items-center justify-center transition-all",
                includeHashtags ? "bg-red-500 border-red-500" : "border-gray-300 dark:border-slate-700"
              )} onClick={() => setIncludeHashtags(!includeHashtags)}>
                {includeHashtags && <CheckCircle2 size={14} className="text-white" />}
              </div>
              <span className="text-sm dark:text-gray-300 flex items-center gap-1">
                <Hash size={14} className="text-red-500" />
                Include Hashtags
              </span>
            </label>
          </div>

          <button
            onClick={generateCaptions}
            disabled={loading || (!topic.trim() && !image)}
            className="w-full py-4 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 disabled:opacity-50 transition-all shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw className="animate-spin" size={20} /> : <Zap size={20} />}
            {loading ? 'Generating Captions...' : 'Generate AI Captions'}
          </button>

          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-red-600 dark:text-red-400 text-sm">
              {error}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold dark:text-white">Generated Captions</h3>
            <span className="text-xs text-gray-500">{captions.length} variations</span>
          </div>

          {captions.length > 0 ? (
            <div className="space-y-4">
              {captions.map((caption, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-white dark:bg-slate-900 p-6 rounded-2xl border dark:border-slate-800 shadow-sm group hover:border-red-500/50 transition-all"
                >
                  <div className="flex justify-between items-start gap-4">
                    <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed whitespace-pre-wrap">
                      {caption.trim()}
                    </p>
                    <button 
                      onClick={() => copyToClipboard(caption.trim())}
                      className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                      title="Copy to clipboard"
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-8 bg-slate-50 dark:bg-slate-900/50 rounded-3xl border border-dashed dark:border-slate-800">
              <MessageSquare size={48} className="text-slate-300 dark:text-slate-700 mb-4" />
              <p className="text-slate-500 dark:text-slate-400">Your AI-generated captions will appear here.</p>
              <p className="text-xs text-slate-400 mt-2">Enter a topic or upload an image to get started.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const CodeReviewer = () => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [language, setLanguage] = useState('Auto-detect');
  const [focus, setFocus] = useState('General');

  const languages = ['Auto-detect', 'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'Go', 'Rust', 'PHP', 'HTML/CSS', 'SQL'];
  const focusAreas = ['General', 'Security', 'Performance', 'Best Practices', 'Bugs'];

  const reviewCode = async () => {
    if (!code.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: [{ parts: [{ text: `Language: ${language}\nFocus Area: ${focus}\n\nCode:\n\`\`\`\n${code}\n\`\`\`` }] }],
        config: {
          systemInstruction: `You are a world-class senior software engineer and security auditor. 
          Review the provided code with a focus on ${focus}. 
          Identify bugs, security vulnerabilities, performance bottlenecks, and adherence to best practices. 
          Provide specific, actionable feedback. 
          If you find issues, provide optimized code snippets. 
          Structure your response with clear headings: 
          1. Executive Summary
          2. Identified Issues (categorized by severity)
          3. Security Analysis
          4. Performance Recommendations
          5. Best Practices & Refactoring
          6. Optimized Code Snippet
          Use Markdown for formatting.`,
        }
      });
      setResult(response.text);
    } catch (error) {
      console.error("Code Review Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const copyReview = () => {
    if (result) {
      navigator.clipboard.writeText(result);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold dark:text-white flex items-center gap-2">
                <Code size={18} className="text-indigo-500" />
                Source Code
              </label>
              <div className="flex gap-2">
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="text-xs p-2 rounded-lg border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {languages.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
                <select 
                  value={focus}
                  onChange={(e) => setFocus(e.target.value)}
                  className="text-xs p-2 rounded-lg border dark:border-slate-800 dark:bg-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {focusAreas.map(f => <option key={f} value={f}>{f}</option>)}
                </select>
              </div>
            </div>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Paste your code here for review..."
              className="w-full h-[400px] p-6 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white font-mono text-sm focus:ring-2 focus:ring-indigo-500 outline-none resize-none shadow-inner"
            />
            <button
              onClick={reviewCode}
              disabled={loading || !code.trim()}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
            >
              {loading ? <RefreshCw className="animate-spin" size={20} /> : <Sparkles size={20} />}
              {loading ? 'Analyzing Code Architecture...' : 'Perform AI Code Review'}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-xl">
            <h3 className="font-bold dark:text-white mb-4 flex items-center gap-2">
              <Info size={18} className="text-indigo-500" />
              Review Focus
            </h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800">
                <Bug className="text-red-500 mt-1" size={16} />
                <div>
                  <p className="text-xs font-bold dark:text-white">Bug Detection</p>
                  <p className="text-[10px] text-slate-500">Identifies logical errors and edge cases.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800">
                <ShieldAlert className="text-orange-500 mt-1" size={16} />
                <div>
                  <p className="text-xs font-bold dark:text-white">Security Audit</p>
                  <p className="text-[10px] text-slate-500">Scans for vulnerabilities and leaks.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800">
                <Zap className="text-yellow-500 mt-1" size={16} />
                <div>
                  <p className="text-xs font-bold dark:text-white">Performance</p>
                  <p className="text-[10px] text-slate-500">Optimizes speed and resource usage.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800">
                <CheckCircle className="text-green-500 mt-1" size={16} />
                <div>
                  <p className="text-xs font-bold dark:text-white">Best Practices</p>
                  <p className="text-[10px] text-slate-500">Ensures clean, maintainable code.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {result && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between border-b dark:border-slate-800 pb-4">
            <h3 className="text-xl font-bold dark:text-white flex items-center gap-2">
              <Terminal size={20} className="text-indigo-500" />
              AI Review Report
            </h3>
            <button 
              onClick={copyReview}
              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all text-slate-500 flex items-center gap-2 text-sm font-bold"
            >
              <Copy size={16} />
              Copy Report
            </button>
          </div>
          <div className="prose dark:prose-invert max-w-none">
            <div className="text-slate-600 dark:text-slate-400 leading-relaxed markdown-body">
              <Markdown>{result}</Markdown>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

const TranslationStudio = () => {
  const [text, setText] = useState('');
  const [targetLang, setTargetLang] = useState('Spanish');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const languages = ['Spanish', 'French', 'German', 'Chinese', 'Japanese', 'Korean', 'Italian', 'Portuguese', 'Russian', 'Arabic', 'Hindi'];

  const translate = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: `Translate the following text to ${targetLang}: ${text}` }] }],
        config: {
          systemInstruction: `You are a professional translator. Translate the text accurately to ${targetLang}, preserving the original tone, style, and cultural nuances. If the text is ambiguous, provide the most likely translation and a few alternatives.`,
        }
      });
      setResult(response.text);
    } catch (error) {
      console.error("Translation Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {languages.map(lang => (
            <button
              key={lang}
              onClick={() => setTargetLang(lang)}
              className={cn(
                "py-2 px-3 rounded-xl text-[10px] font-bold transition-all border",
                targetLang === lang ? "bg-indigo-600 text-white border-indigo-600" : "bg-slate-50 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700 hover:border-indigo-500"
              )}
            >
              {lang}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-bold dark:text-white">Source Text</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter text to translate..."
              className="w-full h-48 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold dark:text-white">Translation ({targetLang})</label>
            <div className="w-full h-48 p-4 rounded-xl border dark:border-slate-800 dark:bg-slate-50 dark:text-slate-900 dark:bg-slate-800 dark:text-white overflow-y-auto whitespace-pre-wrap">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <RefreshCw className="animate-spin text-indigo-600" size={32} />
                </div>
              ) : result || <span className="text-slate-400 italic">Translation will appear here...</span>}
            </div>
          </div>
        </div>
        <button
          onClick={translate}
          disabled={loading || !text.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          <Languages size={20} />
          Translate to {targetLang}
        </button>
      </div>
    </div>
  );
};

const AudioTranscriber = () => {
  const [recording, setRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [transcript, setTranscript] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        await transcribeAudio(audioBlob);
      };

      mediaRecorder.start();
      setRecording(true);
    } catch (error) {
      console.error("Mic Error:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  const transcribeAudio = async (blob: Blob) => {
    setLoading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [{
            parts: [
              { inlineData: { data: base64Data, mimeType: 'audio/webm' } },
              { text: "Transcribe this audio accurately." }
            ]
          }]
        });
        setTranscript(response.text);
      };
    } catch (error) {
      console.error("Transcription Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 text-center">
      <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="relative inline-block">
          <button
            onClick={recording ? stopRecording : startRecording}
            className={cn(
              "w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500 shadow-lg",
              recording ? "bg-red-500 animate-pulse scale-110" : "bg-indigo-600 hover:bg-indigo-700"
            )}
          >
            <Mic size={40} className="text-white" />
          </button>
          {recording && (
            <div className="absolute -inset-4 border-4 border-red-500/30 rounded-full animate-ping" />
          )}
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-bold dark:text-white">
            {recording ? 'Recording...' : 'Click to Start Recording'}
          </h3>
          <p className="text-slate-500 text-sm">Speak clearly into your microphone</p>
        </div>
      </div>
      {(loading || transcript) && (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl text-left">
          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Transcript</h4>
          {loading ? (
            <div className="animate-pulse space-y-2">
              <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded w-3/4"></div>
              <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded w-1/2"></div>
            </div>
          ) : (
            <div className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
              {transcript}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const LiveAIAssistant = () => {
  const [active, setActive] = useState(false);
  const [status, setStatus] = useState('Ready to talk');
  const liveRef = useRef<any>(null);

  const toggleLive = async () => {
    if (active) {
      if (liveRef.current) liveRef.current.disconnect();
      setActive(false);
      setStatus('Ready to talk');
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const live = (ai as any).live.create({
        model: 'gemini-3.1-flash-live-preview',
        config: {
          systemInstruction: "You are a friendly, helpful AI assistant in a live voice conversation."
        }
      });
      liveRef.current = live;

      live.on('open', () => {
        setActive(true);
        setStatus('Listening...');
      });

      live.on('close', () => {
        setActive(false);
        setStatus('Ready to talk');
      });

      live.on('error', (err) => {
        console.error("Live API Error:", err);
        setActive(false);
        setStatus('Error occurred');
      });

      await live.connect();
    } catch (error) {
      console.error("Live Connect Error:", error);
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-center space-y-12 py-12">
      <div className="relative">
        <div className={cn(
          "w-48 h-48 mx-auto rounded-full flex items-center justify-center transition-all duration-700",
          active ? "bg-indigo-600 shadow-[0_0_50px_rgba(79,70,229,0.4)] scale-110" : "bg-slate-100 dark:bg-slate-800"
        )}>
          <div className={cn(
            "w-32 h-32 rounded-full border-4 flex items-center justify-center transition-all",
            active ? "border-white/30 animate-spin-slow" : "border-slate-200 dark:border-slate-700"
          )}>
            <Mic size={48} className={active ? "text-white" : "text-slate-400"} />
          </div>
        </div>
        {active && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 border-indigo-500/20 rounded-full animate-ping" />
        )}
      </div>
      <div className="space-y-4">
        <h2 className="text-3xl font-black dark:text-white">{status}</h2>
        <p className="text-slate-500 max-w-md mx-auto">
          Experience real-time, low-latency voice conversations with our most advanced AI model.
        </p>
        <button
          onClick={toggleLive}
          className={cn(
            "px-12 py-4 rounded-2xl font-bold transition-all shadow-xl",
            active ? "bg-red-500 text-white hover:bg-red-600" : "bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-500/20"
          )}
        >
          {active ? 'End Conversation' : 'Start Live Chat'}
        </button>
      </div>
    </div>
  );
};

const ImageToVideo = ({ externalAspectRatio, externalStyle, externalFilter }: { externalAspectRatio?: '16:9' | '9:16' | '1:1', externalStyle?: string, externalFilter?: string }) => {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('Animate this image with subtle cinematic motion.');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>(externalAspectRatio || '16:9');
  const [style, setStyle] = useState<string>(externalStyle || 'cinematic');
  const [loading, setLoading] = useState(false);
  const [videoFilter, setVideoFilter] = useState<string>(externalFilter || 'none');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [hasKey, setHasKey] = useState(false);
  const [showErrors, setShowErrors] = useState(false);

  useEffect(() => {
    if (externalAspectRatio) setAspectRatio(externalAspectRatio);
  }, [externalAspectRatio]);

  useEffect(() => {
    if (externalStyle) setStyle(externalStyle);
  }, [externalStyle]);

  useEffect(() => {
    if (externalFilter) setVideoFilter(externalFilter);
  }, [externalFilter]);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const animate = async () => {
    if (!image || !prompt.trim() || !aspectRatio) {
      setShowErrors(true);
      return;
    }
    
    if (!hasKey) {
      await handleSelectKey();
    }

    setLoading(true);
    setStatus('Uploading image and starting animation...');
    try {
      const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      const base64Data = image.split(',')[1];
      
      let operation = await (ai.models as any).generateVideos({
        model: 'veo-3.1-lite-generate-preview',
        prompt: `${prompt} in ${style} style${videoFilter !== 'none' ? ` with a ${videoFilter} visual style` : ''}`,
        image: {
          imageBytes: base64Data,
          mimeType: 'image/png'
        },
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio
        }
      });

      while (!operation.done) {
        setStatus('Animating your photo... (this may take a few minutes)');
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await (ai.operations as any).getVideosOperation({ operation });
      }

      const downloadLink = (operation.response as any)?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        setStatus('Fetching video data...');
        const res = await fetch(downloadLink, {
          method: 'GET',
          headers: {
            'x-goog-api-key': apiKey!,
          },
        });
        const blob = await res.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error("Image to Video Error:", error);
      setStatus('Error animating image. Please check your API key and billing.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {!hasKey && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/40 rounded-full flex items-center justify-center text-amber-600">
              <Info size={24} />
            </div>
            <div>
              <h4 className="font-bold dark:text-white">API Key Required</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">Veo video generation requires a paid Google Cloud API key.</p>
              <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-xs text-amber-600 hover:underline">Learn about billing</a>
            </div>
          </div>
          <button 
            onClick={handleSelectKey}
            className="px-6 py-2 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition-all text-sm"
          >
            Select API Key
          </button>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white">Upload Photo</label>
            <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden">
              {image ? (
                <img src={image} alt="Original" className="w-full h-full object-cover" />
              ) : (
                <div className="text-center p-4">
                  <ImageIcon className="mx-auto mb-2 text-slate-400" size={32} />
                  <p className="text-xs text-slate-500">Click to upload photo</p>
                </div>
              )}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            </div>
          </div>
          <div className="space-y-4">
            <label className="text-sm font-bold dark:text-white flex items-center justify-between">
              Animation Style
              {showErrors && !prompt.trim() && (
                <span className="text-[10px] text-red-500 uppercase tracking-wider font-black">Required</span>
              )}
            </label>
            <textarea
              value={prompt}
              onChange={(e) => {
                setPrompt(e.target.value);
                if (e.target.value.trim()) setShowErrors(false);
              }}
              placeholder="Describe how you want the image to move..."
              className={cn(
                "w-full h-48 p-4 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none transition-all",
                showErrors && !prompt.trim() && "border-red-500 ring-1 ring-red-500 bg-red-50/50 dark:bg-red-900/10"
              )}
            />
          </div>
        </div>
        {!externalAspectRatio && !externalStyle && (
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white flex items-center justify-between">
                Output Aspect Ratio
                {showErrors && !aspectRatio && (
                  <span className="text-[10px] text-red-500 uppercase tracking-wider font-black">Required</span>
                )}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['16:9', '9:16', '1:1'].map((ar) => (
                  <button
                    key={ar}
                    onClick={() => {
                      setAspectRatio(ar as any);
                      setShowErrors(false);
                    }}
                    className={cn(
                      "py-2 rounded-xl border text-xs font-bold transition-all",
                      aspectRatio === ar ? "bg-indigo-600 border-indigo-600 text-white" : "border-slate-200 dark:border-slate-800 dark:text-white",
                      showErrors && !aspectRatio && "border-red-500"
                    )}
                  >
                    {ar}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold dark:text-white">Animation Style</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {VIDEO_STYLES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setStyle(s.id as any)}
                    className={cn(
                      "group relative flex flex-col items-center gap-2 p-2 rounded-2xl border transition-all overflow-hidden",
                      style === s.id 
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                        : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 dark:text-white hover:border-indigo-500"
                    )}
                  >
                    <div className={cn(
                      "w-full aspect-video rounded-xl flex items-center justify-center transition-all bg-cover bg-center relative overflow-hidden shadow-sm",
                      style === s.id ? "scale-105" : "group-hover:scale-105"
                    )} style={{ backgroundImage: `url(${s.image})` }}>
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                      <s.icon size={20} className="text-white relative z-10" />
                    </div>
                    <span className="text-[9px] font-black uppercase tracking-wider">{s.name}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="md:col-span-2 space-y-2">
              <label className="text-sm font-bold dark:text-white">Visual Filter</label>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                {(['none', 'vintage', 'glitch', 'vibrant', 'grayscale', 'sepia', 'blur'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setVideoFilter(f)}
                    className={cn(
                      "py-2 rounded-xl border text-[10px] font-bold uppercase tracking-wider transition-all",
                      videoFilter === f 
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                        : "border-slate-100 dark:border-slate-800 dark:text-slate-400 hover:border-indigo-500"
                    )}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        <div className="space-y-4">
          {showErrors && (!image || !prompt.trim()) && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl flex items-center gap-3 text-red-600 dark:text-red-400 text-sm">
              <Info size={18} />
              <p>Please ensure a photo is uploaded and an animation style is described.</p>
            </div>
          )}
          <button
            onClick={animate}
            disabled={loading}
            className={cn(
              "w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20",
              !loading && (!image || !prompt.trim()) && "opacity-70 grayscale-[0.5]"
            )}
          >
            {loading ? status : 'Animate Photo'}
          </button>
        </div>
      </div>
      {videoUrl && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border dark:border-slate-800 shadow-xl">
          <video 
            src={videoUrl} 
            controls 
            className="w-full rounded-2xl" 
            style={{
              filter: videoFilter === 'vintage' ? 'sepia(0.5) contrast(1.2) brightness(0.9) hue-rotate(-10deg)' :
                      videoFilter === 'glitch' ? 'hue-rotate(90deg) saturate(2) contrast(1.5)' :
                      videoFilter === 'vibrant' ? 'saturate(1.8) contrast(1.1)' :
                      videoFilter === 'grayscale' ? 'grayscale(100%)' :
                      videoFilter === 'sepia' ? 'sepia(100%)' :
                      videoFilter === 'blur' ? 'blur(4px)' : 'none'
            }}
          />
          <div className="mt-4 flex justify-end">
            <a 
              href={videoUrl} 
              download="animated-photo.mp4"
              className="flex items-center gap-2 text-indigo-600 font-bold hover:underline"
            >
              <Download size={18} />
              Download Video
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

const AdvancedVideoAI = ({ externalAspectRatio, externalStyle, externalFilter }: { externalAspectRatio?: '16:9' | '9:16' | '1:1', externalStyle?: string, externalFilter?: string }) => {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>(externalAspectRatio || '16:9');
  const [style, setStyle] = useState<string>(externalStyle || 'cinematic');
  const [loading, setLoading] = useState(false);
  const [videoFilter, setVideoFilter] = useState<string>(externalFilter || 'none');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [hasKey, setHasKey] = useState(false);
  const [showErrors, setShowErrors] = useState(false);

  useEffect(() => {
    if (externalAspectRatio) setAspectRatio(externalAspectRatio);
  }, [externalAspectRatio]);

  useEffect(() => {
    if (externalStyle) setStyle(externalStyle);
  }, [externalStyle]);

  useEffect(() => {
    if (externalFilter) setVideoFilter(externalFilter);
  }, [externalFilter]);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => setImage(reader.result as string);
        reader.readAsDataURL(file);
      } else if (file.type.startsWith('video/')) {
        setStatus('Extracting frame from video...');
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.src = URL.createObjectURL(file);
        video.onloadedmetadata = () => {
          video.currentTime = 0.1; // Seek a bit to avoid black frame
        };
        video.onseeked = () => {
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(video, 0, 0);
          setImage(canvas.toDataURL('image/png'));
          setStatus('');
        };
      }
    }
  };

  const generate = async () => {
    if (!prompt.trim()) {
      setShowErrors(true);
      return;
    }
    
    if (!hasKey) {
      await handleSelectKey();
    }

    setLoading(true);
    setStatus('Starting video generation...');
    try {
      const apiKey = (process.env as any).API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      const config: any = {
        model: 'veo-3.1-lite-generate-preview',
        prompt: `${prompt} in ${style} style${videoFilter !== 'none' ? ` with a ${videoFilter} visual style` : ''}`,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio
        }
      };

      if (image) {
        const base64Data = image.split(',')[1];
        config.image = {
          imageBytes: base64Data,
          mimeType: 'image/png'
        };
      }
      
      let operation = await (ai.models as any).generateVideos(config);

      while (!operation.done) {
        setStatus('Generating your video... (this may take a few minutes)');
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await (ai.operations as any).getVideosOperation({ operation });
      }

      const downloadLink = (operation.response as any)?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        setStatus('Fetching video data...');
        const res = await fetch(downloadLink, {
          method: 'GET',
          headers: {
            'x-goog-api-key': apiKey!,
          },
        });
        const blob = await res.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error("Advanced Video Error:", error);
      setStatus('Error generating video. Please check your API key and billing.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {!hasKey && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/40 rounded-full flex items-center justify-center text-amber-600">
              <Info size={24} />
            </div>
            <div>
              <h4 className="font-bold dark:text-white">API Key Required</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">Veo video generation requires a paid Google Cloud API key.</p>
              <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-xs text-amber-600 hover:underline">Learn about billing</a>
            </div>
          </div>
          <button 
            onClick={handleSelectKey}
            className="px-6 py-2 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition-all text-sm"
          >
            Select API Key
          </button>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white flex items-center justify-between">
            Video Prompt
            {showErrors && !prompt.trim() && (
              <span className="text-[10px] text-red-500 uppercase tracking-wider font-black">Required</span>
            )}
          </label>
          <textarea
            value={prompt}
            onChange={(e) => {
              setPrompt(e.target.value);
              if (e.target.value.trim()) setShowErrors(false);
            }}
            placeholder="Describe the video you want to create..."
            className={cn(
              "w-full h-32 p-4 rounded-2xl border dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none transition-all",
              showErrors && !prompt.trim() && "border-red-500 ring-1 ring-red-500 bg-red-50/50 dark:bg-red-900/10"
            )}
          />
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className={cn("space-y-4", (externalAspectRatio || externalStyle) ? "md:col-span-2" : "")}>
            <label className="text-sm font-bold dark:text-white">Reference Image or Clip (Optional)</label>
            <div className="relative h-48 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center overflow-hidden group">
              {image ? (
                <>
                  <img src={image} alt="Reference" className="w-full h-full object-cover" />
                  <button 
                    onClick={() => setImage(null)}
                    className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 size={16} />
                  </button>
                </>
              ) : (
                <div className="text-center p-4">
                  <ImageIcon className="mx-auto mb-2 text-slate-400" size={32} />
                  <p className="text-xs text-slate-500">Click to upload photo or video clip</p>
                </div>
              )}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*,video/*" />
            </div>
          </div>

          {!externalAspectRatio && !externalStyle && (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold dark:text-white">Aspect Ratio</label>
                <div className="grid grid-cols-3 gap-2">
                  {['16:9', '9:16', '1:1'].map((ar) => (
                    <button
                      key={ar}
                      onClick={() => setAspectRatio(ar as any)}
                      className={cn(
                        "py-2 rounded-xl border text-xs font-bold transition-all",
                        aspectRatio === ar ? "bg-indigo-600 border-indigo-600 text-white" : "border-slate-200 dark:border-slate-800 dark:text-white"
                      )}
                    >
                      {ar}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold dark:text-white">Animation Style</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                  {VIDEO_STYLES.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setStyle(s.id as any)}
                      className={cn(
                        "group relative flex flex-col items-center gap-2 p-1.5 rounded-2xl border transition-all overflow-hidden",
                        style === s.id 
                          ? "border-indigo-600 ring-2 ring-indigo-600/50 scale-105 z-10 shadow-xl" 
                          : "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 dark:text-white hover:border-indigo-500 hover:opacity-100 opacity-60"
                      )}
                    >
                      <div className={cn(
                        "w-full aspect-video rounded-xl flex items-center justify-center transition-all bg-cover bg-center relative overflow-hidden shadow-sm",
                        style === s.id ? "" : "group-hover:scale-105"
                      )} style={{ backgroundImage: `url(${s.image})` }}>
                        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors" />
                        <s.icon size={16} className="text-white relative z-10" />
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-[0.2em]">{s.name}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold dark:text-white">Visual Filter</label>
                <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                  {(['none', 'vintage', 'glitch', 'vibrant', 'grayscale', 'sepia', 'blur'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setVideoFilter(f)}
                      className={cn(
                        "py-2 rounded-xl border text-[10px] font-bold uppercase tracking-wider transition-all",
                        videoFilter === f 
                          ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                          : "border-slate-100 dark:border-slate-800 dark:text-slate-400 hover:border-indigo-500"
                      )}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <button
          onClick={generate}
          disabled={loading}
          className={cn(
            "w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black uppercase italic tracking-[0.3em] hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-2xl shadow-indigo-500/20 active:scale-95 flex items-center justify-center gap-4",
            !loading && !prompt.trim() && "opacity-70 grayscale-[0.5]"
          )}
        >
          {loading ? (
            <div className="flex items-center justify-center gap-3">
              <RefreshCw className="animate-spin" size={24} />
              <span>{status}</span>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-3">
              <Sparkles size={24} className="animate-pulse" />
              <span>Execute AI Synthesis</span>
            </div>
          )}
        </button>
      </div>

      <AnimatePresence mode="wait">
        {videoUrl && (
          <motion.div 
            key="pro-result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-black p-8 rounded-[3rem] border border-white/10 shadow-2xl space-y-8 overflow-hidden relative"
          >
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 blur-[120px] rounded-full" />
            <div className="flex items-center justify-between relative z-10">
              <div>
                <h4 className="text-2xl font-black text-white italic uppercase tracking-tighter">Cinematic Asset Export</h4>
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mt-1">Rendered via Advanced Neural Pipelines</p>
              </div>
              <a 
                href={videoUrl} 
                download="ai_advanced_render.mp4"
                className="flex items-center gap-3 px-8 py-4 bg-white text-black text-xs font-black uppercase italic tracking-widest rounded-3xl hover:bg-indigo-600 hover:text-white transition-all shadow-2xl active:scale-95"
              >
                <Download size={20} />
                Download Final Asset
              </a>
            </div>
            
            <div className="relative aspect-video rounded-[2.5rem] overflow-hidden group shadow-[0_0_60px_rgba(0,0,0,0.6)] border border-white/5 bg-slate-950">
              <video 
                src={videoUrl} 
                controls 
                autoPlay 
                loop 
                className="w-full h-full object-cover" 
                style={{
                  filter: videoFilter === 'vintage' ? 'sepia(0.5) contrast(1.2) brightness(0.9) hue-rotate(-10deg)' :
                          videoFilter === 'glitch' ? 'hue-rotate(90deg) saturate(2) contrast(1.5)' :
                          videoFilter === 'vibrant' ? 'saturate(1.8) contrast(1.1)' :
                          videoFilter === 'grayscale' ? 'grayscale(100%)' :
                          videoFilter === 'sepia' ? 'sepia(100%)' :
                          videoFilter === 'blur' ? 'blur(4px)' : 'none'
                }}
              />
              <div className="absolute inset-0 pointer-events-none border border-white/10 rounded-[2.5rem]" />
            </div>
          </motion.div>
        )}

        {loading && !videoUrl && (
          <motion.div 
            key="pro-loader"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white dark:bg-slate-900 border dark:border-slate-800 rounded-[3rem] p-16 flex flex-col items-center justify-center text-center space-y-12 relative overflow-hidden shadow-2xl"
          >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(79,70,229,0.05),transparent_70%)] animate-pulse" />
            
            <div className="relative">
              <div className="w-48 h-48 border-4 border-indigo-500/10 border-t-indigo-600 rounded-full animate-spin shadow-xl" />
              <div className="absolute inset-0 m-auto flex items-center justify-center">
                <RefreshCw className="text-indigo-600 animate-spin" size={48} />
              </div>
            </div>

            <div className="space-y-6 w-full max-w-lg relative z-10">
              <div className="space-y-2">
                <p className="text-3xl font-black text-slate-900 dark:text-white italic uppercase tracking-tighter drop-shadow-sm">{status}</p>
                <p className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.4em] italic animate-pulse">Advanced Geometry Synthesis Active</p>
              </div>
              
              <div className="space-y-3 px-8">
                <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800/50 rounded-full overflow-hidden border dark:border-slate-800">
                  <motion.div 
                    className="h-full bg-gradient-to-r from-indigo-600 to-blue-500 shadow-[0_0_20px_rgba(79,70,229,0.3)]"
                    initial={{ width: "0%" }}
                    animate={{ 
                      width: ["5%", "35%", "65%", "92%"],
                      transition: { duration: 60, ease: "easeInOut" }
                    }}
                  />
                </div>
                <div className="flex justify-between text-[8px] font-black text-slate-400 uppercase tracking-widest opacity-60">
                  <span>Kernels Initialized</span>
                  <span>Neural Rendering</span>
                  <span>Buffer Finalized</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const VideoToMP3 = () => {
  const [video, setVideo] = useState<File | null>(null);
  const [format, setFormat] = useState<'mp3' | 'wav' | 'aac'>('mp3');
  const [bitrate, setBitrate] = useState<'128k' | '192k' | '256k' | '320k'>('192k');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const ffmpegRef = useRef(new FFmpeg());

  const loadFFmpeg = async () => {
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
    const ffmpeg = ffmpegRef.current;
    if (ffmpeg.loaded) return;
    ffmpeg.on('progress', ({ progress }) => setProgress(Math.round(progress * 100)));
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
  };

  const extractAudio = async () => {
    if (!video) return;
    setLoading(true);
    setOutputUrl(null);
    setProgress(0);
    setStatus('Initializing...');
    try {
      const ffmpeg = ffmpegRef.current;
      await loadFFmpeg();
      setStatus('Processing...');
      const videoData = await fetchFile(video);
      const inputName = 'input_video';
      const outputName = `output_audio.${format === 'aac' ? 'm4a' : format}`;
      
      await ffmpeg.writeFile(inputName, videoData);
      
      const args = ['-i', inputName, '-vn'];
      
      if (format === 'mp3') {
        args.push('-acodec', 'libmp3lame', '-b:a', bitrate);
      } else if (format === 'aac') {
        args.push('-acodec', 'aac', '-b:a', bitrate);
      } else if (format === 'wav') {
        args.push('-acodec', 'pcm_s16le');
      }
      
      args.push(outputName);
      await ffmpeg.exec(args);
      
      const data = await ffmpeg.readFile(outputName);
      const blob = new Blob([data], { type: `audio/${format === 'aac' ? 'mp4' : format}` });
      setOutputUrl(URL.createObjectURL(blob));
      setStatus('Success!');
    } catch (error) {
      console.error(error);
      setStatus('Error extracting audio.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-black/40 p-8 rounded-3xl border border-red-500/20 shadow-xl space-y-6 glass-overlay">
        <div className="space-y-4">
          <label className="text-sm font-bold text-white">Upload Video</label>
          <div className="relative h-48 border-2 border-dashed border-red-500/20 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-red-500 glass-overlay">
            <div className="text-center p-4">
              <Upload className="mx-auto mb-2 text-red-500 group-hover:scale-110 transition-transform" size={32} />
              <p className="text-sm text-gray-300">Click to upload video</p>
            </div>
            <input type="file" onChange={(e) => setVideo(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept="video/*" />
          </div>
        </div>

        {video && (
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-red-500/20">
              <div className="flex items-center gap-3">
                <MusicIcon size={18} className="text-red-500" />
                <span className="text-sm text-white truncate max-w-[200px]">{video.name}</span>
              </div>
              <button onClick={() => setVideo(null)} className="text-gray-500 hover:text-red-500 transition-colors"><Trash2 size={18} /></button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Output Format</label>
                <div className="flex p-1 bg-black/40 rounded-xl border border-red-500/10">
                  {(['mp3', 'wav', 'aac'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setFormat(f)}
                      className={cn(
                        "flex-1 py-2 rounded-lg text-xs font-bold transition-all uppercase",
                        format === f ? "bg-red-600 text-white shadow-lg shadow-red-500/20" : "text-gray-500 hover:text-gray-300"
                      )}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              {format !== 'wav' && (
                <div className="space-y-3">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Audio Quality</label>
                  <select
                    value={bitrate}
                    onChange={(e) => setBitrate(e.target.value as any)}
                    className="w-full bg-black/40 border border-red-500/10 rounded-xl px-4 py-2 text-sm text-white focus:border-red-500 outline-none transition-all"
                  >
                    <option value="128k">128 kbps (Standard)</option>
                    <option value="192k">192 kbps (High)</option>
                    <option value="256k">256 kbps (Premium)</option>
                    <option value="320k">320 kbps (Ultra)</option>
                  </select>
                </div>
              )}
            </div>
          </div>
        )}

        {loading && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-white">
              <span>{status}</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <motion.div className="h-full bg-red-600" initial={{ width: 0 }} animate={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        <button
          onClick={extractAudio}
          disabled={loading || !video}
          className="w-full py-4 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 disabled:opacity-50 transition-all shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <FileAudio size={20} />}
          {loading ? 'Extracting...' : `Extract ${format.toUpperCase()}`}
        </button>
      </div>

      {outputUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-black/40 p-6 rounded-3xl border border-red-500/20 shadow-xl space-y-4 glass-overlay">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500/20 rounded-lg">
                <MusicIcon size={20} className="text-red-500" />
              </div>
              <div>
                <h4 className="font-bold text-white">Audio Extracted</h4>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest">{format} • {format === 'wav' ? 'Lossless' : bitrate}</p>
              </div>
            </div>
            <a href={outputUrl} download={`audio.${format === 'aac' ? 'm4a' : format}`} className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20">
              <Download size={16} /> Download
            </a>
          </div>
          <audio src={outputUrl} controls className="w-full custom-audio-player" />
        </motion.div>
      )}
    </div>
  );
};


const CSSMinifier = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [stats, setStats] = useState<{ original: number; minified: number } | null>(null);

  const minifyCSS = () => {
    if (!input.trim()) return;
    
    let minified = input
      .replace(/\/\*[\s\S]*?\*\//g, '') // Remove comments
      .replace(/\s+/g, ' ') // Collapse multiple spaces
      .replace(/\s*([\{\}:;,])\s*/g, '$1') // Remove spaces around special characters
      .replace(/;\}/g, '}') // Remove last semicolon
      .trim();

    setOutput(minified);
    setStats({
      original: input.length,
      minified: minified.length
    });
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white flex items-center gap-2">
            <Droplet className="text-blue-500" size={20} />
            CSS Input
          </label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste your CSS here..."
            className="w-full h-64 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none focus:border-indigo-500 transition-all font-mono text-sm resize-none"
          />
        </div>

        <button
          onClick={minifyCSS}
          disabled={!input.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          <Minimize2 size={20} />
          Minify CSS
        </button>
      </div>

      {output && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 text-green-600 rounded-2xl flex items-center justify-center">
                <CheckCircle2 size={24} />
              </div>
              <div>
                <h4 className="font-bold dark:text-white">Minification Complete</h4>
                {stats && (
                  <p className="text-sm text-slate-500">
                    Reduced from {stats.original} to {stats.minified} chars ({Math.round((1 - stats.minified / stats.original) * 100)}% smaller)
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={copyToClipboard}
              className="flex items-center gap-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 dark:text-white rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
            >
              <Copy size={20} />
              Copy Minified
            </button>
          </div>
          <textarea
            value={output}
            readOnly
            className="w-full h-64 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none font-mono text-sm resize-none"
          />
        </motion.div>
      )}
    </div>
  );
};

const JSMinifier = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [stats, setStats] = useState<{ original: number; minified: number } | null>(null);

  const minifyJS = () => {
    if (!input.trim()) return;
    
    // Very basic JS minification (removing comments and extra whitespace)
    // Note: This is NOT a full JS minifier like Terser, but works for simple scripts
    let minified = input
      .replace(/\/\*[\s\S]*?\*\//g, '') // Remove block comments
      .replace(/\/\/.*/g, '') // Remove line comments
      .replace(/\s+/g, ' ') // Collapse multiple spaces
      .replace(/\s*([\{\}:;,=\+\-\*\/<>!\(\)\[\]])\s*/g, '$1') // Remove spaces around operators
      .trim();

    setOutput(minified);
    setStats({
      original: input.length,
      minified: minified.length
    });
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white flex items-center gap-2">
            <Terminal className="text-yellow-500" size={20} />
            JavaScript Input
          </label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste your JavaScript here..."
            className="w-full h-64 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none focus:border-indigo-500 transition-all font-mono text-sm resize-none"
          />
        </div>

        <button
          onClick={minifyJS}
          disabled={!input.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          <Minimize2 size={20} />
          Minify JavaScript
        </button>
      </div>

      {output && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 text-green-600 rounded-2xl flex items-center justify-center">
                <CheckCircle2 size={24} />
              </div>
              <div>
                <h4 className="font-bold dark:text-white">Minification Complete</h4>
                {stats && (
                  <p className="text-sm text-slate-500">
                    Reduced from {stats.original} to {stats.minified} chars ({Math.round((1 - stats.minified / stats.original) * 100)}% smaller)
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={copyToClipboard}
              className="flex items-center gap-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 dark:text-white rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
            >
              <Copy size={20} />
              Copy Minified
            </button>
          </div>
          <textarea
            value={output}
            readOnly
            className="w-full h-64 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none font-mono text-sm resize-none"
          />
        </motion.div>
      )}
    </div>
  );
};

const HTMLMinifier = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [stats, setStats] = useState<{ original: number; minified: number } | null>(null);

  const minifyHTML = () => {
    if (!input.trim()) return;
    
    // Simple HTML minification logic
    let minified = input
      .replace(/<!--[\s\S]*?-->/g, '') // Remove comments
      .replace(/\s+/g, ' ') // Collapse multiple spaces
      .replace(/>\s+</g, '><') // Remove space between tags
      .trim();

    setOutput(minified);
    setStats({
      original: input.length,
      minified: minified.length
    });
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white flex items-center gap-2">
            <Code className="text-indigo-600" size={20} />
            HTML Input
          </label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste your HTML here..."
            className="w-full h-64 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none focus:border-indigo-500 transition-all font-mono text-sm resize-none"
          />
        </div>

        <button
          onClick={minifyHTML}
          disabled={!input.trim()}
          className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2"
        >
          <Minimize2 size={20} />
          Minify HTML
        </button>
      </div>

      {output && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 text-green-600 rounded-2xl flex items-center justify-center">
                <CheckCircle2 size={24} />
              </div>
              <div>
                <h4 className="font-bold dark:text-white">Minification Complete</h4>
                {stats && (
                  <p className="text-sm text-slate-500">
                    Reduced from {stats.original} to {stats.minified} chars ({Math.round((1 - stats.minified / stats.original) * 100)}% smaller)
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={copyToClipboard}
              className="flex items-center gap-2 px-6 py-3 bg-slate-100 dark:bg-slate-800 dark:text-white rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
            >
              <Copy size={20} />
              Copy Minified
            </button>
          </div>
          <textarea
            value={output}
            readOnly
            className="w-full h-64 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none font-mono text-sm resize-none"
          />
        </motion.div>
      )}
    </div>
  );
};

const ThemeToggler = ({ darkMode, toggleDarkMode }: { darkMode: boolean; toggleDarkMode: () => void }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-8 text-center">
        <div className="space-y-4">
          <div className="w-20 h-20 bg-indigo-100 dark:bg-indigo-900/20 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
            {darkMode ? <Moon size={40} /> : <Sun size={40} />}
          </div>
          <h2 className="text-3xl font-bold dark:text-white">
            Current Theme: <span className="text-indigo-600">{darkMode ? 'Dark' : 'Light'}</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Toggle between light and dark modes to see how the application's appearance changes instantly.
          </p>
        </div>

        <div className="flex justify-center">
          <button
            onClick={toggleDarkMode}
            className="group relative flex items-center gap-4 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/25 active:scale-95"
          >
            {darkMode ? (
              <>
                <Sun size={24} className="group-hover:rotate-90 transition-transform duration-500" />
                Switch to Light Mode
              </>
            ) : (
              <>
                <Moon size={24} className="group-hover:-rotate-12 transition-transform duration-500" />
                Switch to Dark Mode
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 border-t dark:border-slate-800">
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800 space-y-3">
            <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 text-blue-600 rounded-xl flex items-center justify-center mx-auto">
              <Layout size={20} />
            </div>
            <h4 className="font-bold dark:text-white">UI Elements</h4>
            <p className="text-xs text-slate-500">Buttons, inputs, and cards adapt their colors.</p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800 space-y-3">
            <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/20 text-purple-600 rounded-xl flex items-center justify-center mx-auto">
              <Type size={20} />
            </div>
            <h4 className="font-bold dark:text-white">Typography</h4>
            <p className="text-xs text-slate-500">Text contrast is automatically optimized.</p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border dark:border-slate-800 space-y-3">
            <div className="w-10 h-10 bg-green-100 dark:bg-green-900/20 text-green-600 rounded-xl flex items-center justify-center mx-auto">
              <Shield size={20} />
            </div>
            <h4 className="font-bold dark:text-white">Accessibility</h4>
            <p className="text-xs text-slate-500">Ensures readability in any lighting condition.</p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <h3 className="text-xl font-bold dark:text-white flex items-center gap-2">
          <Code className="text-indigo-600" size={24} />
          Theme Variables
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border dark:border-slate-800 font-mono text-sm">
            <p className="text-indigo-600 font-bold mb-2">Background</p>
            <code className="dark:text-slate-300">{darkMode ? 'bg-slate-950' : 'bg-white'}</code>
          </div>
          <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border dark:border-slate-800 font-mono text-sm">
            <p className="text-indigo-600 font-bold mb-2">Text Main</p>
            <code className="dark:text-slate-300">{darkMode ? 'text-white' : 'text-slate-900'}</code>
          </div>
          <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border dark:border-slate-800 font-mono text-sm">
            <p className="text-indigo-600 font-bold mb-2">Border</p>
            <code className="dark:text-slate-300">{darkMode ? 'border-slate-800' : 'border-slate-200'}</code>
          </div>
          <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border dark:border-slate-800 font-mono text-sm">
            <p className="text-indigo-600 font-bold mb-2">Primary</p>
            <code className="dark:text-slate-300">bg-indigo-600</code>
          </div>
        </div>
      </div>
    </div>
  );
};

const VideoDownloader = () => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<any[]>([]);

  const handleDownload = async () => {
    if (!url) return;
    setLoading(true);
    setError(null);
    setResults([]);
    setStatus('Starting download task...');

    try {
      const response = await fetch('/api/video/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to start download');

      const runId = data.data.id;
      
      // Poll for status
      const poll = setInterval(async () => {
        try {
          const statusRes = await fetch(`/api/video/download/status/${runId}`);
          const statusData = await statusRes.json();

          if (statusData.status === 'SUCCEEDED') {
            clearInterval(poll);
            setResults(statusData.results);
            setLoading(false);
            setStatus('Download ready!');
          } else if (statusData.status === 'FAILED' || statusData.status === 'ABORTED') {
            clearInterval(poll);
            setError('Download task failed on server.');
            setLoading(false);
          } else {
            setStatus(`Processing... Status: ${statusData.status}`);
          }
        } catch (err) {
          clearInterval(poll);
          setError('Error checking status');
          setLoading(false);
        }
      }, 3000);

    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white flex items-center gap-2">
            <Youtube className="text-red-600" size={20} />
            YouTube Video URL
          </label>
          <div className="flex flex-col sm:flex-row gap-4">
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="flex-1 px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none focus:border-indigo-500 transition-all"
            />
            <button
              onClick={handleDownload}
              disabled={loading}
              className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              {loading ? <RefreshCw className="animate-spin" size={20} /> : <Download size={20} />}
              {loading ? 'Processing...' : 'Download Video'}
            </button>
          </div>
          {status && !error && <p className="text-sm text-indigo-500 font-medium">{status}</p>}
          {error && <p className="text-sm text-red-500 font-medium">{error}</p>}
        </div>

        {results.length > 0 && (
          <div className="grid gap-6 mt-8">
            {results.map((item, idx) => (
              <div key={idx} className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border dark:border-slate-700 flex flex-col md:flex-row gap-6 items-center">
                <img 
                  src={item.thumbnail} 
                  alt={item.title} 
                  className="w-full md:w-48 aspect-video object-cover rounded-xl shadow-md"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 space-y-2 text-center md:text-left">
                  <h3 className="font-bold dark:text-white line-clamp-2">{item.title}</h3>
                  <p className="text-sm text-slate-500">{item.durationText} • {item.viewCountText}</p>
                  <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                    {item.downloadOptions?.map((opt: any, i: number) => (
                      <a
                        key={i}
                        href={opt.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-white dark:bg-slate-700 border dark:border-slate-600 rounded-lg text-xs font-bold dark:text-white hover:bg-indigo-50 dark:hover:bg-slate-600 transition-all flex items-center gap-2"
                      >
                        <Download size={14} />
                        {opt.quality} ({opt.ext})
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const YouTubeThumbnailDownloader = () => {
  const [url, setUrl] = useState('');
  const [videoId, setVideoId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  const extractVideoId = (url: string) => {
    const regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[7].length === 11) ? match[7] : null;
  };

  const handleGetThumbnail = () => {
    setError(null);
    const id = extractVideoId(url);
    if (id) {
      setVideoId(id);
    } else {
      setError('Invalid YouTube URL. Please enter a valid link.');
      setVideoId(null);
    }
  };

  const downloadImage = async (imgUrl: string, filename: string) => {
    setDownloading(imgUrl);
    try {
      const response = await fetch(imgUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Download failed:', err);
      // Fallback: open in new tab
      window.open(imgUrl, '_blank');
    } finally {
      setDownloading(null);
    }
  };

  const resolutions = [
    { id: 'maxresdefault', name: 'Maximum Resolution (HD)', size: '1280x720' },
    { id: 'sddefault', name: 'Standard Definition', size: '640x480' },
    { id: 'hqdefault', name: 'High Quality', size: '480x360' },
    { id: 'mqdefault', name: 'Medium Quality', size: '320x180' },
    { id: 'default', name: 'Default Quality', size: '120x90' },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6">
        <div className="space-y-4">
          <label className="text-sm font-bold dark:text-white flex items-center gap-2">
            <Youtube className="text-red-600" size={20} />
            YouTube Video URL
          </label>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 group">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full px-6 py-4 rounded-2xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-white outline-none focus:border-indigo-500 transition-all text-lg font-medium"
              />
            </div>
            <button
              onClick={handleGetThumbnail}
              className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <Search size={20} />
              Get Thumbnails
            </button>
          </div>
          {error && <p className="text-red-500 text-sm font-medium">{error}</p>}
        </div>
      </div>

      {videoId && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Main Preview */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="lg:col-span-2 bg-white dark:bg-slate-900 p-8 rounded-3xl border dark:border-slate-800 shadow-xl space-y-6"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold dark:text-white">HD Preview</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => downloadImage(`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`, `yt_thumb_maxres_${videoId}.jpg`)}
                  className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-500/20 disabled:opacity-50"
                  disabled={downloading === `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                >
                  {downloading === `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` ? <RefreshCw className="animate-spin" size={20} /> : <Download size={20} />}
                  Download HD
                </button>
              </div>
            </div>
            <div className="relative aspect-video rounded-2xl overflow-hidden border-4 border-slate-100 dark:border-slate-800 shadow-inner group">
              <img
                src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                alt="YouTube Thumbnail HD"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                }}
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Play size={64} className="text-white fill-white" />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-500 uppercase tracking-wider">Download All Resolutions</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {resolutions.map((res) => (
                  <button
                    key={res.id}
                    onClick={() => downloadImage(`https://img.youtube.com/vi/${videoId}/${res.id}.jpg`, `yt_thumb_${res.id}_${videoId}.jpg`)}
                    className="flex flex-col items-center justify-center gap-2 p-4 bg-slate-50 dark:bg-slate-800/50 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 border dark:border-slate-800 rounded-2xl transition-all group disabled:opacity-50"
                    disabled={downloading === `https://img.youtube.com/vi/${videoId}/${res.id}.jpg`}
                  >
                    {downloading === `https://img.youtube.com/vi/${videoId}/${res.id}.jpg` ? (
                      <RefreshCw className="animate-spin text-indigo-600" size={20} />
                    ) : (
                      <Download size={20} className="text-slate-400 group-hover:text-indigo-600 transition-colors" />
                    )}
                    <div className="text-center">
                      <p className="text-[10px] font-bold dark:text-white truncate w-full">{res.name.split(' ')[0]}</p>
                      <p className="text-[10px] text-slate-500">{res.size}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* All Resolutions */}
          {resolutions.map((res, idx) => (
            <motion.div
              key={res.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-lg flex flex-col sm:flex-row gap-6 items-center"
            >
              <div className="w-full sm:w-48 aspect-video rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 flex-shrink-0">
                <img
                  src={`https://img.youtube.com/vi/${videoId}/${res.id}.jpg`}
                  alt={res.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 space-y-4 text-center sm:text-left w-full">
                <div>
                  <h4 className="font-bold dark:text-white">{res.name}</h4>
                  <p className="text-xs text-slate-500">{res.size}</p>
                </div>
                <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
                  <a
                    href={`https://img.youtube.com/vi/${videoId}/${res.id}.jpg`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-slate-100 dark:bg-slate-800 dark:text-white rounded-lg text-sm font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center gap-2"
                  >
                    <Eye size={16} />
                    View
                  </a>
                  <button
                    onClick={() => downloadImage(`https://img.youtube.com/vi/${videoId}/${res.id}.jpg`, `yt_thumb_${res.id}_${videoId}.jpg`)}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition-all flex items-center gap-2 disabled:opacity-50"
                    disabled={downloading === `https://img.youtube.com/vi/${videoId}/${res.id}.jpg`}
                  >
                    {downloading === `https://img.youtube.com/vi/${videoId}/${res.id}.jpg` ? <RefreshCw className="animate-spin" size={16} /> : <Download size={16} />}
                    Download
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

const VideoCompressor = () => {
  const [video, setVideo] = useState<File | null>(null);
  const [compressionLevel, setCompressionLevel] = useState<'low' | 'medium' | 'high'>('medium');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [originalSize, setOriginalSize] = useState(0);
  const [compressedSize, setCompressedSize] = useState(0);
  const ffmpegRef = useRef(new FFmpeg());

  const loadFFmpeg = async () => {
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
    const ffmpeg = ffmpegRef.current;
    if (ffmpeg.loaded) return;
    ffmpeg.on('progress', ({ progress }) => setProgress(Math.round(progress * 100)));
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
  };

  const compressVideo = async () => {
    if (!video) return;
    setLoading(true);
    setOutputUrl(null);
    setProgress(0);
    setStatus('Initializing...');
    try {
      const ffmpeg = ffmpegRef.current;
      await loadFFmpeg();
      setStatus('Processing...');
      const videoData = await fetchFile(video);
      await ffmpeg.writeFile('input.mp4', videoData);
      let crf = '28';
      if (compressionLevel === 'low') crf = '22';
      if (compressionLevel === 'high') crf = '35';
      await ffmpeg.exec(['-i', 'input.mp4', '-vcodec', 'libx264', '-crf', crf, '-preset', 'veryfast', 'output.mp4']);
      const data = await ffmpeg.readFile('output.mp4');
      const blob = new Blob([data], { type: 'video/mp4' });
      setOutputUrl(URL.createObjectURL(blob));
      setStatus('Success!');
    } catch (error) {
      console.error(error);
      setStatus('Error compressing video.');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setVideo(null);
    setOutputUrl(null);
    setProgress(0);
    setStatus('');
    setOriginalSize(0);
    setCompressedSize(0);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-black/40 p-8 rounded-3xl border border-red-500/20 shadow-xl space-y-6 glass-overlay">
        <div className="space-y-4">
          <label className="text-sm font-bold text-white">Upload Video</label>
          <div className="relative h-48 border-2 border-dashed border-red-500/20 rounded-2xl flex items-center justify-center overflow-hidden group transition-all hover:border-red-500 glass-overlay">
            <div className="text-center p-4">
              <Upload className="mx-auto mb-2 text-red-500 group-hover:scale-110 transition-transform" size={32} />
              <p className="text-sm text-gray-300">Click to upload video</p>
            </div>
            <input type="file" onChange={(e) => setVideo(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept="video/*" />
          </div>
        </div>

        {video && (
          <div className="space-y-4">
            <label className="text-sm font-bold text-white">Compression Level</label>
            <div className="grid grid-cols-3 gap-3">
              {(['low', 'medium', 'high'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setCompressionLevel(level)}
                  className={cn(
                    "py-3 rounded-xl font-bold transition-all capitalize border",
                    compressionLevel === level ? "bg-red-600 text-white border-red-600" : "bg-black/40 text-gray-400 border-red-500/20 hover:border-red-500"
                  )}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>
        )}

        {loading && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-white">
              <span>{status}</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <motion.div className="h-full bg-red-600" initial={{ width: 0 }} animate={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        <button
          onClick={compressVideo}
          disabled={loading || !video}
          className="w-full py-4 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 disabled:opacity-50 transition-all shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <Play size={20} />}
          {loading ? 'Compressing...' : 'Compress Video'}
        </button>
      </div>

      {outputUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-black/40 p-6 rounded-3xl border border-red-500/20 shadow-xl space-y-4 glass-overlay">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-white">Result</h4>
            <a href={outputUrl} download="compressed.mp4" className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20">
              <Download size={16} /> Download Video
            </a>
          </div>
          <video src={outputUrl} controls className="w-full rounded-2xl border border-red-500/20" />
        </motion.div>
      )}
    </div>
  );
};

const VideoConverter = () => {
  const [video, setVideo] = useState<File | null>(null);
  const [targetFormat, setTargetFormat] = useState<'mp4' | 'webm'>('mp4');
  const [loading, setLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [progress, setProgress] = useState(0);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const ffmpegRef = useRef(new FFmpeg());

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setVideo(file);
    }
  };

  const loadFFmpeg = async () => {
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
    const ffmpeg = ffmpegRef.current;
    if (ffmpeg.loaded) return;
    ffmpeg.on('progress', ({ progress }) => setProgress(Math.round(progress * 100)));
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
  };

  const convertVideo = async () => {
    if (!video) return;
    setLoading(true);
    setOutputUrl(null);
    setProgress(0);
    setStatus('Initializing...');
    try {
      const ffmpeg = ffmpegRef.current;
      await loadFFmpeg();
      setStatus('Processing...');
      const videoData = await fetchFile(video);
      await ffmpeg.writeFile('input', videoData);
      const outputName = `output.${targetFormat}`;
      await ffmpeg.exec(['-i', 'input', outputName]);
      const data = await ffmpeg.readFile(outputName);
      const blob = new Blob([data], { type: `video/${targetFormat}` });
      setOutputUrl(URL.createObjectURL(blob));
      setStatus('Success!');
    } catch (error) {
      console.error(error);
      setStatus('Error converting video.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-black/40 p-8 rounded-3xl border border-red-500/20 shadow-xl space-y-6 glass-overlay">
        <div className="space-y-4">
          <label className="text-sm font-bold text-white">Upload Video</label>
          <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              "relative h-48 border-2 border-dashed rounded-2xl flex items-center justify-center overflow-hidden group transition-all glass-overlay",
              isDragging ? "border-red-500 bg-red-500/10 scale-[1.02]" : "border-red-500/20 hover:border-red-500"
            )}
          >
            <div className="text-center p-4 pointer-events-none">
              <Upload className={cn("mx-auto mb-2 text-red-500 transition-transform", isDragging ? "scale-125" : "group-hover:scale-110")} size={32} />
              <p className="text-sm text-gray-300">
                {isDragging ? "Drop video here" : "Click or drag video here"}
              </p>
              {video && <p className="text-xs text-red-400 mt-2 font-bold">Selected: {video.name}</p>}
            </div>
            <input type="file" onChange={(e) => setVideo(e.target.files?.[0] || null)} className="absolute inset-0 opacity-0 cursor-pointer" accept="video/*" />
          </div>
        </div>

        {video && (
          <div className="space-y-4">
            <label className="text-sm font-bold text-white">Target Format</label>
            <div className="grid grid-cols-2 gap-3">
              {(['mp4', 'webm'] as const).map((format) => (
                <button
                  key={format}
                  onClick={() => setTargetFormat(format)}
                  className={cn(
                    "py-3 rounded-xl font-bold transition-all capitalize border",
                    targetFormat === format ? "bg-red-600 text-white border-red-600" : "bg-black/40 text-gray-400 border-red-500/20 hover:border-red-500"
                  )}
                >
                  {format.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        )}

        {loading && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-white">
              <span>{status}</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <motion.div className="h-full bg-red-600" initial={{ width: 0 }} animate={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        <button
          onClick={convertVideo}
          disabled={loading || !video}
          className="w-full py-4 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 disabled:opacity-50 transition-all shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
        >
          {loading ? <RefreshCw className="animate-spin" size={20} /> : <Play size={20} />}
          {loading ? 'Converting...' : 'Convert Video'}
        </button>
      </div>

      {outputUrl && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-black/40 p-6 rounded-3xl border border-red-500/20 shadow-xl space-y-4 glass-overlay">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-white">Result</h4>
            <a href={outputUrl} download={`converted.${targetFormat}`} className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20">
              <Download size={16} /> Download Video
            </a>
          </div>
          <video src={outputUrl} controls className="w-full rounded-2xl border border-red-500/20" />
        </motion.div>
      )}
    </div>
  );
};

const EDITOR_MODES = [
  { id: 'trim', label: 'Trim', icon: Scissors, description: 'Start and end point selection' },
  { id: 'merge', label: 'Merge', icon: Layers, description: 'Combine multiple clips' },
  { id: 'speed', label: 'Speed', icon: Gauge, description: 'Adjust playback velocity' },
  { id: 'crop', label: 'Crop', icon: Crop, description: 'Reframe and resize canvas' },
  { id: 'effects', label: 'Effects', icon: Palette, description: 'Apply visual style filters' },
  { id: 'adjust', label: 'Adjust', icon: SlidersHorizontal, description: 'Color and light balance' },
  { id: 'volume', label: 'Volume', icon: Volume2, description: 'Audio gain and muting' },
] as const;

const VideoEditorPro = ({ initialMode = 'trim' }: { initialMode?: 'trim' | 'merge' | 'speed' | 'effects' | 'adjust' | 'brightness' | 'contrast' | 'hue' | 'volume' | 'mute' | 'crop' }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [mode, setMode] = useState<typeof initialMode>(initialMode);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(0);
  const [duration, setDuration] = useState(0);
  const [speed, setSpeed] = useState(1.0);
  const [effect, setEffect] = useState<'none' | 'vintage' | 'glitch' | 'vibrant' | 'grayscale' | 'sepia'>('none');
  const [brightness, setBrightness] = useState(1.0);
  const [contrast, setContrast] = useState(1.0);
  const [hue, setHue] = useState(0);
  const [intensity, setIntensity] = useState(1.0);
  const [crop, setCrop] = useState({ x: 0, y: 0, width: 100, height: 100 });
  const [aspectRatio, setAspectRatio] = useState('original');
  const [videoSize, setVideoSize] = useState({ width: 0, height: 0 });
  const [volume, setVolume] = useState(1.0);
  const [muteAudio, setMuteAudio] = useState(false);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);
  const [previewStyle, setPreviewStyle] = useState<React.CSSProperties>({});
  const ffmpegRef = useRef(new FFmpeg());
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let filter = "";
    if (effect === 'vintage') filter = `sepia(${0.5 * intensity}) contrast(${1 + 0.2 * intensity}) brightness(${1 - 0.1 * intensity}) hue-rotate(${-10 * intensity}deg)`;
    else if (effect === 'glitch') filter = `hue-rotate(${90 * intensity}deg) saturate(${1 + intensity}) contrast(${1 + 0.5 * intensity})`;
    else if (effect === 'vibrant') filter = `saturate(${1 + 0.8 * intensity}) contrast(${1 + 0.1 * intensity})`;
    else if (effect === 'grayscale') filter = `grayscale(${intensity})`;
    else if (effect === 'sepia') filter = `sepia(${intensity})`;

    if (brightness !== 1 || contrast !== 1) {
      filter += ` brightness(${brightness}) contrast(${contrast})`;
    }

    if (hue !== 0) {
      filter += ` hue-rotate(${hue}deg)`;
    }

    setPreviewStyle({ filter });
  }, [effect, brightness, contrast, hue, intensity]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = muteAudio ? 0 : volume;
    }
  }, [volume, muteAudio]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  }, [speed]);

  const loadFFmpeg = async () => {
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
    const ffmpeg = ffmpegRef.current;
    if (ffmpeg.loaded) return;
    
    ffmpeg.on('log', ({ message }) => console.log(message));
    ffmpeg.on('progress', ({ progress }) => setProgress(Math.round(progress * 100)));
    
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      
      // Cleanup old preview URL if needed
      if (previewUrl && !files.find(f => URL.createObjectURL(f as Blob) === previewUrl)) {
        // This is tricky because we can't easily track which URL belongs to which file without a Map
        // For simplicity, we just revoke the current one if we're replacing the whole set
      }

      if (mode !== 'merge') {
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        const file = newFiles[0] as File;
        setFiles([file]);
        setPreviewUrl(URL.createObjectURL(file as Blob));
        setSelectedFileIndex(0);
      } else {
        const addedFiles = [...files, ...newFiles];
        setFiles(addedFiles);
        if (!previewUrl && addedFiles.length > 0) {
          setPreviewUrl(URL.createObjectURL(addedFiles[0] as Blob));
          setSelectedFileIndex(0);
        }
      }
      setOutputUrl(null);
    }
  };

  const handlePreviewFile = (index: number) => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    const url = URL.createObjectURL(files[index] as Blob);
    setPreviewUrl(url);
    setSelectedFileIndex(index);
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${[h, m, s].map(v => v.toString().padStart(2, '0')).join(':')}.${ms}`;
  };

  const handleAspectRatioChange = (ratio: string) => {
    setAspectRatio(ratio);
    if (ratio === 'original' || videoSize.width === 0) {
      setCrop({ x: 0, y: 0, width: 100, height: 100 });
      return;
    }

    const [rw, rh] = ratio.split(':').map(Number);
    const targetRatio = rw / rh;
    const videoRatio = videoSize.width / videoSize.height;

    let newWidth = 100;
    let newHeight = 100;

    if (targetRatio > videoRatio) {
      newHeight = (100 * videoRatio) / targetRatio;
      newWidth = 100;
    } else {
      newWidth = (100 * targetRatio) / videoRatio;
      newHeight = 100;
    }

    setCrop({
      x: (100 - newWidth) / 2,
      y: (100 - newHeight) / 2,
      width: newWidth,
      height: newHeight
    });
  };

  const moveFile = (index: number, direction: 'up' | 'down') => {
    const newFiles = [...files];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex >= 0 && targetIndex < newFiles.length) {
      [newFiles[index], newFiles[targetIndex]] = [newFiles[targetIndex], newFiles[index]];
      setFiles(newFiles);
    }
  };

  const processVideo = async () => {
    if (files.length === 0) return;
    setLoading(true);
    setProgress(0);
    setStatus('Initializing FFmpeg...');
    
    try {
      const ffmpeg = ffmpegRef.current;
      await loadFFmpeg();

      const inputName = 'input.mp4';
      const outputName = 'output.mp4';

      if (mode === 'merge') {
        setStatus('Merging videos...');
        const inputFiles: string[] = [];
        for (let i = 0; i < files.length; i++) {
          const data = await fetchFile(files[i]);
          const name = `input${i}.mp4`;
          await ffmpeg.writeFile(name, data);
          inputFiles.push(`file '${name}'`);
        }
        await ffmpeg.writeFile('concat.txt', inputFiles.join('\n'));
        const mergeArgs = ['-f', 'concat', '-safe', '0', '-i', 'concat.txt'];
        if (muteAudio) {
          mergeArgs.push('-an');
        }
        mergeArgs.push(outputName);
        await ffmpeg.exec(mergeArgs);
      } else {
        const file = files[0];
        const data = await fetchFile(file);
        await ffmpeg.writeFile(inputName, data);

        const args = ['-i', inputName];
        let vf = [];

        if (mode === 'trim') {
          args.push('-ss', trimStart.toFixed(3), '-to', trimEnd.toFixed(3));
        }

        if (mode === 'crop' || aspectRatio !== 'original') {
          const x = Math.floor((crop.x / 100) * videoSize.width);
          const y = Math.floor((crop.y / 100) * videoSize.height);
          const w = Math.floor((crop.width / 100) * videoSize.width);
          const h = Math.floor((crop.height / 100) * videoSize.height);
          vf.push(`crop=${w}:${h}:${x}:${y}`);
        }

        if (effect !== 'none') {
          if (effect === 'vintage') {
            vf.push(`colorchannelmixer=${.393*intensity + (1-intensity)}:${.769*intensity}:${.189*intensity}:0:${.349*intensity}:${.686*intensity + (1-intensity)}:${.168*intensity}:0:${.272*intensity}:${.534*intensity}:${.131*intensity + (1-intensity)}`);
            vf.push(`noise=alls=${10*intensity}:allf=t+u`);
          } else if (effect === 'glitch') {
            vf.push(`rgbashift=rh=${5*intensity}:bv=${-5*intensity},noise=alls=${20*intensity}:allf=t+u`);
          } else if (effect === 'vibrant') {
            vf.push(`eq=saturation=${1 + 0.5*intensity}:contrast=${1 + 0.1*intensity}`);
          } else if (effect === 'grayscale') {
            vf.push(`hue=s=${1-intensity}`);
          } else if (effect === 'sepia') {
            vf.push(`colorchannelmixer=${.393*intensity + (1-intensity)}:${.769*intensity}:${.189*intensity}:0:${.349*intensity}:${.686*intensity + (1-intensity)}:${.168*intensity}:0:${.272*intensity}:${.534*intensity}:${.131*intensity + (1-intensity)}`);
          }
        }

        if (brightness !== 1.0 || contrast !== 1.0) {
          vf.push(`eq=brightness=${(brightness - 1).toFixed(2)}:contrast=${contrast.toFixed(2)}`);
        }

        if (hue !== 0) {
          vf.push(`hue=h=${hue}`);
        }

        if (speed !== 1.0) {
          vf.push(`setpts=${(1/speed).toFixed(4)}*PTS`);
        }

        if (vf.length > 0) {
          if ((speed !== 1.0 || volume !== 1.0) && !muteAudio) {
            let audioFilters = [];
            if (speed !== 1.0) audioFilters.push(`atempo=${speed.toFixed(4)}`);
            if (volume !== 1.0) audioFilters.push(`volume=${volume.toFixed(2)}`);
            const audioFilter = audioFilters.join(',');
            args.push('-filter_complex', `[0:v]${vf.join(',')}[v];[0:a]${audioFilter}[a]`, '-map', '[v]', '-map', '[a]');
          } else {
            args.push('-vf', vf.join(','));
          }
        } else if (volume !== 1.0 && !muteAudio) {
          args.push('-af', `volume=${volume.toFixed(2)}`);
        }

        if (muteAudio) {
          args.push('-an');
        }

        args.push(outputName);
        setStatus('Processing video...');
        await ffmpeg.exec(args);
      }

      const data = await ffmpeg.readFile(outputName);
      const blob = new Blob([data], { type: 'video/mp4' });
      setOutputUrl(URL.createObjectURL(blob));
      setStatus('Success!');
    } catch (error) {
      console.error("Video Editor Error:", error);
      setStatus('Error processing video. Check console for details.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar Navigation */}
        <aside className="lg:w-72 space-y-4">
          <div className="bg-black/40 p-6 rounded-3xl border border-red-500/20 glass-overlay">
            <h3 className="text-xs font-black text-red-500 uppercase tracking-widest mb-4">Editing Modes</h3>
            <div className="space-y-1">
              {EDITOR_MODES.map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    setMode(m.id as any);
                    if (m.id !== 'merge') {
                      setFiles(prev => prev.slice(0, 1));
                    }
                    setOutputUrl(null);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 p-3 rounded-2xl transition-all text-left group",
                    (mode === m.id || (m.id === 'adjust' && ['brightness', 'contrast', 'hue'].includes(mode)) || (m.id === 'volume' && mode === 'mute'))
                      ? "bg-red-600 text-white shadow-lg shadow-red-600/20" 
                      : "text-slate-400 hover:bg-red-500/10 hover:text-red-500"
                  )}
                >
                  <div className={cn(
                    "p-2 rounded-xl",
                    (mode === m.id || (m.id === 'adjust' && ['brightness', 'contrast', 'hue'].includes(mode)) || (m.id === 'volume' && mode === 'mute'))
                      ? "bg-white/20" 
                      : "bg-slate-800 group-hover:bg-red-500/20 transition-colors"
                  )}>
                    <m.icon size={18} />
                  </div>
                  <div>
                    <p className="text-sm font-bold leading-none">{m.label}</p>
                    <p className={cn(
                      "text-[10px] mt-1 line-clamp-1 opacity-60",
                      (mode === m.id || (m.id === 'adjust' && ['brightness', 'contrast', 'hue'].includes(mode)) || (m.id === 'volume' && mode === 'mute'))
                        ? "text-white" 
                        : "text-slate-500"
                    )}>
                      {m.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-black/40 p-6 rounded-3xl border border-red-500/20 glass-overlay">
             <div className="space-y-4">
              <label className="text-xs font-black text-gray-500 uppercase tracking-widest flex items-center justify-between">
                Source Files
                <VideoIcon size={12} />
              </label>
              
              <div className="relative border-2 border-dashed border-red-500/20 rounded-2xl p-4 flex flex-col items-center justify-center text-center group hover:border-red-500 transition-all cursor-pointer">
                <Upload size={24} className="text-red-500 mb-2 group-hover:scale-110 transition-transform" />
                <p className="text-[10px] font-bold text-gray-400">Click or drag to add files</p>
                <input 
                  type="file" 
                  onChange={handleFileChange} 
                  multiple={mode === 'merge'}
                  className="absolute inset-0 opacity-0 cursor-pointer" 
                  accept="video/*" 
                />
              </div>

              {files.length > 0 && (
                <div className="max-h-48 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                  {files.map((f, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-white/5 rounded-xl border border-white/10 group">
                      <div className="flex items-center gap-2 min-w-0">
                        {mode === 'merge' && (
                          <div className="flex flex-col">
                            <button disabled={i === 0} onClick={() => moveFile(i, 'up')} className="text-gray-600 hover:text-red-500 disabled:opacity-20"><ChevronUp size={10} /></button>
                            <button disabled={i === files.length - 1} onClick={() => moveFile(i, 'down')} className="text-gray-600 hover:text-red-500 disabled:opacity-20"><ChevronDown size={10} /></button>
                          </div>
                        )}
                        <button 
                          onClick={() => handlePreviewFile(i)}
                          className={cn(
                            "text-[10px] font-medium truncate text-left flex-1 hover:text-red-500 transition-colors",
                            selectedFileIndex === i ? "text-red-500 font-bold" : "text-gray-300"
                          )}
                        >
                          {f.name}
                        </button>
                      </div>
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={() => handlePreviewFile(i)}
                          className={cn(
                            "p-1 rounded-md transition-colors",
                            selectedFileIndex === i ? "text-red-500 bg-red-500/10" : "text-gray-500 hover:text-red-500 hover:bg-red-500/10"
                          )}
                        >
                          <Play size={10} />
                        </button>
                        <button onClick={() => setFiles(prev => prev.filter((_, idx) => idx !== i))} className="p-1 text-gray-600 hover:text-red-500 transition-colors">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </aside>

        {/* Main Editor Section */}
        <main className="flex-1 space-y-6">
          <div className="bg-black/40 p-8 rounded-[2rem] border border-red-500/20 shadow-xl space-y-6 glass-overlay relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 blur-3xl -mr-32 -mt-32 rounded-full" />
            
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center text-red-500 border border-red-500/20">
                  <Play size={20} />
                </div>
                <div>
                  <h2 className="text-xl font-black text-white tracking-tight uppercase italic line-clamp-1">
                    {mode === 'merge' ? 'Timeline Merger' : `${mode} Workspace`}
                  </h2>
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Editor Pro • Local Rendering</p>
                </div>
              </div>
              
              {files.length > 0 && (
                <button
                  onClick={processVideo}
                  disabled={loading}
                  className="px-6 py-2 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-600/20 active:scale-95 flex items-center gap-2 text-sm disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <RefreshCw size={16} className="animate-spin" />
                      {progress}% Done
                    </>
                  ) : (
                    <>
                      Apply & Export
                      <Download size={16} />
                    </>
                  )}
                </button>
              )}
            </div>

            {previewUrl ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                    Previewing: <span className="text-red-500">{files[selectedFileIndex]?.name || 'Unknown File'}</span>
                  </p>
                  {files.length > 1 && (
                    <div className="flex items-center gap-2">
                       <button 
                        disabled={selectedFileIndex === 0}
                        onClick={() => handlePreviewFile(selectedFileIndex - 1)}
                        className="p-1 text-gray-500 hover:text-red-500 disabled:opacity-20"
                      >
                        <ChevronLeft size={16} />
                      </button>
                      <span className="text-[10px] font-mono text-gray-500">{selectedFileIndex + 1} / {files.length}</span>
                      <button 
                        disabled={selectedFileIndex === files.length - 1}
                        onClick={() => handlePreviewFile(selectedFileIndex + 1)}
                        className="p-1 text-gray-500 hover:text-red-500 disabled:opacity-20"
                      >
                        <ChevronRight size={16} />
                      </button>
                    </div>
                  )}
                </div>
                <div className="relative group rounded-[2rem] overflow-hidden border border-red-500/20 shadow-2xl bg-black aspect-video flex items-center justify-center">
                  <video 
                    ref={videoRef}
                    src={previewUrl} 
                    muted={muteAudio}
                    style={previewStyle}
                    className="max-w-full max-h-full transition-all duration-300" 
                    onLoadedMetadata={(e) => {
                      const dur = e.currentTarget.duration;
                      setDuration(dur);
                      setTrimEnd(dur);
                      setVideoSize({
                        width: e.currentTarget.videoWidth,
                        height: e.currentTarget.videoHeight
                      });
                    }}
                    controls
                  />
                  {mode === 'crop' && (
                    <div className="absolute inset-0 pointer-events-none">
                      <div 
                        className="absolute border-2 border-red-500 bg-red-500/10 shadow-[0_0_0_9999px_rgba(0,0,0,0.5)]"
                        style={{
                          left: `${crop.x}%`,
                          top: `${crop.y}%`,
                          width: `${crop.width}%`,
                          height: `${crop.height}%`
                        }}
                      >
                        <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-30">
                          {[...Array(9)].map((_, i) => (
                            <div key={i} className="border-[0.5px] border-white" />
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Mode Controls Container */}
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">

        {mode === 'trim' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Scissors size={18} className="text-red-500" />
                <label className="text-sm font-bold text-white">Trim Range</label>
              </div>
              <div className="flex gap-4 text-xs font-mono text-yellow-400 bg-black/40 px-3 py-1 rounded-lg border border-red-500/10">
                <span>{formatTime(trimStart)}</span>
                <span>-</span>
                <span>{formatTime(trimEnd)}</span>
                <span className="text-gray-500 ml-2">({(trimEnd - trimStart).toFixed(1)}s)</span>
              </div>
            </div>

            <div className="space-y-8">
              <div className="relative h-4 bg-gray-800 rounded-full overflow-hidden">
                {/* Visual track for the selected range */}
                <div 
                  className="absolute h-full bg-red-600/30 border-x border-red-500/50"
                  style={{ 
                    left: `${(trimStart / duration) * 100}%`, 
                    width: `${((trimEnd - trimStart) / duration) * 100}%` 
                  }}
                />
                <input 
                  type="range" min="0" max={duration} step="0.1" value={trimStart}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setTrimStart(Math.min(val, trimEnd - 0.1));
                  }}
                  className="absolute w-full h-full bg-transparent appearance-none cursor-pointer accent-red-600 z-20 pointer-events-auto"
                />
                <input 
                  type="range" min="0" max={duration} step="0.1" value={trimEnd}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setTrimEnd(Math.max(val, trimStart + 0.1));
                  }}
                  className="absolute w-full h-full bg-transparent appearance-none cursor-pointer accent-yellow-400 z-10 pointer-events-auto"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold text-gray-500 uppercase">Start Time</span>
                    <button 
                      onClick={() => videoRef.current && setTrimStart(videoRef.current.currentTime)}
                      className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase transition-colors"
                    >
                      Set Current
                    </button>
                  </div>
                  <input 
                    type="number" step="0.1" min="0" max={trimEnd} value={trimStart.toFixed(1)}
                    onChange={(e) => setTrimStart(Math.min(parseFloat(e.target.value) || 0, trimEnd - 0.1))}
                    className="w-full bg-black/40 border border-red-500/10 rounded-xl px-4 py-2 text-sm text-white focus:border-red-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold text-gray-500 uppercase">End Time</span>
                    <button 
                      onClick={() => videoRef.current && setTrimEnd(videoRef.current.currentTime)}
                      className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase transition-colors"
                    >
                      Set Current
                    </button>
                  </div>
                  <input 
                    type="number" step="0.1" min={trimStart} max={duration} value={trimEnd.toFixed(1)}
                    onChange={(e) => setTrimEnd(Math.max(parseFloat(e.target.value) || 0, trimStart + 0.1))}
                    className="w-full bg-black/40 border border-red-500/10 rounded-xl px-4 py-2 text-sm text-white focus:border-red-500 outline-none transition-all"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {mode === 'speed' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white">Playback Speed</label>
              <span className="text-lg font-black text-red-600">{speed.toFixed(2)}x</span>
            </div>
            <div className="px-2">
              <input 
                type="range" min="0.5" max="2.0" step="0.05" value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-600"
              />
              <div className="flex justify-between mt-2 text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                <span>0.5x (Slow)</span>
                <span>1.0x (Normal)</span>
                <span>2.0x (Fast)</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 italic text-center">
              The preview player above updates its playback speed in real-time as you move the slider.
            </p>
          </div>
        )}

        {mode === 'brightness' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sun size={20} className="text-yellow-400" />
                <label className="text-sm font-bold text-white">Video Brightness</label>
              </div>
              <button 
                onClick={() => setBrightness(1.0)}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-400">Adjust the overall lightness of your video</span>
                <span className="text-lg font-black text-yellow-400">{Math.round(brightness * 100)}%</span>
              </div>
              <input 
                type="range" min="0.5" max="1.5" step="0.01" value={brightness}
                onChange={(e) => setBrightness(parseFloat(e.target.value))}
                className="w-full h-3 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-yellow-500"
              />
              <div className="flex justify-between text-[10px] text-gray-500 uppercase font-bold">
                <span>Darker</span>
                <span>Normal</span>
                <span>Brighter</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 italic text-center">
              The live preview above updates instantly as you move the slider.
            </p>
          </div>
        )}

        {mode === 'contrast' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Contrast size={20} className="text-blue-400" />
                <label className="text-sm font-bold text-white">Video Contrast</label>
              </div>
              <button 
                onClick={() => setContrast(1.0)}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-400">Fine-tune the difference between light and dark areas</span>
                <span className="text-lg font-black text-blue-400">{Math.round(contrast * 100)}%</span>
              </div>
              <input 
                type="range" min="0.5" max="2.0" step="0.01" value={contrast}
                onChange={(e) => setContrast(parseFloat(e.target.value))}
                className="w-full h-3 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[10px] text-gray-500 uppercase font-bold">
                <span>Low Contrast</span>
                <span>Normal</span>
                <span>High Contrast</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 italic text-center">
              The live preview above updates instantly as you move the slider.
            </p>
          </div>
        )}

        {mode === 'hue' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Palette size={20} className="text-purple-400" />
                <label className="text-sm font-bold text-white">Hue Rotation</label>
              </div>
              <button 
                onClick={() => setHue(0)}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-400">Shift the colors of your video</span>
                <span className="text-lg font-black text-purple-400">{hue}°</span>
              </div>
              <input 
                type="range" min="-180" max="180" step="1" value={hue}
                onChange={(e) => setHue(parseInt(e.target.value))}
                className="w-full h-3 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                style={{
                  background: 'linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000)'
                }}
              />
              <div className="flex justify-between text-[10px] text-gray-500 uppercase font-bold">
                <span>-180°</span>
                <span>0°</span>
                <span>180°</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 italic text-center">
              Preview updates instantly. Shift colors across the entire spectrum.
            </p>
          </div>
        )}

        {mode === 'volume' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Volume2 size={20} className="text-green-400" />
                <label className="text-sm font-bold text-white">Audio Volume</label>
              </div>
              <button 
                onClick={() => setVolume(1.0)}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-400">Adjust the loudness of your video</span>
                <span className="text-lg font-black text-green-400">{Math.round(volume * 100)}%</span>
              </div>
              <input 
                type="range" min="0" max="2.0" step="0.01" value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full h-3 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-green-500"
              />
              <div className="flex justify-between text-[10px] text-gray-500 uppercase font-bold">
                <span>Mute</span>
                <span>Normal</span>
                <span>200% (Boost)</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-500 italic text-center">
              Preview updates instantly. Volume is applied to the final exported video.
            </p>
          </div>
        )}

        {mode === 'adjust' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white">Manual Adjustments</label>
              <button 
                onClick={() => {
                  setBrightness(1.0);
                  setContrast(1.0);
                  setHue(0);
                  setVolume(1.0);
                }}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Sun size={16} className="text-yellow-400" />
                    <label className="text-xs font-bold text-gray-300">Brightness</label>
                  </div>
                  <span className="text-xs font-mono text-yellow-400">{Math.round(brightness * 100)}%</span>
                </div>
                <input 
                  type="range" min="0.5" max="1.5" step="0.01" value={brightness}
                  onChange={(e) => setBrightness(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-600"
                />
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Contrast size={16} className="text-blue-400" />
                    <label className="text-xs font-bold text-gray-300">Contrast</label>
                  </div>
                  <span className="text-xs font-mono text-blue-400">{Math.round(contrast * 100)}%</span>
                </div>
                <input 
                  type="range" min="0.5" max="1.5" step="0.01" value={contrast}
                  onChange={(e) => setContrast(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-600"
                />
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Palette size={16} className="text-purple-400" />
                    <label className="text-xs font-bold text-gray-300">Hue</label>
                  </div>
                  <span className="text-xs font-mono text-purple-400">{hue}°</span>
                </div>
                <input 
                  type="range" min="-180" max="180" step="1" value={hue}
                  onChange={(e) => setHue(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-purple-600"
                />
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Volume2 size={16} className="text-green-400" />
                    <label className="text-xs font-bold text-gray-300">Volume</label>
                  </div>
                  <span className="text-xs font-mono text-green-400">{Math.round(volume * 100)}%</span>
                </div>
                <input 
                  type="range" min="0" max="2.0" step="0.01" value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-green-600"
                />
              </div>
            </div>
            <p className="text-[10px] text-gray-500 italic text-center">
              Preview is applied instantly to the player above.
            </p>
          </div>
        )}

        {mode === 'effects' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white">Visual Effects</label>
              <button 
                onClick={() => {
                  setEffect('none');
                  setIntensity(1.0);
                }}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="relative">
                <select 
                  value={effect}
                  onChange={(e) => setEffect(e.target.value as any)}
                  className="w-full p-4 bg-black/60 text-white rounded-xl border border-red-500/20 focus:ring-2 focus:ring-red-500 outline-none appearance-none cursor-pointer pr-10"
                >
                  <option value="none">None (Original)</option>
                  <option value="vintage">Vintage Film</option>
                  <option value="glitch">Glitch Effect</option>
                  <option value="vibrant">Vibrant Colors</option>
                  <option value="grayscale">Black & White</option>
                  <option value="sepia">Sepia Tone</option>
                </select>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                  <ChevronDown size={16} />
                </div>
              </div>
            </div>

            {effect !== 'none' && (
              <div className="space-y-4 pt-4 border-t border-red-500/10">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-gray-300 uppercase tracking-wider">Effect Intensity</label>
                  <span className="text-xs font-mono text-red-500">{Math.round(intensity * 100)}%</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.01" value={intensity}
                  onChange={(e) => setIntensity(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-600"
                />
              </div>
            )}
          </div>
        )}

        {mode === 'crop' && files.length > 0 && (
          <div className="space-y-6 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white">Crop & Aspect Ratio</label>
              <button 
                onClick={() => handleAspectRatioChange('original')}
                className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCw size={12} />
                Reset
              </button>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Presets</label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {[
                  { id: 'original', label: 'Original' },
                  { id: '16:9', label: '16:9' },
                  { id: '9:16', label: '9:16' },
                  { id: '1:1', label: '1:1' },
                  { id: '4:3', label: '4:3' },
                  { id: '21:9', label: '21:9' },
                  { id: '2:3', label: '2:3' },
                  { id: '5:4', label: '5:4' }
                ].map((ratio) => (
                  <button
                    key={ratio.id}
                    onClick={() => handleAspectRatioChange(ratio.id)}
                    className={cn(
                      "py-2 px-3 rounded-lg text-[10px] font-bold uppercase transition-all border",
                      aspectRatio === ratio.id 
                        ? "bg-red-600 text-white border-red-600 shadow-lg shadow-red-500/20" 
                        : "bg-black/40 text-gray-400 border-red-500/20 hover:border-red-500"
                    )}
                  >
                    {ratio.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-red-500/10">
              {[
                { label: 'X Position', key: 'x', min: 0, max: 100 - crop.width },
                { label: 'Y Position', key: 'y', min: 0, max: 100 - crop.height },
                { label: 'Width', key: 'width', min: 1, max: 100 - crop.x },
                { label: 'Height', key: 'height', min: 1, max: 100 - crop.y }
              ].map((ctrl) => (
                <div key={ctrl.key} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold text-gray-400 uppercase">{ctrl.label}</label>
                    <span className="text-[10px] font-mono text-red-500">{Math.round(crop[ctrl.key as keyof typeof crop])}%</span>
                  </div>
                  <input 
                    type="range" min={ctrl.min} max={ctrl.max} step="1" 
                    value={crop[ctrl.key as keyof typeof crop]}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setCrop(prev => ({ ...prev, [ctrl.key]: val }));
                      setAspectRatio('custom');
                    }}
                    className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-600"
                  />
                </div>
              ))}
            </div>
          </div>
        )}
        {mode === 'mute' && files.length > 0 && (
          <div className="space-y-4 bg-black/40 p-6 rounded-2xl border border-red-500/20">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white">Audio Control</label>
              <VolumeX size={24} className={muteAudio ? "text-red-500" : "text-gray-400"} />
            </div>
            <div className="p-4 bg-black/60 rounded-xl border border-red-500/10 space-y-4">
              <div className="flex items-center gap-4">
                <input 
                  type="checkbox" id="mute-tab-toggle" checked={muteAudio}
                  onChange={(e) => setMuteAudio(e.target.checked)}
                  className="w-6 h-6 rounded border-red-500/20 text-red-600 focus:ring-red-500"
                />
                <label htmlFor="mute-tab-toggle" className="text-base font-bold text-white cursor-pointer">
                  Silence Video
                </label>
              </div>
              <p className="text-xs text-gray-400 italic">
                This will remove all audio tracks from your video. You can also use the toggle below while in other modes.
              </p>
            </div>
          </div>
        )}

                  </div>
                </div>
            ) : mode === 'merge' ? (
              <div className="space-y-8 py-12 text-center animate-in fade-in zoom-in duration-700">
                <div className="w-24 h-24 bg-red-500/10 rounded-full flex items-center justify-center mx-auto text-red-500">
                  <Layers size={48} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-black text-white uppercase italic">Merge Workspace</h3>
                  <p className="text-sm text-gray-500 max-w-sm mx-auto">Upload multiple clips in the sidebar to combine them into a single seamless video file.</p>
                </div>
                <div className="flex flex-col items-center gap-4">
                  <div className="relative inline-block group">
                    <button className="px-8 py-3 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-700 transition-all flex items-center gap-2 border border-red-500/20">
                      Add Video Clips
                      <Plus size={16} />
                    </button>
                    <input 
                      type="file" 
                      onChange={handleFileChange} 
                      multiple={true}
                      className="absolute inset-0 opacity-0 cursor-pointer" 
                      accept="video/*" 
                    />
                  </div>
                  {files.length > 0 && (
                    <button
                      onClick={processVideo}
                      disabled={loading || files.length < 2}
                      className="px-8 py-4 bg-red-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-xl shadow-red-600/30 active:scale-95 flex items-center gap-2 mx-auto disabled:opacity-50"
                    >
                      {loading ? `Merging (${progress}%)` : 'Merge Clips Now'}
                      <FastForward size={20} />
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-8 py-24 text-center animate-in fade-in zoom-in duration-700 relative">
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5 overflow-hidden">
                  <Play size={400} className="text-red-500" />
                </div>
                <div className="relative z-10 space-y-6">
                  <div className="w-24 h-24 bg-red-500/10 rounded-full flex items-center justify-center mx-auto text-red-500 border border-red-500/20 shadow-inner">
                    <Upload size={48} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Ready to Edit</h3>
                    <p className="text-sm text-gray-500 max-w-sm mx-auto">Upload a video file from your device to begin professional {mode} adjustments.</p>
                  </div>
                  <div className="pt-4">
                    <div className="relative inline-block group">
                      <button className="px-10 py-4 bg-red-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-2xl shadow-red-600/40 active:scale-95 flex items-center gap-3">
                        Choose Video File
                        <Plus size={20} />
                      </button>
                      <input 
                        type="file" 
                        onChange={handleFileChange} 
                        multiple={false}
                        className="absolute inset-0 opacity-0 cursor-pointer" 
                        accept="video/*" 
                      />
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-600 font-bold uppercase tracking-widest pt-4">Supported formats: MP4, MOV, AVI, WEBM</p>
                </div>
              </div>
            )}

            {outputUrl && (
              <div className="pt-8 border-t border-red-500/20 animate-in slide-in-from-top-4 duration-500">
                <div className="bg-green-500/10 border border-green-500/20 p-6 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-500/20 rounded-2xl flex items-center justify-center text-green-500">
                      <CheckCircle2 size={24} />
                    </div>
                    <div>
                      <p className="text-sm font-black text-green-500 uppercase tracking-widest">Processing Complete</p>
                      <p className="text-xs text-slate-400">Your edited video is ready for download</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <a 
                      href={outputUrl} 
                      download="edited-video.mp4"
                      className="px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all flex items-center gap-2 shadow-lg shadow-green-600/20"
                    >
                      Download MP4
                      <Download size={18} />
                    </a>
                    <button 
                      onClick={() => setOutputUrl(null)}
                      className="px-6 py-3 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-700 transition-all"
                    >
                      Clear
                    </button>
                  </div>
                </div>
                <div className="mt-6 rounded-2xl overflow-hidden border border-red-500/20 shadow-2xl aspect-video bg-black">
                  <video src={outputUrl} controls className="w-full h-full" />
                </div>
              </div>
            )}
          </div>

          <div className="text-center">
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-600">
              Powerful In-Browser Video Processing • 100% Private
            </p>
          </div>
        </main>
      </div>
    </div>
  );
};

const ContextualAISuggestion = ({ onLaunchTool }: { onLaunchTool: (toolId: string, prompt?: string) => void }) => {
  const [suggestion, setSuggestion] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const hour = new Date().getHours();
    const month = new Date().getMonth();
    const day = new Date().getDay();
    
    let idea = "A cinematic video of a futuristic city at sunset";
    
    if (hour >= 20 || hour < 5) {
      idea = "A dreamy landscape under a starlit sky with aurora borealis";
    } else if (hour >= 5 && hour < 10) {
      idea = "A crisp morning scene in a lush forest with golden sunbeams";
    } else if (hour >= 10 && hour < 17) {
      idea = "A vibrant urban street scene bustling with afternoon energy";
    }

    if (month >= 2 && month <= 4) { // Spring
      idea += " amidst blooming cherry blossoms";
    } else if (month >= 5 && month <= 7) { // Summer
      idea += " with clear blue tropical waters";
    } else if (month >= 8 && month <= 10) { // Autumn
      idea += " surrounded by vibrant autumn foliage";
    } else { // Winter
      idea += " in a serene snow-covered valley";
    }

    if (day === 0 || day === 6) {
      idea += " - capturing the peaceful energy of a weekend getaway";
    } else if (day === 5) {
      idea += " - celebrating the vibrant spirit of a Friday night";
    }

    setSuggestion(idea);
    setLoading(false);
  }, []);

  if (loading) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl mx-auto mt-8 bg-gradient-to-r from-red-600/20 via-purple-600/20 to-indigo-600/20 backdrop-blur-xl border border-white/10 p-8 rounded-[2.5rem] flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl group relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="flex items-center gap-6 relative z-10 w-full md:w-auto">
        <div className="w-16 h-16 bg-red-500/20 rounded-[1.5rem] flex items-center justify-center text-red-400 group-hover:rotate-12 transition-all shadow-inner border border-red-500/20 shrink-0">
          <Sparkles size={32} className="animate-pulse" />
        </div>
        <div className="text-left space-y-2">
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-red-500">Live AI Vision</p>
          <p className="text-lg md:text-xl text-white font-black leading-tight italic tracking-tighter">
            "{suggestion}"
          </p>
        </div>
      </div>
      <div className="flex flex-wrap md:flex-nowrap items-center gap-3 w-full md:w-auto relative z-10">
        <button 
          onClick={() => onLaunchTool('ai-video-studio', suggestion)}
          className="flex-1 md:flex-none px-6 py-4 bg-white text-black text-[10px] font-black uppercase italic tracking-widest rounded-2xl hover:bg-red-500 hover:text-white transition-all shadow-2xl active:scale-95 group/btn flex items-center justify-center gap-3"
        >
          Film Studio
          <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
        </button>
        <button 
          onClick={() => onLaunchTool('image-gen-pro', suggestion)}
          className="flex-1 md:flex-none px-6 py-4 bg-white/10 text-white text-[10px] font-black uppercase italic tracking-widest rounded-2xl hover:bg-indigo-600 border border-white/10 transition-all shadow-2xl active:scale-95 group/btn flex items-center justify-center gap-3"
        >
          Image Forge
          <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
        </button>
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [currentView, setCurrentView] = useState('home');
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>('All');
  const [sortBy, setSortBy] = useState<'default' | 'popular' | 'alphabetical' | 'alphabetical-desc'>('default');
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [userFavorites, setUserFavorites] = useState<string[]>([]);
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setUserFavorites([]);
      return;
    }

    const q = query(collection(db, 'favorites'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const favs = snapshot.docs.map(doc => doc.data().toolId);
      setUserFavorites(favs);
    }, (error) => {
      console.error("Error fetching favorites:", error);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
      
      if (currentUser) {
        // Sync user profile to Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: currentUser.uid,
            email: currentUser.email,
            displayName: currentUser.displayName,
            photoURL: currentUser.photoURL,
            role: 'user',
            createdAt: serverTimestamp()
          });
        }
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    TOOLS.forEach(tool => {
      counts[tool.category] = (counts[tool.category] || 0) + 1;
    });
    return counts;
  }, []);

  const filteredTools = useMemo(() => {
    let result = TOOLS.filter(tool => {
      const query = searchQuery.toLowerCase();
      const matchesSearch = tool.name.toLowerCase().includes(query) || 
                           tool.description.toLowerCase().includes(query) ||
                           (tool.tags && tool.tags.some(tag => tag.toLowerCase().includes(query)));
      const matchesCategory = activeCategory === 'All' || tool.category === activeCategory;
      return matchesSearch && matchesCategory;
    });

    if (sortBy === 'popular') {
      result = [...result].sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
    } else if (sortBy === 'alphabetical') {
      result = [...result].sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === 'alphabetical-desc') {
      result = [...result].sort((a, b) => b.name.localeCompare(a.name));
    }

    return result;
  }, [searchQuery, activeCategory, sortBy]);

  const handleToolClick = async (tool: Tool, initialPrompt?: string) => {
    setPendingPrompt(initialPrompt || null);
    setSelectedTool(tool);
    setCurrentView('tool-detail');
    window.scrollTo(0, 0);

    // Save to history if logged in
    if (user) {
      try {
        await addDoc(collection(db, 'history'), {
          userId: user.uid,
          toolId: tool.id,
          toolName: tool.name,
          timestamp: serverTimestamp()
        });
      } catch (error) {
        console.error("Error saving history:", error);
      }
    }
  };

  const handleToggleFavorite = async (toolId: string) => {
    if (!user) return;

    const favRef = doc(db, 'favorites', `${user.uid}_${toolId}`);
    const isFav = userFavorites.includes(toolId);

    try {
      if (isFav) {
        await deleteDoc(favRef);
      } else {
        await setDoc(favRef, {
          userId: user.uid,
          toolId: toolId,
          addedAt: serverTimestamp()
        });
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  const renderToolContent = () => {
    if (!selectedTool) return null;
    switch (selectedTool.id) {
      case 'word-counter': return <WordCounter />;
      case 'qr-gen': return <QRCodeGenerator />;
      case 'markdown-editor': return <MarkdownEditor />;
      case 'json-formatter': return <JSONFormatter />;
      case 'bmi-calc': return <BMICalculator />;
      case 'case-conv': return <CaseConverter />;
      case 'base64-conv': return <Base64Tool />;
      case 'url-conv': return <URLEncoder />;
      case 'percentage-calc': return <PercentageCalc />;
      case 'merge-pdf': return <MergePDF />;
      case 'rotate-pdf': return <RotatePDF />;
      case 'protect-pdf': return <ProtectPDF />;
      case 'sign-pdf': return <SignPDF />;
      case 'ocr-pdf': return <OCR_PDF />;
      case 'word-to-pdf': return <WordToPDF />;
      case 'pdf-to-word': return <PDFtoWord />;
      case 'excel-to-pdf': return <ExcelToPDF />;
      case 'ppt-to-pdf': return <PPTtoPDF />;
      case 'html-to-pdf': return <HTMLToPDF />;
      case 'pdf-editor': return <PDFEditor />;
      case 'pdf-size-reducer': return <PDFSizeReducer />;
      case 'unlock-pdf': return <UnlockPDF />;
      case 'jpg-to-pdf': return <JPGtoPDF />;
      case 'pdf-to-jpg': return <PDFtoJPG />;
      case 'compress-pdf': return <CompressPDF />;
      case 'extract-pages': return <ExtractPages />;
      case 'add-watermark': return <AddWatermark />;
      case 'pdf-viewer': return <PDFViewer />;
      case 'split-pdf': return <SplitPDF />;
      case 'tts': return <TextToSpeech />;
      case 'plagiarism-check': return <PlagiarismChecker />;
      case 'music-gen': return <MusicGenerator />;
      case 'bg-remover': return <BGRemover />;
      case 'image-resizer': return <ImageResizer />;
      case 'watermark-image': return <WatermarkImage />;
      case 'image-gen-pro': return <AIImageStudio initialPrompt={pendingPrompt || undefined} />;
      case 'image-editor-ai': return <ImageEditorAI />;
      case 'image-analyzer': return <AIAnalyzer type="image" />;
      case 'image-compressor': return <ImageCompressor />;
      case 'video-analyzer': return <VideoContentAnalyzer />;
      case 'video-gen-ai': return <VideoCreatorAI />;
      case 'ai-video-generator': return <AIVideoGenerator />;
      case 'video-agent': return <AIVideoAgent />;
      case 'advanced-video-ai': return <AdvancedVideoAI />;
      case 'thinking-ai': return <ThinkingAI />;
      case 'creative-writer': return <CreativeWriter />;
      case 'code-reviewer': return <CodeReviewer />;
      case 'translation-studio': return <TranslationStudio />;
      case 'gemini-explorer': return <GeminiExplorer />;
      case 'smart-search': return <SmartSearch />;
      case 'map-explorer-ai': return <MapExplorerAI />;
      case 'ai-chatbot': return <AIChatbot />;
      case 'audio-transcriber': return <AudioTranscriber />;
      case 'caption-gen': return <CaptionGenerator />;
      case 'html-minifier': return <HTMLMinifier />;
      case 'css-minifier': return <CSSMinifier />;
      case 'js-minifier': return <JSMinifier />;
      case 'theme-toggler': return <ThemeToggler darkMode={darkMode} toggleDarkMode={() => setDarkMode(!darkMode)} />;
      case 'youtube-thumbnail-downloader': return <YouTubeThumbnailDownloader />;
      case 'video-downloader': return <VideoDownloader />;
      case 'video-compressor': return <VideoCompressor />;
      case 'ai-video-studio': return <AIVideoStudio initialPrompt={pendingPrompt || undefined} />;
      case 'video-converter': return <VideoConverter />;
      case 'video-to-mp3': return <VideoToMP3 />;
      case 'video-editor-pro': return <VideoEditorPro />;
      case 'trim-video': return <VideoEditorPro initialMode="trim" />;
      case 'merge-videos': return <VideoEditorPro initialMode="merge" />;
      case 'video-speed': return <VideoEditorPro initialMode="speed" />;
      case 'video-effects': return <VideoEditorPro initialMode="effects" />;
      case 'video-brightness': return <VideoEditorPro initialMode="brightness" />;
      case 'video-contrast': return <VideoEditorPro initialMode="contrast" />;
      case 'video-hue': return <VideoEditorPro initialMode="hue" />;
      case 'video-volume': return <VideoEditorPro initialMode="volume" />;
      case 'live-ai-chat': return <LiveAIAssistant />;
      case 'image-to-video': return <ImageToVideo />;
      case 'task-manager': return <TaskManager />;
      default: return <PlaceholderTool tool={selectedTool} />;
    }
  };

  return (
    <div className="min-h-screen transition-colors duration-300">
      <Navbar 
        darkMode={darkMode} 
        toggleDarkMode={() => setDarkMode(!darkMode)} 
        onNavigate={(v) => {
          setCurrentView(v);
          setSelectedTool(null);
          window.scrollTo(0, 0);
        }}
        user={user}
        onSignIn={signInWithGoogle}
        onLogout={logout}
      />

      <main className="container mx-auto px-4 py-12">
        <AnimatePresence mode="wait">
          {currentView === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-16"
            >
              {/* Hero Section */}
              <section className="text-center space-y-8 py-12">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 border-2 border-red-600 text-yellow-400 text-sm font-bold shadow-lg shadow-red-500/20">
                    <Star size={16} className="fill-current" />
                    <span>100+ Free Online Tools</span>
                  </div>
                <h1 className="text-5xl md:text-7xl font-black tracking-tight text-white drop-shadow-lg">
                  All the tools you need, <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 to-yellow-400">in one place.</span>
                </h1>
                <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed drop-shadow-md">
                  Fast, secure, and free online tools for PDF, Images, Video, 
                  Calculators, and Developers. No installation required.
                </p>
                
                <div className="max-w-2xl mx-auto relative group">
                  <div className="absolute inset-0 bg-red-500/10 blur-2xl group-hover:bg-red-500/20 transition-all" />
                  <div className="relative flex items-center bg-black/40 border border-red-500/20 rounded-2xl p-2 shadow-2xl backdrop-blur-md">
                    <Search className="ml-4 text-gray-400" size={24} />
                    <input
                      type="text"
                      placeholder="Search for any tool (e.g., PDF to Word, BMI, JSON)..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          document.getElementById('tools-grid')?.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="flex-1 px-4 py-4 bg-transparent text-white outline-none text-lg placeholder:text-gray-500"
                    />
                    <button 
                      onClick={() => document.getElementById('tools-grid')?.scrollIntoView({ behavior: 'smooth' })}
                      className="hidden sm:block px-8 py-4 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-all shadow-lg shadow-red-500/20"
                    >
                      Search
                    </button>
                  </div>
                </div>
                
                <ContextualAISuggestion onLaunchTool={(id, prompt) => {
                  const tool = TOOLS.find(t => t.id === id);
                  if (tool) handleToolClick(tool, prompt);
                }} />
              </section>

              {/* Categories */}
              <section className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-white drop-shadow-md">Browse by Category</h2>
                  <button className="text-sm font-bold text-red-500 hover:underline">View All</button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                  <button
                    onClick={() => setActiveCategory('All')}
                    className={cn(
                      "p-4 rounded-2xl border transition-all flex flex-col items-center gap-3 relative",
                      activeCategory === 'All' 
                        ? "bg-red-600 border-red-600 text-white shadow-lg shadow-red-500/20" 
                        : "shiny-card border-red-500/20 text-gray-300 hover:border-red-500"
                    )}
                  >
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center transition-all border-2 border-red-600 shadow-sm",
                      "bg-black text-yellow-400 group-hover:shadow-[0_0_15px_rgba(255,0,0,0.3)] group-hover:scale-110 duration-300"
                    )}>
                      <LayoutGrid size={24} />
                    </div>
                    <span className="text-xs font-bold uppercase tracking-wider">All Tools</span>
                    <span className={cn(
                      "absolute top-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded-md",
                      activeCategory === 'All' ? "bg-white/20 text-white" : "bg-red-900/30 text-red-400"
                    )}>
                      {TOOLS.length}
                    </span>
                  </button>
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat.name}
                      onClick={() => setActiveCategory(cat.name)}
                      className={cn(
                        "p-4 rounded-2xl border transition-all flex flex-col items-center gap-3 relative",
                        activeCategory === cat.name 
                          ? "bg-red-600 border-red-600 text-white shadow-lg shadow-red-500/20" 
                          : "shiny-card border-red-500/20 text-gray-300 hover:border-red-500"
                      )}
                    >
                      <div className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center transition-all border-2 border-red-600 shadow-sm",
                        "bg-black text-yellow-400 group-hover:shadow-[0_0_15px_rgba(255,0,0,0.3)] group-hover:scale-110 duration-300"
                      )}>
                        <cat.icon size={24} />
                      </div>
                      <span className="text-xs font-bold uppercase tracking-wider">{cat.name}</span>
                      <span className={cn(
                        "absolute top-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded-md",
                        activeCategory === cat.name ? "bg-white/20 text-white" : "bg-red-900/30 text-red-400"
                      )}>
                        {categoryCounts[cat.name] || 0}
                      </span>
                    </button>
                  ))}
                </div>
              </section>

              {/* Favorites Section */}
              {user && userFavorites.length > 0 && (
                <section className="space-y-8">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-[#111827] dark:text-white flex items-center gap-2">
                      <Heart className="text-pink-500 fill-current" size={24} />
                      Your Favorites
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {TOOLS.filter(t => userFavorites.includes(t.id)).map(tool => (
                      <ToolCard 
                        key={tool.id} 
                        tool={tool} 
                        onClick={() => handleToolClick(tool)} 
                        user={user}
                        isFavorite={true}
                        onToggleFavorite={handleToggleFavorite}
                      />
                    ))}
                  </div>
                </section>
              )}

              {/* Tools Grid */}
              <section className="space-y-8" id="tools-grid">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <h2 className="text-2xl font-bold text-white drop-shadow-md">
                    {activeCategory === 'All' ? 'Popular Tools' : `${activeCategory} Tools`}
                  </h2>
                  <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
                    {(searchQuery || activeCategory !== 'All' || sortBy !== 'default') && (
                      <button 
                        onClick={() => {
                          setSearchQuery('');
                          setActiveCategory('All');
                          setSortBy('default');
                        }}
                        className="text-xs font-bold text-gray-300 hover:text-yellow-400 flex items-center gap-1 transition-colors"
                      >
                        <X size={14} />
                        Clear Filters
                      </button>
                    )}
                    <div className="flex items-center gap-2 bg-black/40 border border-red-500/20 rounded-xl px-3 py-1">
                      <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Sort:</span>
                      <select 
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as any)}
                        className="bg-transparent border-none outline-none text-sm font-bold text-yellow-400 cursor-pointer py-1"
                      >
                        <option value="default">Default</option>
                        <option value="popular">Popularity</option>
                        <option value="alphabetical">Name (A-Z)</option>
                        <option value="alphabetical-desc">Name (Z-A)</option>
                      </select>
                    </div>
                    <div className="relative w-full sm:w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <input
                        type="text"
                        placeholder="Filter tools..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 bg-black/40 border border-red-500/20 rounded-xl outline-none focus:ring-2 focus:ring-red-500 text-white text-sm transition-all"
                      />
                    </div>
                    <span className="text-sm text-gray-300 whitespace-nowrap">{filteredTools.length} tools found</span>
                  </div>
                </div>
                
                <div className="glass-overlay p-8 rounded-3xl border border-red-500/10 shadow-2xl">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredTools.map(tool => (
                      <div key={tool.id}>
                        <ToolCard 
                          tool={tool} 
                          onClick={() => handleToolClick(tool)} 
                          user={user} 
                          isFavorite={userFavorites.includes(tool.id)}
                          onToggleFavorite={handleToggleFavorite}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {filteredTools.length === 0 && (
                  <div className="text-center py-20 glass-overlay rounded-3xl border-2 border-dashed border-red-500/20">
                    <p className="text-gray-300">No tools found matching your search.</p>
                  </div>
                )}
              </section>

              {/* Features Section */}
              <section className="grid grid-cols-1 md:grid-cols-3 gap-8 py-12">
                {[
                  { title: '100% Free', desc: 'All tools are free to use without any subscription or hidden costs.', icon: Star },
                  { title: 'Secure & Private', desc: 'Your files are processed locally or deleted immediately after processing.', icon: Shield },
                  { title: 'Fast & Reliable', desc: 'Optimized for speed to get your tasks done in seconds.', icon: FastForward },
                ].map(feature => (
                  <div key={feature.title} className="p-8 bg-indigo-50/50 dark:bg-indigo-900/10 rounded-3xl space-y-4">
                    <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
                      <feature.icon size={24} />
                    </div>
                    <h3 className="text-xl font-bold dark:text-white">{feature.title}</h3>
                    <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{feature.desc}</p>
                  </div>
                ))}
              </section>
            </motion.div>
          )}

          {currentView === 'tool-detail' && selectedTool && (
            <motion.div
              key="tool-detail"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setCurrentView('home')}
                    className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-colors"
                  >
                    <ArrowLeft size={24} />
                  </button>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{selectedTool.category} Tool</span>
                    </div>
                    <h1 className="text-3xl font-black text-white">{selectedTool.name}</h1>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-lg border dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800">
                    <Share2 size={20} />
                  </button>
                  <button className="p-2 rounded-lg border dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800">
                    <Heart size={20} />
                  </button>
                </div>
              </div>

              <div className="glass-overlay border border-red-500/20 rounded-3xl p-8 shadow-2xl">
                {renderToolContent()}
              </div>

              {/* Ads Placeholder */}
              <div className="w-full h-32 bg-slate-100 dark:bg-slate-800/50 rounded-2xl border-2 border-dashed dark:border-slate-800 flex items-center justify-center text-slate-400 text-sm font-bold uppercase tracking-widest">
                Advertisement Space
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
              <h3 className="text-2xl font-bold text-white">About {selectedTool.name}</h3>
              <p className="text-gray-300 leading-relaxed">
                {selectedTool.description} ToolVerse provides a simple and efficient way to handle your {selectedTool.category.toLowerCase()} tasks online. 
                Our tools are designed to be fast, secure, and easy to use for everyone.
              </p>
              <div className="space-y-4">
                <h4 className="font-bold text-white">Key Features:</h4>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {['No registration required', 'Fast processing', 'Secure data handling', 'Mobile responsive'].map(f => (
                    <li key={f} className="flex items-center gap-2 text-gray-400">
                      <CheckCircle2 size={18} className="text-red-500" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
                </div>
                <div className="space-y-6">
              <h3 className="text-xl font-bold text-white">Related Tools</h3>
              <div className="space-y-4">
                {TOOLS.filter(t => t.category === selectedTool.category && t.id !== selectedTool.id).slice(0, 4).map(tool => (
                  <div 
                    key={tool.id}
                    onClick={() => handleToolClick(tool)}
                    className="p-4 bg-black/40 rounded-xl border border-red-500/20 cursor-pointer hover:border-red-500 transition-all flex items-center gap-4"
                  >
                    <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center text-yellow-400 border border-red-500/30">
                      <tool.icon size={20} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-sm text-white truncate">{tool.name}</h4>
                      <p className="text-xs text-gray-500 truncate">{tool.category}</p>
                    </div>
                    <ChevronRight size={16} className="text-red-500" />
                  </div>
                ))}
              </div>
                </div>
              </div>
            </motion.div>
          )}

          {['about', 'contact', 'privacy-policy', 'terms-of-service'].includes(currentView) && (
            <motion.div
              key="static-page"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl mx-auto space-y-8 py-12"
            >
              <h1 className="text-4xl font-black text-[#111827] dark:text-white capitalize">
                {currentView.replace('-', ' ')}
              </h1>
              <div className="prose dark:prose-invert max-w-none text-slate-600 dark:text-slate-400 space-y-6">
                <p>
                  Welcome to ToolVerse, your number one source for all online tools. We're dedicated to providing you the very best of web-based utilities, with an emphasis on speed, security, and simplicity.
                </p>
                <p>
                  Founded in 2026, ToolVerse has come a long way from its beginnings. When we first started out, our passion for "Tools for Everyone" drove us to start our own business.
                </p>
                <p>
                  We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer onNavigate={setCurrentView} />
    </div>
  );
}
